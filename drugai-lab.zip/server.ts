import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

// Initialize GoogleGenAI server-side client
let ai: GoogleGenAI | null = null;
if (process.env.GEMINI_API_KEY) {
  ai = new GoogleGenAI({
    apiKey: process.env.GEMINI_API_KEY,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// Medical Disclaimers
const STANDARD_DISCLAIMER =
  'DRUGAI-LAB provides general health and medicine information for educational purposes only. The information provided is not a diagnosis, prescription, or substitute for professional medical advice. Always consult a qualified physician or pharmacist before starting, stopping, or altering any medication. In an emergency, call your local emergency services immediately.';

// Curated Clinical Drug Interaction Database Fallback
interface DrugInteractionResult {
  pair: [string, string];
  severity: 'Major' | 'Moderate' | 'Minor' | 'None';
  description: string;
  mechanism: string;
  clinicalEffects: string[];
  precautions: string[];
  questionsForClinician: string[];
}

const KNOWN_INTERACTION_RULES: Array<{
  keywords: [string[], string[]];
  severity: 'Major' | 'Moderate' | 'Minor';
  description: string;
  mechanism: string;
  clinicalEffects: string[];
  precautions: string[];
  questionsForClinician: string[];
}> = [
  {
    keywords: [
      ['warfarin', 'coumadin', 'eliquis', 'xarelto', 'blood thinner'],
      ['aspirin', 'ibuprofen', 'advil', 'motrin', 'naproxen', 'aleve', 'nsaid'],
    ],
    severity: 'Major',
    description: 'High risk of gastrointestinal bleeding and systemic hemorrhaging.',
    mechanism: 'Additive antithrombotic and anticoagulant effects combined with NSAID-induced gastric mucosal injury and platelet inhibition.',
    clinicalEffects: [
      'Unusual bruising, black or tarry stools',
      'Persistent nosebleeds or bleeding gums',
      'Sudden weakness, dizziness, or signs of internal blood loss',
    ],
    precautions: [
      'Avoid concurrent use of over-the-counter NSAIDs unless specifically supervised by a hematologist or cardiologist.',
      'Consider physician-recommended alternatives such as acetaminophen if clinically appropriate.',
      'Promptly report any signs of overt or occult bleeding.',
    ],
    questionsForClinician: [
      'Is there a safer alternative pain relief option that does not increase bleeding risk?',
      'Should my INR / clotting time be monitored more frequently?',
      'Do I require a protective gastro-agent (PPI) if co-administration is strictly required?',
    ],
  },
  {
    keywords: [
      ['lisinopril', 'enalapril', 'ramipril', 'losartan', 'valsartan', 'ace inhibitor', 'arb'],
      ['spironolactone', 'potassium', 'k-dur', 'triamterene'],
    ],
    severity: 'Major',
    description: 'Elevated risk of severe hyperkalemia (dangerously high blood potassium levels).',
    mechanism: 'ACE inhibitors/ARBs reduce aldosterone secretion, decreasing renal potassium excretion, which synergizes with potassium-sparing diuretics or potassium supplements.',
    clinicalEffects: [
      'Cardiac arrhythmias, palpitations, or bradycardia',
      'Muscle weakness, tingling sensations, or numbness',
      'Fatigue or sudden confusion',
    ],
    precautions: [
      'Routine serum potassium and renal function (eGFR/Creatinine) monitoring is essential.',
      'Avoid high-potassium salt substitutes and unnecessary potassium supplements.',
    ],
    questionsForClinician: [
      'How frequently should my blood potassium levels be checked?',
      'Are dietary potassium restrictions recommended for my specific regimen?',
    ],
  },
  {
    keywords: [
      ['ssri', 'sertraline', 'zoloft', 'fluoxetine', 'prozac', 'escitalopram', 'lexapro', 'citalopram', 'snri', 'duloxetine', 'cymbalta'],
      ['tramadol', 'ultram', 'sumatriptan', 'imitrex', 'linezolid', 'st john wort', 'maoi'],
    ],
    severity: 'Major',
    description: 'Risk of Serotonin Syndrome, a potentially life-threatening condition.',
    mechanism: 'Additive serotonergic neurotransmission in the central and peripheral nervous system.',
    clinicalEffects: [
      'Agitation, restlessness, confusion, or delirium',
      'Hyperreflexia, tremors, rigidity, or shivering',
      'Tachycardia, high blood pressure, and hyperthermia',
    ],
    precautions: [
      'Watch for onset of mental status changes or neuromuscular hyperactivity, especially within 24–48 hours of dosage initiation.',
      'Seek immediate emergency care if high fever, rigid muscles, or confusion develop.',
    ],
    questionsForClinician: [
      'Can an alternative non-serotonergic analgesic or medication be prescribed?',
      'What are the earliest warning signs I should be vigilant for?',
    ],
  },
  {
    keywords: [
      ['atorvastatin', 'lipitor', 'simvastatin', 'zocor', 'lovastatin'],
      ['clarithromycin', 'erythromycin', 'itraconazole', 'ketoconazole', 'grapefruit'],
    ],
    severity: 'Major',
    description: 'Increased statin plasma concentrations, raising the risk of myopathy and rhabdomyolysis.',
    mechanism: 'Strong inhibition of hepatic cytochrome P450 CYP3A4, severely impeding statin metabolism.',
    clinicalEffects: [
      'Unexplained severe muscle aches, pain, or weakness',
      'Dark-colored (tea-colored) urine indicative of myoglobinuria',
      'Elevated creatine kinase and potential acute kidney injury',
    ],
    precautions: [
      'Temporary cessation of statin during short-course macrolide antibiotic therapy is frequently practiced.',
      'Report any unexpected muscle tenderness or dark urine promptly.',
    ],
    questionsForClinician: [
      'Should I temporarily pause my statin while taking this antibiotic/antifungal?',
      'Is there an alternative antibiotic that does not inhibit CYP3A4 enzymes?',
    ],
  },
  {
    keywords: [
      ['metformin', 'glucophage'],
      ['contrast', 'iodinated contrast', 'ct contrast', 'dye'],
    ],
    severity: 'Major',
    description: 'Increased risk of metformin-associated lactic acidosis following contrast-induced nephropathy.',
    mechanism: 'Radiological iodinated contrast can transiently impair renal function, leading to metformin accumulation.',
    clinicalEffects: [
      'Severe abdominal discomfort, nausea, malaise',
      'Deep and rapid breathing (Kussmaul breathing)',
      'Severe hypothermia or hypotension',
    ],
    precautions: [
      'Metformin is typically held prior to or at the time of procedure and resumed 48 hours later after verifying normal renal function.',
    ],
    questionsForClinician: [
      'When exactly should I stop taking metformin before my scheduled imaging scan?',
      'When can I safely resume my normal diabetic medication schedule?',
    ],
  },
  {
    keywords: [
      ['metoprolol', 'atenolol', 'propranolol', 'beta blocker'],
      ['albuterol', 'salbutamol', 'ventolin', 'beta agonist'],
    ],
    severity: 'Moderate',
    description: 'Mutual pharmacological antagonism reducing the efficacy of both medications.',
    mechanism: 'Beta-blockers can diminish the bronchodilatory response of beta-agonists, while high-dose beta-agonists may counteract blood pressure control.',
    clinicalEffects: [
      'Reduced relief of acute asthma or bronchospasm symptoms',
      'Transient elevations or fluctuations in resting pulse',
    ],
    precautions: [
      'Cardioselective beta-blockers (e.g., metoprolol, atenolol) are preferred over non-selective agents (propranolol) in respiratory conditions.',
      'Ensure rescue inhaler remains responsive under clinical oversight.',
    ],
    questionsForClinician: [
      'Is a cardioselective beta-blocker the best option for my cardiovascular and lung health profile?',
    ],
  },
  {
    keywords: [
      ['ciprofloxacin', 'cipro', 'levofloxacin', 'levaquin', 'doxycycline'],
      ['calcium', 'iron', 'ferrous', 'antacid', 'tums', 'magnesium', 'aluminum'],
    ],
    severity: 'Moderate',
    description: 'Significantly decreased antibiotic absorption due to chelation complexes.',
    mechanism: 'Polyvalent cations bind to fluoroquinolones and tetracyclines in the digestive tract, preventing GI absorption.',
    clinicalEffects: [
      'Subtherapeutic antibiotic levels leading to infection persistence or treatment failure.',
    ],
    precautions: [
      'Separate administration by at least 2 hours before or 4 to 6 hours after cation-containing antacids or mineral supplements.',
    ],
    questionsForClinician: [
      'What exact hourly interval is recommended between taking my mineral supplement and this antibiotic?',
    ],
  },
  {
    keywords: [
      ['omeprazole', 'prilosec', 'esomeprazole', 'nexium'],
      ['clopidogrel', 'plavix'],
    ],
    severity: 'Moderate',
    description: 'Reduced antiplatelet effectiveness of clopidogrel.',
    mechanism: 'Omeprazole inhibits CYP2C19, preventing metabolic bioactivation of clopidogrel into its active antiplatelet form.',
    clinicalEffects: [
      'Potential increase in thrombotic or cardiovascular events in high-risk patients.',
    ],
    precautions: [
      'Physicians frequently choose pantoprazole or an H2 blocker (e.g., famotidine) as an alternative with minimal CYP2C19 interaction.',
    ],
    questionsForClinician: [
      'Should I switch to pantoprazole or famotidine to protect my stomach while preserving clopidogrel activity?',
    ],
  },
];

// Fallback rule matcher
function evaluateDrugInteractionsLocally(medications: string[]): {
  interactions: DrugInteractionResult[];
  overallRisk: 'Major' | 'Moderate' | 'Minor' | 'None';
  summary: string;
} {
  const norm = medications.map((m) => m.toLowerCase().trim());
  const found: DrugInteractionResult[] = [];

  for (let i = 0; i < norm.length; i++) {
    for (let j = i + 1; j < norm.length; j++) {
      const medA = norm[i];
      const medB = norm[j];

      let matchedRule: (typeof KNOWN_INTERACTION_RULES)[0] | null = null;
      for (const rule of KNOWN_INTERACTION_RULES) {
        const [groupA, groupB] = rule.keywords;
        const aIn1 = groupA.some((k) => medA.includes(k));
        const bIn2 = groupB.some((k) => medB.includes(k));
        const bIn1 = groupA.some((k) => medB.includes(k));
        const aIn2 = groupB.some((k) => medA.includes(k));

        if ((aIn1 && bIn2) || (bIn1 && aIn2)) {
          matchedRule = rule;
          break;
        }
      }

      if (matchedRule) {
        found.push({
          pair: [medications[i], medications[j]],
          severity: matchedRule.severity,
          description: matchedRule.description,
          mechanism: matchedRule.mechanism,
          clinicalEffects: matchedRule.clinicalEffects,
          precautions: matchedRule.precautions,
          questionsForClinician: matchedRule.questionsForClinician,
        });
      }
    }
  }

  let overallRisk: 'Major' | 'Moderate' | 'Minor' | 'None' = 'None';
  if (found.some((x) => x.severity === 'Major')) overallRisk = 'Major';
  else if (found.some((x) => x.severity === 'Moderate')) overallRisk = 'Moderate';
  else if (found.some((x) => x.severity === 'Minor')) overallRisk = 'Minor';

  const summary =
    found.length > 0
      ? `Identified ${found.length} clinically documented interaction${found.length > 1 ? 's' : ''} among the ${medications.length} queried medications. Detailed pharmacological mechanisms and monitoring guidance are provided below.`
      : `No severe direct interactions were detected among the queried medications [${medications.join(', ')}] in our standard core screening reference. However, individual patient variables (renal function, liver metabolism, age, and genetics) alter drug disposition. Always verify with your prescriber.`;

  return { interactions: found, overallRisk, summary };
}

// 1. Drug Interaction Checker Endpoint
app.post('/api/ai/interaction-checker', async (req, res) => {
  try {
    const { medications, language = 'English' } = req.body;
    if (!medications || !Array.isArray(medications) || medications.length < 2) {
      return res.status(400).json({
        error: 'Please provide at least 2 medications to screen for interactions.',
      });
    }

    const cleanedMeds = medications
      .map((m: string) => String(m).trim())
      .filter((m: string) => m.length > 0);

    if (cleanedMeds.length < 2) {
      return res.status(400).json({
        error: 'Please provide at least 2 valid medication names.',
      });
    }

    if (ai) {
      try {
        const prompt = `You are the DRUGAI-LAB Clinical Pharmacology & Drug Safety Engine.
Analyze potential drug-drug interactions between these medications: ${JSON.stringify(cleanedMeds)}.
Language requested: ${language}.

IMPORTANT CLINICAL SAFETY RULES:
- Identify pairwise interactions with exact clinical rigor.
- Assign severity strictly as "Major", "Moderate", "Minor", or "None".
- Explain pharmacological mechanism (e.g. CYP3A4 inhibition, additive QT prolongation, antiplatelet synergism, renal clearance competition).
- Detail clinical signs & symptoms patients should be vigilant of.
- Give evidence-based precautions and actionable questions to discuss with their physician or pharmacist.
- ALWAYS include a clear safety disclaimer: DRUGAI-LAB does not diagnose, prescribe or recommend altering dosages.

Return ONLY a valid JSON object matching this exact structure:
{
  "overallRisk": "Major" | "Moderate" | "Minor" | "None",
  "summary": "Clinical overview summary paragraph",
  "interactions": [
    {
      "pair": ["Drug 1", "Drug 2"],
      "severity": "Major" | "Moderate" | "Minor",
      "description": "Clear clinical summary of the interaction",
      "mechanism": "Pharmacological/biochemical mechanism",
      "clinicalEffects": ["List of potential signs, symptoms or adverse risks"],
      "precautions": ["Recommended clinical precautions and monitoring"],
      "questionsForClinician": ["Targeted questions the patient should ask their pharmacist or doctor"]
    }
  ],
  "generalSafetyNotes": ["Key safe medication practices for these therapies"],
  "disclaimer": "${STANDARD_DISCLAIMER}"
}`;

        const response = await ai.models.generateContent({
          model: 'gemini-3.8-flash',
          contents: prompt,
          config: {
            responseMimeType: 'application/json',
          },
        });

        const rawText = response.text || '{}';
        const parsed = JSON.parse(rawText);
        return res.json({
          ...parsed,
          disclaimer: STANDARD_DISCLAIMER,
          source: 'DRUGAI Gemini Clinical Intelligence',
        });
      } catch (geminiErr) {
        console.warn('Gemini interaction check error, falling back to local database:', geminiErr);
      }
    }

    // Local DB fallback
    const localResult = evaluateDrugInteractionsLocally(cleanedMeds);
    return res.json({
      ...localResult,
      generalSafetyNotes: [
        'Always maintain an updated list of all prescription drugs, OTC remedies, vitamins, and herbal supplements.',
        'Inform both your prescribing doctor and dispensing pharmacist about every product you ingest.',
        'Never stop or adjust the dosage of critical medications without direct medical guidance.',
      ],
      disclaimer: STANDARD_DISCLAIMER,
      source: 'DRUGAI Core Clinical Pharmacopeia',
    });
  } catch (error: any) {
    console.error('Interaction checker error:', error);
    res.status(500).json({
      error: 'Failed to process interaction screening.',
      details: error?.message || 'Internal server error',
    });
  }
});

// 2. Conversational Health Assistant & Expert Personas Endpoint
app.post('/api/ai/chat', async (req, res) => {
  try {
    const {
      message,
      conversationHistory = [],
      expertType = 'general',
      language = 'English',
      beginnerMode = false,
    } = req.body;

    if (!message || typeof message !== 'string') {
      return res.status(400).json({ error: 'Message content is required.' });
    }

    // Expert personas
    const EXPERT_ROLES: Record<string, string> = {
      general: 'DRUGAI General Health Assistant: A friendly, evidence-based healthcare educator providing structured health information.',
      medicine: 'AI Medicine Information Assistant: Specialized in pharmacology, drug mechanisms, common indications, side effects, and safe usage guidelines.',
      pharmacology: 'AI Pharmacology Learning Assistant: Tailored for pharmacy and medical students, explaining pharmacokinetics (ADME), receptor dynamics, and biochemical pathways.',
      nutrition: 'AI Nutrition Education Assistant: Explains dietary balance, micronutrients, vitamin interactions with medications, and lifestyle health.',
      mental: 'AI Mental Wellness Information Assistant: Offers psychoeducational support, coping strategies, and mental health literacy (with immediate crisis hotline recommendations).',
      firstaid: 'AI First-Aid Education Assistant: Teaches standard first-aid protocols, CPR basics, burn care, and distinguishes minor injuries from medical emergencies.',
      tutor: 'AI Student Medical Tutor: Educational companion for healthcare students offering case scenarios, practice questions, and anatomical/physiological breakdowns.',
      research: 'AI Medical Research Assistant: Helps researchers explore clinical trial methodologies, peer-reviewed study designs, statistical endpoints, and medical literature standards.',
    };

    const roleDescription = EXPERT_ROLES[expertType] || EXPERT_ROLES.general;

    // Detect language script from user message
    const detectDominantLanguage = (text: string, preferred: string): { lang: string; scriptName: string } => {
      if (/[\u0C00-\u0C7F]/.test(text)) return { lang: 'Telugu', scriptName: 'Telugu script (తెలుగు)' };
      if (/[\u0900-\u097F]/.test(text)) {
        if (preferred.toLowerCase().includes('marathi')) return { lang: 'Marathi', scriptName: 'Devanagari script (मराठी)' };
        return { lang: 'Hindi', scriptName: 'Devanagari script (हिन्दी)' };
      }
      if (/[\u0B80-\u0BFF]/.test(text)) return { lang: 'Tamil', scriptName: 'Tamil script (தமிழ்)' };
      if (/[\u0C80-\u0CFF]/.test(text)) return { lang: 'Kannada', scriptName: 'Kannada script (ಕನ್ನಡ)' };
      if (/[\u0D00-\u0D7F]/.test(text)) return { lang: 'Malayalam', scriptName: 'Malayalam script (മലയാളം)' };
      if (/[\u0980-\u09FF]/.test(text)) return { lang: 'Bengali', scriptName: 'Bengali script (বাংলা)' };
      if (/[\u0A80-\u0AFF]/.test(text)) return { lang: 'Gujarati', scriptName: 'Gujarati script (ગુજરાતી)' };
      if (/[\u0A00-\u0A7F]/.test(text)) return { lang: 'Punjabi', scriptName: 'Gurmukhi script (ਪੰਜਾਬੀ)' };
      if (/[\u0600-\u06FF]/.test(text)) return { lang: 'Urdu', scriptName: 'Urdu Nastaliq/Arabic script (اردو)' };
      return { lang: preferred, scriptName: `${preferred} script` };
    };

    const detected = detectDominantLanguage(message, language);
    const activeTargetLanguage = detected.lang;

    const systemPrompt = `You are ${roleDescription} on DRUGAI-LAB ("AI-Powered Health Knowledge, Medicine Awareness & Emergency Support").
Target Language: ${activeTargetLanguage}. Native Script Required: ${detected.scriptName}.
Explain Like I'm a Beginner Mode: ${beginnerMode ? 'ENABLED (Use plain language, simple everyday analogies, zero jargon, and high clarity)' : 'DISABLED (Professional healthcare standard)'}.

CRITICAL MULTILINGUAL & NATIVE WRITING SCRIPT RULES:
1. AUTOMATIC LANGUAGE DETECTION & MIRRORING:
   - Detect the language of the user's message. Reply in the EXACT SAME language.
   - You MUST write in the genuine native writing script of that language. NEVER use English letters (Latin alphabet) to transliterate non-English words.
   - If the user asks in Telugu, reply strictly in Telugu script (తెలుగు లిపి). Example: “జ్వరం రావడానికి ఇన్ఫెక్షన్లు సహా అనేక కారణాలు ఉండవచ్చు...” (NEVER write "Jwaram enduku vastundi?").
   - If the user asks in Hindi, reply strictly in Devanagari script (हिन्दी).
   - If the user asks in Tamil, reply strictly in Tamil script (தமிழ்).
   - If the user asks in Kannada, Malayalam, Marathi, Bengali, Gujarati, Punjabi, or Urdu, reply in their respective native scripts.
   - If the user asks in English, reply in English.
2. MIXED-LANGUAGE QUESTIONS: If the question mixes English and native words, identify the user's dominant intended language and respond in that language using its native script.
3. CONVERSATIONAL CONTINUITY: Keep the same language throughout the conversation unless the user explicitly asks to change languages.
4. SIMPLIFY CLINICAL TERMS: Translate difficult medical concepts and pharmacology terms into simple, relatable vocabulary in that language.
5. NEVER switch to English unnecessarily when the user is communicating in another language.

STRICT CLINICAL SAFETY RULES:
1. NEVER diagnose the user with a specific disease.
2. NEVER prescribe medications or provide personal dosing instructions like "Take X mg". Always advise consulting a qualified clinician.
3. Detect potential life-threatening emergencies immediately (chest pain, stroke symptoms FAST, severe breathlessness, anaphylaxis, severe bleeding, suicidal ideation). If detected, prominently place an EMERGENCY ALERT at the very top advising immediate local emergency services (e.g. 911 / 112 / 108) in their native language.
4. State that DRUGAI-LAB is for education only.
5. Provide structured, accurate, compassionate, and trustworthy answers.`;

    if (ai) {
      try {
        const contents = [
          ...conversationHistory.map((m: { role: string; content: string }) => ({
            role: m.role === 'assistant' ? 'model' : 'user',
            parts: [{ text: m.content }],
          })),
          { role: 'user', parts: [{ text: message }] },
        ];

        const response = await ai.models.generateContent({
          model: 'gemini-3.8-flash',
          contents,
          config: {
            systemInstruction: systemPrompt,
          },
        });

        const reply = response.text || 'Information is temporarily unavailable.';
        const isEmergency =
          /emergency|call 911|call 112|call 108|అత్యవసర|ఆస్పత్రి|आपातकालीन|জরুরি|அவசர|ತುರ್ತು|അടിയന്തര|immediate medical attention|chest pain|stroke|anaphylaxis|ambulance/i.test(
            reply
          ) ||
          /chest pain|difficulty breathing|unconscious|severe bleeding|stroke|గుండెనొప్పి|శ్వాస|చాతీ|सीने में दर्द|सांस/i.test(message);

        return res.json({
          reply,
          isEmergency,
          expertType,
          language: activeTargetLanguage,
          disclaimer: STANDARD_DISCLAIMER,
        });
      } catch (geminiErr) {
        console.warn('Gemini chat error, falling back to smart educational response:', geminiErr);
      }
    }

    // Local smart educational fallback in native languages
    const isEmergency =
      /chest pain|heart attack|can't breathe|difficulty breathing|stroke|suicide|overdose|unconscious|గుండె|శ్వాస|రక్తం|सीने में दर्द|दिल का दौरा/i.test(
        message
      );

    let reply = '';
    const isTelugu = activeTargetLanguage === 'Telugu' || /[\u0C00-\u0C7F]/.test(message);
    const isHindi = activeTargetLanguage === 'Hindi' || /[\u0900-\u097F]/.test(message);
    const isTamil = activeTargetLanguage === 'Tamil' || /[\u0B80-\u0BFF]/.test(message);

    if (isEmergency) {
      if (isTelugu) {
        reply = `🚨 **అత్యవసర హెచ్చరిక (URGENT EMERGENCY ALERT)**
మీరు లేదా మీ సమీపంలో ఉన్నవారు తీవ్రమైన గుండెనొప్పి, శ్వాస తీసుకోవడంలో ఇబ్బంది, అకస్మాత్తుగా స్పృహ కోల్పోవడం లేదా పక్షవాతం లక్షణాలను ఎదుర్కొంటుంటే, **వెంటనే స్థానిక అత్యవసర సేవలైన 108 / 112 లేదా సమీప అత్యవసర ఆసుపత్రికి వెళ్ళండి**. ఆన్‌లైన్ సమాధానాల కోసం వేచి ఉండకండి.`;
      } else if (isHindi) {
        reply = `🚨 **आपातकालीन सूचना (URGENT EMERGENCY ALERT)**
यदि आप या आपके आसपास कोई गंभीर सीने में दर्द, सांस लेने में तकलीफ, बेहोशी या स्ट्रोक के लक्षणों का अनुभव कर रहा है, तो **तुरंत आपातकालीन नंबर 108 / 112 पर कॉल करें या निकटतम अस्पताल के इमरजेंसी विभाग में जाएं**।`;
      } else {
        reply = `🚨 **URGENT EMERGENCY NOTICE**
If you or someone nearby is experiencing severe chest pressure, sudden numbness/paralysis, severe breathing distress, severe bleeding, or sudden confusion, **call your local emergency medical services (such as 911 / 112 / 108) or proceed to the nearest emergency department immediately**. Do not wait for website answers.`;
      }
    } else if (isTelugu) {
      if (message.includes('జ్వరం') || message.toLowerCase().includes('fever')) {
        reply = `**ఆరోగ్య విద్యా సమాచారం: జ్వరం (Fever)**

జ్వరం అనేది మన శరీరం ఇన్ఫెక్షన్లతో లేదా వైరస్‌లతో పోరాడుతున్నప్పుడు రోగనిరోధక వ్యవస్థ చూపే సహజమైన ప్రతిస్పందన.

**సాధారణ కారణాలు:**
1. వైరల్ లేదా బ్యాక్టీరియల్ ఇన్ఫెక్షన్లు (ఉదాహరణకు ఫ్లూ, డెంగ్యూ, టైఫాయిడ్ లేదా జలుబు)
2. శారీరక వాపు లేదా వాతావరణ మార్పులు
3. డీహైడ్రేషన్ లేదా అలసట

**ముఖ్యమైన జాగ్రత్తలు:**
- పుష్కలంగా ద్రవాలు (నీరు, ఓఆర్ఎస్, కొబ్బరి నీళ్ళు) తీసుకోండి.
- తగినంత విశ్రాంతి తీసుకోండి.
- వైద్యుడి సలహా లేకుండా యాంటీబయాటిక్స్ వాడకండి.

⚠️ **ఎప్పుడు వైద్యుడిని సంప్రదించాలి?**
జ్వరం 102°F కన్నా ఎక్కువగా ఉన్నా, 3 రోజుల కంటే ఎక్కువ కాలం కొనసాగినా, విపరీతమైన తలనొప్పి, శ్వాసలో ఇబ్బంది లేదా వాంతులు ఉంటే వెంటనే అర్హత కలిగిన వైద్యుడిని సంప్రదించండి.

*గమనిక: ఈ సమాచారం విద్య మరియు అవగాహన కోసం మాత్రమే, ఇది వైద్య నిర్ధారణ కాదు.*`;
      } else {
        reply = `**ఆరోగ్య విద్యా సమాధానం: "${message.trim()}"**

మీ ప్రశ్నకు సంబంధించి వైద్య మార్గదర్శకాల ప్రకారం వివరాలు:
1. **ముఖ్య అవగాహన:** శరీరంలో ఏవైనా లక్షణాలు లేదా సందేహాలు ఉన్నప్పుడు, రక్త పరీక్షలు లేదా శారీరక పరీక్షల ద్వారా సరైన మూల కారణాన్ని గుర్తించడం ముఖ్యం.
2. **మందుల వాడకం:** వైద్యుడి లేదా ఫార్మసిస్ట్ సూచన మేరకే మందులను ఉపయోగించాలి. స్వంత వైద్యం చేసుకోకూడదు.
3. **సలహా:** ఖచ్చితమైన నిర్ధారణ మరియు చికిత్స కోసం మీ సమీప వైద్యుడిని సంప్రదించండి.

*గమనిక: DRUGAI-LAB అందించే సమాచారం అవగాహన కోసం మాత్రమే. అత్యవసర పరిస్థితుల్లో వెంటనే 108 / 112 కు కాల్ చేయండి.*`;
      }
    } else if (isHindi) {
      reply = `**स्वास्थ्य शिक्षा जानकारी: "${message.trim()}"**

चिकित्सा विशेषज्ञों और स्वास्थ्य दिशानिर्देशों के अनुसार:
1. **मूल बिंदु:** किसी भी लक्षण या स्वास्थ्य विषय को समझने के लिए उचित शारीरिक जांच और परीक्षण आवश्यक होते हैं।
2. **दवाओं की सावधानी:** बिना डॉक्टर या फार्मासिस्ट की सलाह के कोई भी नई दवा शुरू या बंद न करें।
3. **अगला कदम:** अपनी व्यक्तिगत स्वास्थ्य स्थिति के लिए योग्य चिकित्सक से परामर्श लें।

*नोट: यह जानकारी केवल शैक्षिक जागरूकता के लिए है और डॉक्टर की सलाह का विकल्प नहीं है।*`;
    } else if (beginnerMode) {
      reply = `**Educational Explanation (Simple Terms):**

Thank you for your question regarding **"${message.trim()}"**.

Here is how doctors and scientists explain it simply:
- **What it is:** Think of the body like a finely tuned engine. When this topic is discussed, it refers to how specific cells, organs, or medications interact to maintain balance.
- **Why it matters:** Understanding this helps individuals recognize normal body functions versus signs that warrant medical evaluation.
- **Safe Next Step:** Always consult your physician or licensed pharmacist for personalized evaluation and care.

*Disclaimer: This information is for general education and does not replace medical advice.*`;
    } else {
      reply = `**Educational Summary on: "${message.trim()}"**

According to trusted public health guidelines (WHO, CDC, MedlinePlus):
1. **Core Concept:** Medical science evaluates this based on clinical trials, physiological markers, and evidence-based clinical protocols.
2. **Key Considerations:** Individual factors such as medical history, existing medications, renal and liver function significantly influence health outcomes.
3. **Recommended Consultation:** Please discuss your specific situation with a qualified healthcare professional who can review your personal records.

*${STANDARD_DISCLAIMER}*`;
    }

    return res.json({
      reply,
      isEmergency,
      expertType,
      language: activeTargetLanguage,
      disclaimer: STANDARD_DISCLAIMER,
    });
  } catch (error: any) {
    console.error('Chat endpoint error:', error);
    res.status(500).json({ error: 'Failed to process assistant query.' });
  }
});

// 3. Google Maps Places (New) Nearby Facilities Proxy Endpoint
app.post('/api/maps/places-nearby', async (req, res) => {
  try {
    const { lat, lng, radius = 5000, facilityType = 'hospital', query } = req.body;
    const apiKey = process.env.GOOGLE_MAPS_API_KEY || process.env.VITE_GOOGLE_MAPS_API_KEY;

    if (!apiKey) {
      return res.status(500).json({ error: 'Google Maps API key not configured' });
    }

    const fieldMask = [
      'places.id',
      'places.displayName',
      'places.formattedAddress',
      'places.location',
      'places.nationalPhoneNumber',
      'places.internationalPhoneNumber',
      'places.types',
      'places.googleMapsUri',
      'places.regularOpeningHours',
      'places.rating',
      'places.userRatingCount',
      'places.businessStatus',
    ].join(',');

    let apiUrl = '';
    let requestPayload: any = {};

    if (query && query.trim()) {
      // Text Search with Places API (New)
      apiUrl = 'https://places.googleapis.com/v1/places:searchText';
      requestPayload = {
        textQuery: `${facilityType} in ${query.trim()}`,
        maxResultCount: 15,
        locationBias: lat && lng ? {
          circle: {
            center: { latitude: Number(lat), longitude: Number(lng) },
            radius: Number(radius),
          },
        } : undefined,
      };
    } else if (lat && lng) {
      // Nearby Search with Places API (New)
      apiUrl = 'https://places.googleapis.com/v1/places:searchNearby';
      let includedTypes = ['hospital'];
      if (facilityType === 'clinic') includedTypes = ['medical_clinic', 'doctor'];
      else if (facilityType === 'pharmacy') includedTypes = ['pharmacy', 'drugstore'];
      else if (facilityType === 'emergency') includedTypes = ['hospital'];

      requestPayload = {
        includedTypes,
        maxResultCount: 15,
        locationRestriction: {
          circle: {
            center: { latitude: Number(lat), longitude: Number(lng) },
            radius: Number(radius),
          },
        },
      };
    } else {
      return res.status(400).json({ error: 'Coordinates or search query required.' });
    }

    const gmpRes = await fetch(apiUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Goog-Api-Key': apiKey,
        'X-Goog-FieldMask': fieldMask,
        'X-Goog-Maps-Solution-ID': 'gmp_mcp_codeassist_v1_aistudio',
      },
      body: JSON.stringify(requestPayload),
    });

    if (gmpRes.status === 429) {
      return res.status(429).json({
        quotaExceeded: true,
        error: 'RESOURCE_EXHAUSTED',
        message: 'Google Maps Platform quota reached.',
      });
    }

    if (!gmpRes.ok) {
      const errText = await gmpRes.text();
      console.warn('Google Places API response error:', gmpRes.status, errText);
      return res.status(gmpRes.status).json({ error: 'Places API error', details: errText });
    }

    const data = await gmpRes.json();
    return res.json({
      places: data.places || [],
      attribution: 'gmp_mcp_codeassist_v1_aistudio',
    });
  } catch (error: any) {
    console.error('Nearby places proxy error:', error);
    res.status(500).json({ error: 'Failed to retrieve nearby healthcare places.' });
  }
});

// 4. Google Maps Geocoding Proxy Endpoint
app.post('/api/maps/geocode', async (req, res) => {
  try {
    const { address } = req.body;
    const apiKey = process.env.GOOGLE_MAPS_API_KEY || process.env.VITE_GOOGLE_MAPS_API_KEY;

    if (!address || typeof address !== 'string') {
      return res.status(400).json({ error: 'Address string is required.' });
    }

    if (!apiKey) {
      return res.status(500).json({ error: 'Google Maps API key not configured' });
    }

    const geocodeUrl = `https://maps.googleapis.com/maps/api/geocode/json?address=${encodeURIComponent(
      address
    )}&key=${apiKey}`;

    const geoRes = await fetch(geocodeUrl);
    if (geoRes.status === 429) {
      return res.status(429).json({ quotaExceeded: true, error: 'OVER_QUERY_LIMIT' });
    }

    const geoData = await geoRes.json();
    if (geoData.status === 'OVER_QUERY_LIMIT') {
      return res.status(429).json({ quotaExceeded: true, error: 'OVER_QUERY_LIMIT' });
    }

    return res.json(geoData);
  } catch (error: any) {
    console.error('Geocoding error:', error);
    res.status(500).json({ error: 'Failed to geocode address' });
  }
});

// 5. Google Maps Client Configuration Endpoint
app.get('/api/config/maps', (req, res) => {
  const key = process.env.VITE_GOOGLE_MAPS_API_KEY || process.env.GOOGLE_MAPS_API_KEY || '';
  res.json({
    apiKey: key,
    hasKey: Boolean(key),
    demoKeyConfigured: key.startsWith('AIzaSy'),
  });
});

// 6. Health & Status Check
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    service: 'DRUGAI-LAB API',
    aiEnabled: Boolean(ai),
    mapsConfigured: Boolean(process.env.VITE_GOOGLE_MAPS_API_KEY || process.env.GOOGLE_MAPS_API_KEY),
    timestamp: new Date().toISOString(),
  });
});

// In development, hook Vite middleware; in production, serve built dist files
async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, () => {
    console.log(`DRUGAI-LAB server running on port ${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
});
