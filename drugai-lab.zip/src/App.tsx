/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { AuthProvider } from './context/AuthContext';
import { LanguageProvider } from './context/LanguageContext';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { EmergencyModal } from './components/EmergencyModal';
import { SearchModal } from './components/SearchModal';
import { MedicalBackground } from './components/MedicalBackground';

// Pages
import { Home } from './pages/Home';
import { DrugInteractionChecker } from './pages/DrugInteractionChecker';
import { DiseaseExplorer } from './pages/DiseaseExplorer';
import { DiseaseDetail } from './pages/DiseaseDetail';
import { MedicineExplorer } from './pages/MedicineExplorer';
import { MedicineDetail } from './pages/MedicineDetail';
import { DrugAwarenessCenter } from './pages/DrugAwarenessCenter';
import { MedicineCategories } from './pages/MedicineCategories';
import { AiHealthAssistant } from './pages/AiHealthAssistant';
import { AiVoiceAssistant } from './pages/AiVoiceAssistant';
import { AiHealthExperts } from './pages/AiHealthExperts';
import { StudentHub } from './pages/StudentHub';
import { DoctorHub } from './pages/DoctorHub';
import { EmergencyNearMe } from './pages/EmergencyNearMe';
import { HealthArticles } from './pages/HealthArticles';
import { ArticleDetail } from './pages/ArticleDetail';
import { Dashboard } from './pages/Dashboard';
import { AdminDashboard } from './pages/AdminDashboard';
import { SourcesAndReferences } from './pages/SourcesAndReferences';
import {
  MedicalDisclaimerPage,
  PrivacyPolicyPage,
  TermsOfUsePage,
  AboutPage,
  ContactPage,
} from './pages/LegalPages';
import { AuthPages } from './pages/AuthPages';

export default function App() {
  const [currentTab, setCurrentTab] = useState<string>('home');
  const [selectedDiseaseId, setSelectedDiseaseId] = useState<string>('hypertension');
  const [selectedMedicineId, setSelectedMedicineId] = useState<string>('paracetamol');
  const [selectedArticleId, setSelectedArticleId] = useState<string>('antibiotic-resistance-crisis');

  const [emergencyModalOpen, setEmergencyModalOpen] = useState(false);
  const [searchModalOpen, setSearchModalOpen] = useState(false);
  const [gmpQuotaExceeded, setGmpQuotaExceeded] = useState(false);

  // Listen for Google Maps quota exceeded event
  useEffect(() => {
    const handleQuota = () => setGmpQuotaExceeded(true);
    window.addEventListener('gmp-quota-exceeded', handleQuota);
    return () => window.removeEventListener('gmp-quota-exceeded', handleQuota);
  }, []);

  // Keyboard shortcut: '/' opens search
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === '/' && !searchModalOpen && (e.target as HTMLElement).tagName !== 'INPUT') {
        e.preventDefault();
        setSearchModalOpen(true);
      }
      if (e.key === 'Escape') {
        setSearchModalOpen(false);
        setEmergencyModalOpen(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [searchModalOpen]);

  const handleNavigate = (tab: string, param?: string) => {
    window.scrollTo({ top: 0, behavior: 'smooth' });

    if (tab === 'disease-detail' && param) {
      setSelectedDiseaseId(param);
    } else if (tab === 'medicine-detail' && param) {
      setSelectedMedicineId(param);
    } else if (tab === 'article-detail' && param) {
      setSelectedArticleId(param);
    }

    setCurrentTab(tab);
  };

  const renderContent = () => {
    switch (currentTab) {
      case 'home':
        return (
          <Home
            onNavigate={handleNavigate}
            onOpenEmergency={() => setEmergencyModalOpen(true)}
            onOpenSearch={() => setSearchModalOpen(true)}
          />
        );
      case 'interactions':
        return <DrugInteractionChecker />;
      case 'diseases':
        return (
          <DiseaseExplorer
            onSelectDisease={(id) => handleNavigate('disease-detail', id)}
          />
        );
      case 'disease-detail':
        return (
          <DiseaseDetail
            diseaseId={selectedDiseaseId}
            onBack={() => handleNavigate('diseases')}
            onNavigateToMedicine={(id) => handleNavigate('medicine-detail', id)}
            onOpenEmergency={() => setEmergencyModalOpen(true)}
          />
        );
      case 'medicines':
        return (
          <MedicineExplorer
            onSelectMedicine={(id) => handleNavigate('medicine-detail', id)}
            onCheckInteraction={(medName) => handleNavigate('interactions', medName)}
          />
        );
      case 'medicine-detail':
        return (
          <MedicineDetail
            medicineId={selectedMedicineId}
            onBack={() => handleNavigate('medicines')}
            onCheckInteractionsWith={(name) => handleNavigate('interactions', name)}
          />
        );
      case 'awareness':
        return (
          <DrugAwarenessCenter
            onCheckInteraction={(med) => handleNavigate('interactions', med)}
          />
        );
      case 'categories':
        return <MedicineCategories />;
      case 'ai-assistant':
        return (
          <AiHealthAssistant onOpenEmergency={() => setEmergencyModalOpen(true)} />
        );
      case 'ai-voice':
        return (
          <AiVoiceAssistant onOpenEmergency={() => setEmergencyModalOpen(true)} />
        );
      case 'ai-experts':
        return <AiHealthExperts />;
      case 'student-hub':
        return <StudentHub />;
      case 'doctor-hub':
        return (
          <DoctorHub onNavigateToInteractions={() => handleNavigate('interactions')} />
        );
      case 'emergency-near-me':
        return <EmergencyNearMe />;
      case 'articles':
        return (
          <HealthArticles
            onSelectArticle={(id) => handleNavigate('article-detail', id)}
          />
        );
      case 'article-detail':
        return (
          <ArticleDetail
            articleId={selectedArticleId}
            onBack={() => handleNavigate('articles')}
          />
        );
      case 'dashboard':
      case 'bookmarks':
        return <Dashboard onNavigate={handleNavigate} />;
      case 'admin':
        return <AdminDashboard />;
      case 'sources':
        return <SourcesAndReferences />;
      case 'disclaimer':
        return <MedicalDisclaimerPage />;
      case 'privacy':
        return <PrivacyPolicyPage />;
      case 'terms':
        return <TermsOfUsePage />;
      case 'about':
        return <AboutPage />;
      case 'contact':
        return <ContactPage />;
      case 'login':
      case 'register':
        return (
          <AuthPages
            initialMode={currentTab === 'register' ? 'register' : 'login'}
            onSuccess={() => handleNavigate('dashboard')}
          />
        );
      default:
        return (
          <Home
            onNavigate={handleNavigate}
            onOpenEmergency={() => setEmergencyModalOpen(true)}
            onOpenSearch={() => setSearchModalOpen(true)}
          />
        );
    }
  };

  return (
    <AuthProvider>
      <LanguageProvider>
        <div className="min-h-screen flex flex-col font-sans bg-transparent text-slate-900 dark:text-slate-100 transition-colors duration-300 relative">
          {/* Advanced Realistic Medical Background Layer */}
          <MedicalBackground />

          {/* Google Maps Quota Warning Banner (Section 8 Case A) */}
          {gmpQuotaExceeded && (
            <div className="bg-amber-50 border-b border-amber-200 text-amber-900 px-4 py-2.5 text-xs md:text-sm text-center sticky top-0 z-50 shadow-sm">
              <span>
                Google Maps Platform quota reached. If you are the app owner, visit{' '}
                <a
                  href="https://developers.google.com/maps/ai/ai-studio?utm_campaign=gmp_mcp_codeassist_v1_aistudio#quota_exceeded_errors"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="underline font-semibold text-amber-950 hover:text-amber-800"
                >
                  maps developer site
                </a>{' '}
                for instructions to update your account.
              </span>
            </div>
          )}

          {/* Main Top Header */}
          <Navbar
            currentTab={currentTab}
            onNavigate={handleNavigate}
            onOpenEmergency={() => setEmergencyModalOpen(true)}
            onOpenSearch={() => setSearchModalOpen(true)}
          />

          {/* Body Content */}
          <main className="flex-1">{renderContent()}</main>

          {/* Footer */}
          <Footer
            onNavigate={handleNavigate}
            onOpenEmergency={() => setEmergencyModalOpen(true)}
          />

          {/* Modals */}
          <EmergencyModal
            isOpen={emergencyModalOpen}
            onClose={() => setEmergencyModalOpen(false)}
            onNavigateToHospitals={() => {
              setEmergencyModalOpen(false);
              handleNavigate('emergency-near-me');
            }}
          />

          <SearchModal
            isOpen={searchModalOpen}
            onClose={() => setSearchModalOpen(false)}
            onSelect={(type, id) => {
              if (type === 'disease' && id) handleNavigate('disease-detail', id);
              else if (type === 'medicine' && id) handleNavigate('medicine-detail', id);
              else if (type === 'article' && id) handleNavigate('article-detail', id);
              else if (type === 'interactions') handleNavigate('interactions');
            }}
          />
        </div>
      </LanguageProvider>
    </AuthProvider>
  );
}
