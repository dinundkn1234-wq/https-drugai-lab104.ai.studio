import React from 'react';
import { AlertTriangle, PhoneCall, ShieldAlert, MapPin, X, HeartPulse, Clock } from 'lucide-react';

interface EmergencyModalProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigateToHospitals: () => void;
}

export const EmergencyModal: React.FC<EmergencyModalProps> = ({
  isOpen,
  onClose,
  onNavigateToHospitals,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-2xl bg-white dark:bg-slate-900 border-2 border-red-500 rounded-2xl shadow-2xl overflow-hidden p-6 md:p-8">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          aria-label="Close Emergency Window"
        >
          <X className="w-6 h-6" />
        </button>

        {/* Top Emergency Badge */}
        <div className="flex items-center gap-3 text-red-600 dark:text-red-400 mb-4">
          <div className="p-3 bg-red-100 dark:bg-red-950/60 rounded-xl">
            <ShieldAlert className="w-8 h-8 animate-pulse text-red-600" />
          </div>
          <div>
            <span className="text-xs font-bold uppercase tracking-wider bg-red-100 dark:bg-red-950 text-red-700 dark:text-red-300 px-2 py-0.5 rounded">
              CRITICAL EMERGENCY PROTOCOL
            </span>
            <h2 className="text-xl md:text-2xl font-extrabold text-slate-900 dark:text-white mt-0.5">
              Immediate Emergency Guidance
            </h2>
          </div>
        </div>

        {/* Main Urgent Callout */}
        <div className="p-4 md:p-5 bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-800 rounded-xl mb-6">
          <p className="text-base md:text-lg font-bold text-red-900 dark:text-red-200 leading-snug">
            “If you or someone nearby is experiencing a life-threatening emergency, contact your local emergency services immediately or go to the nearest emergency department.”
          </p>
          <p className="text-xs text-red-700 dark:text-red-300 mt-2">
            Do not wait for website responses or attempt self-treatment for acute medical crises.
          </p>
        </div>

        {/* Immediate Call Grid */}
        <div className="mb-6">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-2">
            Direct Emergency Helplines (Tap to Call)
          </h3>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
            <a
              href="tel:911"
              className="flex flex-col items-center justify-center p-3 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold transition-all shadow-md hover:scale-[1.02]"
            >
              <PhoneCall className="w-5 h-5 mb-1" />
              <span className="text-lg">911</span>
              <span className="text-[10px] font-normal opacity-90">USA / Canada</span>
            </a>
            <a
              href="tel:112"
              className="flex flex-col items-center justify-center p-3 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold transition-all shadow-md hover:scale-[1.02]"
            >
              <PhoneCall className="w-5 h-5 mb-1" />
              <span className="text-lg">112</span>
              <span className="text-[10px] font-normal opacity-90">Europe / Global GSM</span>
            </a>
            <a
              href="tel:108"
              className="flex flex-col items-center justify-center p-3 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold transition-all shadow-md hover:scale-[1.02]"
            >
              <PhoneCall className="w-5 h-5 mb-1" />
              <span className="text-lg">108 / 102</span>
              <span className="text-[10px] font-normal opacity-90">India Ambulance</span>
            </a>
            <a
              href="tel:999"
              className="flex flex-col items-center justify-center p-3 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold transition-all shadow-md hover:scale-[1.02]"
            >
              <PhoneCall className="w-5 h-5 mb-1" />
              <span className="text-lg">999</span>
              <span className="text-[10px] font-normal opacity-90">UK / Singapore</span>
            </a>
          </div>
        </div>

        {/* Life Threatening Signs Checklist */}
        <div className="bg-slate-50 dark:bg-slate-800/60 p-4 rounded-xl border border-slate-200 dark:border-slate-700 mb-6">
          <h4 className="text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-2 flex items-center gap-1.5">
            <HeartPulse className="w-4 h-4 text-red-500" />
            Red-Flag Signs Requiring Instant 911 / Emergency Care:
          </h4>
          <ul className="text-xs space-y-1.5 text-slate-600 dark:text-slate-300">
            <li className="flex items-start gap-2">
              <span className="text-red-500 font-bold">•</span>
              <span><strong>Crushing chest pressure</strong> or pain radiating to left arm, neck, back, or jaw.</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-red-500 font-bold">•</span>
              <span><strong>Stroke Signs (F.A.S.T.):</strong> Sudden facial droop, arm weakness, slurred speech.</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-red-500 font-bold">•</span>
              <span><strong>Severe Breathing Distress:</strong> Gasping for air, blue/cyanotic lips or fingernails.</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-red-500 font-bold">•</span>
              <span><strong>Loss of Consciousness</strong>, sudden unresponsiveness, or uncontrollable seizures.</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-red-500 font-bold">•</span>
              <span><strong>Severe Allergic Reaction (Anaphylaxis):</strong> Swelling of throat, hives, collapse.</span>
            </li>
          </ul>
        </div>

        {/* Actions Footer */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
          <button
            onClick={() => {
              onClose();
              onNavigateToHospitals();
            }}
            className="w-full sm:w-auto flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-teal-600 hover:bg-teal-700 text-white font-semibold text-sm transition-colors shadow-sm"
          >
            <MapPin className="w-4 h-4" />
            Find Nearest Emergency Hospitals & ERs
          </button>
          <button
            onClick={onClose}
            className="w-full sm:w-auto px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 text-sm font-medium transition-colors"
          >
            I Understand, Dismiss
          </button>
        </div>
      </div>
    </div>
  );
};
