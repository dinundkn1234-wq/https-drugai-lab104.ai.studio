import React from 'react';
import { Activity, ShieldCheck, HeartPulse, ExternalLink, ShieldAlert } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

interface FooterProps {
  onNavigate: (tab: string) => void;
  onOpenEmergency: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate, onOpenEmergency }) => {
  const { t } = useLanguage();

  return (
    <footer className="bg-slate-900 text-slate-400 border-t border-slate-800 text-xs">
      {/* Top Clinical Safety Callout */}
      <div className="bg-slate-950 border-b border-slate-800/80 py-4 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-teal-950/80 text-teal-400 border border-teal-800">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <p className="text-slate-200 font-semibold text-xs">
                Clinical Educational Integrity & Responsible AI Protocol
              </p>
              <p className="text-slate-400 text-[11px]">
                Grounding health knowledge in peer-reviewed clinical guidelines, public pharmacopeias, and emergency triage protocols.
              </p>
            </div>
          </div>
          <button
            onClick={onOpenEmergency}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-red-600/90 hover:bg-red-600 text-white font-bold transition-colors whitespace-nowrap shadow-sm"
          >
            <ShieldAlert className="w-4 h-4 text-amber-300" />
            <span>Emergency Services Directory &rarr;</span>
          </button>
        </div>
      </div>

      {/* Main Footer Links */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 grid grid-cols-2 md:grid-cols-5 gap-8">
        {/* Brand Column */}
        <div className="col-span-2">
          <div className="flex items-center gap-2 mb-3 cursor-pointer" onClick={() => onNavigate('home')}>
            <div className="w-8 h-8 rounded-lg bg-teal-600 flex items-center justify-center text-white font-black">
              <Activity className="w-5 h-5" />
            </div>
            <span className="text-lg font-extrabold text-white tracking-tight">
              DRUGAI<span className="text-teal-400">-LAB</span>
            </span>
          </div>
          <p className="text-slate-400 text-xs leading-relaxed mb-4 max-w-sm">
            “AI-Powered Health Knowledge, Medicine Awareness & Emergency Support.” Empowering students, patients, doctors, researchers, and the general public with verified medical education.
          </p>
          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-[11px] text-slate-400 leading-normal">
            <strong className="text-slate-200">Legal Medical Disclaimer:</strong> DRUGAI-LAB provides general health and medicine information for educational purposes only. Not a diagnosis, prescription, or clinical substitute. In an emergency, contact local emergency services immediately.
          </div>
        </div>

        {/* Clinical Databases */}
        <div>
          <h4 className="text-white font-bold text-xs uppercase tracking-wider mb-3">Medical Databases</h4>
          <ul className="space-y-2">
            <li>
              <button onClick={() => onNavigate('interactions')} className="hover:text-teal-400 transition-colors">
                Drug Interaction Checker
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate('medicines')} className="hover:text-teal-400 transition-colors">
                Medicine Explorer
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate('diseases')} className="hover:text-teal-400 transition-colors">
                Disease Database
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate('categories')} className="hover:text-teal-400 transition-colors">
                Medicine Categories
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate('awareness')} className="hover:text-teal-400 transition-colors">
                Drug Safety & Awareness
              </button>
            </li>
          </ul>
        </div>

        {/* AI & Hubs */}
        <div>
          <h4 className="text-white font-bold text-xs uppercase tracking-wider mb-3">AI & Professional</h4>
          <ul className="space-y-2">
            <li>
              <button onClick={() => onNavigate('ai-assistant')} className="hover:text-teal-400 transition-colors">
                DRUGAI Health Assistant
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate('ai-voice')} className="hover:text-teal-400 transition-colors">
                Voice AI Assistant
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate('ai-experts')} className="hover:text-teal-400 transition-colors">
                AI Health Experts (8 Personas)
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate('student-hub')} className="hover:text-teal-400 transition-colors">
                Student Learning Hub
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate('doctor-hub')} className="hover:text-teal-400 transition-colors">
                Doctor / Clinician Hub
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate('emergency-near-me')} className="hover:text-red-400 transition-colors">
                Emergency Near Me
              </button>
            </li>
          </ul>
        </div>

        {/* Institutional Sources & Trust */}
        <div>
          <h4 className="text-white font-bold text-xs uppercase tracking-wider mb-3">Evidence Sources</h4>
          <ul className="space-y-2">
            <li>
              <a href="https://www.who.int" target="_blank" rel="noopener noreferrer" className="hover:text-teal-400 flex items-center gap-1">
                World Health Organization (WHO) <ExternalLink className="w-3 h-3 text-slate-600" />
              </a>
            </li>
            <li>
              <a href="https://www.fda.gov" target="_blank" rel="noopener noreferrer" className="hover:text-teal-400 flex items-center gap-1">
                U.S. FDA Drug Information <ExternalLink className="w-3 h-3 text-slate-600" />
              </a>
            </li>
            <li>
              <a href="https://www.cdc.gov" target="_blank" rel="noopener noreferrer" className="hover:text-teal-400 flex items-center gap-1">
                Centers for Disease Control (CDC) <ExternalLink className="w-3 h-3 text-slate-600" />
              </a>
            </li>
            <li>
              <a href="https://medlineplus.gov" target="_blank" rel="noopener noreferrer" className="hover:text-teal-400 flex items-center gap-1">
                NIH MedlinePlus <ExternalLink className="w-3 h-3 text-slate-600" />
              </a>
            </li>
            <li>
              <button onClick={() => onNavigate('sources')} className="hover:text-teal-400 transition-colors">
                All References & Sources
              </button>
            </li>
          </ul>
        </div>
      </div>

      {/* Bottom Legal bar */}
      <div className="border-t border-slate-800 py-6 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-slate-500">
          <div>
            &copy; 2026 DRUGAI-LAB. All Rights Reserved. Built for global healthcare literacy and safety.
          </div>
          <div className="flex flex-wrap items-center gap-4">
            <button onClick={() => onNavigate('privacy')} className="hover:text-slate-300">Privacy Policy</button>
            <button onClick={() => onNavigate('terms')} className="hover:text-slate-300">Terms of Use</button>
            <button onClick={() => onNavigate('disclaimer')} className="hover:text-slate-300">Medical Disclaimer</button>
            <button onClick={() => onNavigate('about')} className="hover:text-slate-300">About DRUGAI-LAB</button>
            <button onClick={() => onNavigate('contact')} className="hover:text-slate-300">Contact</button>
          </div>
        </div>
      </div>
    </footer>
  );
};
