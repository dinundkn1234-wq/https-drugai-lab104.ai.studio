import React from 'react';

export const MedicalBackground: React.FC = () => {
  return (
    <div
      aria-hidden="true"
      className="fixed inset-0 pointer-events-none -z-10 overflow-hidden select-none transition-opacity duration-700"
    >
      {/* 1. Base Gradient Canvas */}
      <div className="absolute inset-0 bg-slate-50/90 dark:bg-[#030712] transition-colors duration-500" />

      {/* 2. Precision Micro-Grid & Dot Matrix Architecture */}
      <div
        className="absolute inset-0 opacity-[0.45] dark:opacity-[0.25]"
        style={{
          backgroundImage: `
            radial-gradient(circle at center, rgba(13, 148, 136, 0.18) 1px, transparent 1px)
          `,
          backgroundSize: '28px 28px',
          backgroundPosition: '0 0',
        }}
      />

      {/* 3. Subtle Technical Blueprint Line Mesh */}
      <div
        className="absolute inset-0 opacity-[0.2] dark:opacity-[0.12]"
        style={{
          backgroundImage: `
            linear-gradient(to right, rgba(14, 165, 233, 0.08) 1px, transparent 1px),
            linear-gradient(to bottom, rgba(14, 165, 233, 0.08) 1px, transparent 1px)
          `,
          backgroundSize: '112px 112px',
        }}
      />

      {/* 4. Ambient Bioluminescent Glow Orbs */}
      {/* Top Left: Clinical Emerald / Teal Vitality Glow */}
      <div
        className="absolute -top-[12%] -left-[8%] w-[650px] h-[650px] rounded-full blur-[120px] transition-all duration-700
          bg-gradient-to-br from-teal-400/20 via-emerald-400/10 to-transparent
          dark:from-teal-500/25 dark:via-cyan-600/15 dark:to-transparent"
      />

      {/* Top Right: Sky Blue Medical Research Glow */}
      <div
        className="absolute -top-[10%] -right-[10%] w-[600px] h-[600px] rounded-full blur-[130px] transition-all duration-700
          bg-gradient-to-bl from-sky-400/20 via-cyan-300/10 to-transparent
          dark:from-blue-600/20 dark:via-cyan-500/15 dark:to-transparent"
      />

      {/* Center Depth: Soft Stabilizing Aura */}
      <div
        className="absolute top-[40%] left-[25%] w-[800px] h-[500px] rounded-full blur-[150px] transition-all duration-700
          bg-gradient-to-r from-teal-200/15 via-indigo-100/10 to-transparent
          dark:from-teal-900/15 dark:via-indigo-950/20 dark:to-transparent"
      />

      {/* Bottom Center: Deep Anchor Atmosphere */}
      <div
        className="absolute -bottom-[15%] left-[10%] w-[900px] h-[550px] rounded-full blur-[140px] transition-all duration-700
          bg-gradient-to-t from-slate-200/40 via-teal-100/15 to-transparent
          dark:from-slate-900/40 dark:via-cyan-950/15 dark:to-transparent"
      />

      {/* 5. Realistic ECG / Biomedical Telemetry Frequency Wave */}
      <div className="absolute inset-x-0 top-[220px] opacity-[0.06] dark:opacity-[0.10] overflow-hidden">
        <svg
          viewBox="0 0 1600 120"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="w-full h-24 stroke-teal-600 dark:stroke-cyan-400"
          preserveAspectRatio="none"
        >
          <path
            d="M0,60 L240,60 L255,45 L270,75 L285,60 L420,60 L435,20 L450,105 L465,50 L480,70 L495,60 L780,60 L795,45 L810,75 L825,60 L960,60 L975,15 L990,110 L1005,45 L1020,70 L1035,60 L1320,60 L1335,45 L1350,75 L1365,60 L1600,60"
            strokeWidth="1.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      </div>

      {/* 6. Subtle Vignette Edge Mask */}
      <div className="absolute inset-0 bg-radial-[circle_at_center,transparent_60%,rgba(0,0,0,0.03)_100%] dark:bg-radial-[circle_at_center,transparent_60%,rgba(0,0,0,0.4)_100%]" />
    </div>
  );
};
