import React, { useState } from 'react';
import {
  Activity,
  ShieldAlert,
  Search,
  Globe,
  Sun,
  Moon,
  Menu,
  X,
  User,
  LogOut,
  Pill,
  BookOpen,
  Stethoscope,
  Bot,
  Mic,
  Bookmark,
  ChevronDown,
  Sparkles,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';
import { SupportedLanguage } from '../types';

interface NavbarProps {
  currentTab: string;
  onNavigate: (tab: string, param?: string) => void;
  onOpenEmergency: () => void;
  onOpenSearch: () => void;
}

const SUPPORTED_LANGUAGES: { code: SupportedLanguage; label: string; native: string }[] = [
  { code: 'Auto-Detect', label: 'Auto-Detect', native: 'ఆటో / स्वतः' },
  { code: 'English', label: 'English', native: 'English' },
  { code: 'Telugu', label: 'Telugu', native: 'తెలుగు' },
  { code: 'Hindi', label: 'Hindi', native: 'हिन्दी' },
  { code: 'Tamil', label: 'Tamil', native: 'தமிழ்' },
  { code: 'Kannada', label: 'Kannada', native: 'ಕನ್ನಡ' },
  { code: 'Malayalam', label: 'Malayalam', native: 'മലയാളം' },
  { code: 'Marathi', label: 'Marathi', native: 'मराठी' },
  { code: 'Bengali', label: 'Bengali', native: 'বাংলা' },
  { code: 'Gujarati', label: 'Gujarati', native: 'ગુજરાતી' },
  { code: 'Punjabi', label: 'Punjabi', native: 'ਪੰਜਾਬੀ' },
  { code: 'Urdu', label: 'Urdu', native: 'اردو' },
];

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  onNavigate,
  onOpenEmergency,
  onOpenSearch,
}) => {
  const { user, darkMode, toggleDarkMode, logout } = useAuth();
  const { language, setLanguage, t } = useLanguage();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [langDropdownOpen, setLangDropdownOpen] = useState(false);
  const [userDropdownOpen, setUserDropdownOpen] = useState(false);

  const navItems = [
    { id: 'home', label: 'Home' },
    { id: 'interactions', label: 'Interaction Checker', badge: 'AI Tool' },
    { id: 'medicines', label: 'Medicines' },
    { id: 'diseases', label: 'Diseases' },
    { id: 'awareness', label: 'Drug Awareness' },
    { id: 'ai-assistant', label: 'AI Assistant' },
    { id: 'ai-voice', label: 'Voice AI' },
    { id: 'ai-experts', label: 'Health Experts' },
    { id: 'student-hub', label: 'Student Hub' },
    { id: 'doctor-hub', label: 'Doctor Hub' },
    { id: 'emergency-near-me', label: 'Emergency Near Me' },
  ];

  return (
    <header className="sticky top-0 z-40 w-full bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 transition-colors">
      {/* Top Urgent Emergency Notification Bar */}
      <div className="bg-red-600 text-white text-[12px] font-semibold px-4 py-1.5 flex items-center justify-between shadow-inner">
        <div className="flex items-center gap-2 max-w-5xl mx-auto w-full">
          <ShieldAlert className="w-4 h-4 shrink-0 animate-pulse text-amber-200" />
          <span className="truncate">
            <strong>EMERGENCY NOTICE:</strong> {t('emergencyDisclaimer')}
          </span>
          <button
            onClick={onOpenEmergency}
            className="ml-auto underline whitespace-nowrap hover:text-amber-200 font-bold text-[11px] bg-red-700/80 px-2.5 py-0.5 rounded"
          >
            Immediate Help & Hotlines &rarr;
          </button>
        </div>
      </div>

      {/* Main Navbar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Brand */}
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => onNavigate('home')}>
            <div className="relative flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-tr from-teal-600 via-cyan-600 to-emerald-500 shadow-md shadow-teal-500/20 text-white font-black text-xl">
              <Activity className="w-6 h-6" />
              <span className="absolute -top-1 -right-1 flex h-2.5 w-2.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-400"></span>
              </span>
            </div>
            <div>
              <span className="text-xl font-extrabold tracking-tight bg-gradient-to-r from-slate-900 to-teal-800 dark:from-white dark:to-teal-300 bg-clip-text text-transparent">
                DRUGAI<span className="text-teal-600 dark:text-teal-400">-LAB</span>
              </span>
              <p className="text-[10px] font-medium text-slate-500 dark:text-slate-400 -mt-1 hidden sm:block tracking-wide">
                Clinical AI & Medicine Intelligence
              </p>
            </div>
          </div>

          {/* Center Navigation Links (Desktop) */}
          <nav className="hidden xl:flex items-center space-x-1">
            {navItems.slice(0, 7).map((item) => (
              <button
                key={item.id}
                onClick={() => onNavigate(item.id)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all relative ${
                  currentTab === item.id
                    ? 'text-teal-700 dark:text-teal-300 bg-teal-50 dark:bg-teal-950/60 shadow-sm'
                    : 'text-slate-700 dark:text-slate-300 hover:text-teal-600 dark:hover:text-teal-400 hover:bg-slate-100 dark:hover:bg-slate-800/60'
                }`}
              >
                {item.label}
                {item.badge && (
                  <span className="ml-1.5 px-1.5 py-0.2 text-[9px] font-bold bg-teal-100 dark:bg-teal-900 text-teal-800 dark:text-teal-200 rounded-full">
                    {item.badge}
                  </span>
                )}
              </button>
            ))}

            {/* Hubs dropdown */}
            <div className="relative group">
              <button className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800/60 transition-colors">
                <span>More Hubs</span>
                <ChevronDown className="w-3.5 h-3.5" />
              </button>
              <div className="absolute top-full left-0 mt-1 w-48 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-xl py-2 hidden group-hover:block animate-fade-in">
                <button
                  onClick={() => onNavigate('student-hub')}
                  className="w-full text-left px-4 py-2 text-xs font-medium text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-2"
                >
                  <BookOpen className="w-4 h-4 text-teal-600" /> Student Learning Hub
                </button>
                <button
                  onClick={() => onNavigate('doctor-hub')}
                  className="w-full text-left px-4 py-2 text-xs font-medium text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-2"
                >
                  <Stethoscope className="w-4 h-4 text-teal-600" /> Doctor & Clinician Hub
                </button>
                <button
                  onClick={() => onNavigate('emergency-near-me')}
                  className="w-full text-left px-4 py-2 text-xs font-medium text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/40 flex items-center gap-2"
                >
                  <ShieldAlert className="w-4 h-4" /> Emergency Near Me
                </button>
                <button
                  onClick={() => onNavigate('categories')}
                  className="w-full text-left px-4 py-2 text-xs font-medium text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-2"
                >
                  <Pill className="w-4 h-4 text-teal-600" /> Medicine Categories
                </button>
                <button
                  onClick={() => onNavigate('articles')}
                  className="w-full text-left px-4 py-2 text-xs font-medium text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-2"
                >
                  <Sparkles className="w-4 h-4 text-teal-600" /> Health Education Articles
                </button>
              </div>
            </div>
          </nav>

          {/* Right Action Tools: Search, Lang, Dark Mode, Emergency, Profile */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Universal Search trigger */}
            <button
              onClick={onOpenSearch}
              className="flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs text-slate-500 dark:text-slate-400 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors border border-slate-200/60 dark:border-slate-700/60"
              title="Search medicines, diseases, symptoms"
            >
              <Search className="w-3.5 h-3.5" />
              <span className="hidden md:inline font-normal">Search health...</span>
              <kbd className="hidden lg:inline text-[10px] bg-white dark:bg-slate-900 px-1.5 py-0.5 rounded border border-slate-300 dark:border-slate-700 font-mono">
                /
              </kbd>
            </button>

            {/* Language Selector */}
            <div className="relative">
              <button
                onClick={() => setLangDropdownOpen(!langDropdownOpen)}
                className="p-2 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors flex items-center gap-1 text-xs font-semibold"
                title="Select language"
              >
                <Globe className="w-4 h-4 text-teal-600 dark:text-teal-400" />
                <span className="hidden sm:inline">{language.slice(0, 3)}</span>
              </button>

              {langDropdownOpen && (
                <div className="absolute right-0 mt-2 w-48 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-2xl py-2 z-50 animate-fade-in max-h-80 overflow-y-auto">
                  <div className="px-3 py-1 text-[10px] font-bold uppercase text-slate-400 tracking-wider">
                    Select Language ({SUPPORTED_LANGUAGES.length})
                  </div>
                  {SUPPORTED_LANGUAGES.map((lang) => (
                    <button
                      key={lang.code}
                      onClick={() => {
                        setLanguage(lang.code);
                        setLangDropdownOpen(false);
                      }}
                      className={`w-full text-left px-3 py-1.5 text-xs flex items-center justify-between transition-colors ${
                        language === lang.code
                          ? 'bg-teal-50 dark:bg-teal-950 text-teal-700 dark:text-teal-300 font-bold'
                          : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                      }`}
                    >
                      <span>{lang.label}</span>
                      <span className="text-[11px] text-slate-400 font-normal">{lang.native}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Dark Mode Toggle */}
            <button
              onClick={toggleDarkMode}
              className="p-2 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              aria-label="Toggle Theme"
            >
              {darkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-slate-600" />}
            </button>

            {/* SOS Emergency Button */}
            <button
              onClick={onOpenEmergency}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-red-600 hover:bg-red-700 text-white text-xs font-bold shadow-md shadow-red-500/20 transition-all hover:scale-[1.02] animate-pulse"
              title="Emergency Help & Nearest Hospital"
            >
              <ShieldAlert className="w-4 h-4" />
              <span className="hidden sm:inline">SOS HELP</span>
            </button>

            {/* User Account / Profile */}
            {user ? (
              <div className="relative">
                <button
                  onClick={() => setUserDropdownOpen(!userDropdownOpen)}
                  className="flex items-center gap-2 p-1.5 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                >
                  <div className="w-7 h-7 rounded-lg bg-teal-600 text-white flex items-center justify-center font-bold text-xs uppercase">
                    {user.name.charAt(0)}
                  </div>
                  <span className="text-xs font-semibold text-slate-800 dark:text-slate-200 hidden lg:inline max-w-[90px] truncate">
                    {user.name}
                  </span>
                </button>

                {userDropdownOpen && (
                  <div className="absolute right-0 mt-2 w-56 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-2xl py-2 z-50 animate-fade-in">
                    <div className="px-4 py-2 border-b border-slate-100 dark:border-slate-800">
                      <p className="text-xs font-bold text-slate-900 dark:text-slate-100 truncate">{user.name}</p>
                      <p className="text-[11px] text-slate-500 truncate">{user.email}</p>
                      <div className="mt-1 flex items-center gap-1">
                        <span className="text-[10px] font-bold uppercase tracking-wider px-1.5 py-0.5 rounded bg-teal-100 dark:bg-teal-950 text-teal-800 dark:text-teal-200">
                          {user.role}
                        </span>
                        {user.isDoctorVerified && (
                          <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
                            Verified MD
                          </span>
                        )}
                      </div>
                    </div>
                    <button
                      onClick={() => {
                        onNavigate('dashboard');
                        setUserDropdownOpen(false);
                      }}
                      className="w-full text-left px-4 py-2 text-xs font-medium text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-2"
                    >
                      <User className="w-4 h-4 text-teal-600" /> My Health Dashboard
                    </button>
                    <button
                      onClick={() => {
                        onNavigate('bookmarks');
                        setUserDropdownOpen(false);
                      }}
                      className="w-full text-left px-4 py-2 text-xs font-medium text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-2"
                    >
                      <Bookmark className="w-4 h-4 text-teal-600" /> Saved Meds & Topics ({user.bookmarks.length})
                    </button>
                    <button
                      onClick={() => {
                        onNavigate('admin');
                        setUserDropdownOpen(false);
                      }}
                      className="w-full text-left px-4 py-2 text-xs font-medium text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-2"
                    >
                      <Activity className="w-4 h-4 text-teal-600" /> Admin Console
                    </button>
                    <div className="border-t border-slate-100 dark:border-slate-800 mt-1 pt-1">
                      <button
                        onClick={() => {
                          logout();
                          setUserDropdownOpen(false);
                        }}
                        className="w-full text-left px-4 py-2 text-xs font-medium text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/30 flex items-center gap-2"
                      >
                        <LogOut className="w-4 h-4" /> Sign Out
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <button
                onClick={() => onNavigate('login')}
                className="px-3 py-1.5 rounded-lg bg-teal-600 hover:bg-teal-700 text-white text-xs font-semibold transition-colors shadow-sm"
              >
                Sign In
              </button>
            )}

            {/* Mobile Menu Hamburger */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="xl:hidden p-2 rounded-lg text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              aria-label="Open Navigation Menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="xl:hidden border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-4 pt-3 pb-6 space-y-1 shadow-2xl">
          <div className="grid grid-cols-2 gap-2 pb-3 mb-2 border-b border-slate-100 dark:border-slate-800">
            <button
              onClick={() => {
                onNavigate('interactions');
                setMobileMenuOpen(false);
              }}
              className="p-2.5 rounded-xl bg-teal-50 dark:bg-teal-950/60 border border-teal-200 dark:border-teal-800 text-teal-800 dark:text-teal-200 text-xs font-bold text-left flex items-center gap-2"
            >
              <Pill className="w-4 h-4 text-teal-600" />
              <span>Drug Interactions</span>
            </button>
            <button
              onClick={() => {
                onNavigate('ai-assistant');
                setMobileMenuOpen(false);
              }}
              className="p-2.5 rounded-xl bg-cyan-50 dark:bg-cyan-950/60 border border-cyan-200 dark:border-cyan-800 text-cyan-800 dark:text-cyan-200 text-xs font-bold text-left flex items-center gap-2"
            >
              <Bot className="w-4 h-4 text-cyan-600" />
              <span>AI Assistant</span>
            </button>
          </div>

          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => {
                onNavigate(item.id);
                setMobileMenuOpen(false);
              }}
              className={`w-full text-left px-3 py-2 rounded-lg text-xs font-medium flex items-center justify-between ${
                currentTab === item.id
                  ? 'bg-teal-50 dark:bg-teal-950 text-teal-700 dark:text-teal-300 font-bold'
                  : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <span>{item.label}</span>
              {item.badge && (
                <span className="text-[10px] px-1.5 py-0.5 bg-teal-100 dark:bg-teal-900 text-teal-800 dark:text-teal-200 rounded">
                  {item.badge}
                </span>
              )}
            </button>
          ))}
        </div>
      )}
    </header>
  );
};
