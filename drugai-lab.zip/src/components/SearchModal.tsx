import React, { useState, useMemo } from 'react';
import { Search, X, Pill, Activity, FileText, ArrowRight, Clock, Sparkles } from 'lucide-react';
import { DISEASES_DATA, MEDICINES_DATA, HEALTH_ARTICLES, MEDICAL_TERMS } from '../data/mockData';
import { useAuth } from '../context/AuthContext';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelect: (type: 'disease' | 'medicine' | 'article' | 'interactions', id?: string) => void;
}

export const SearchModal: React.FC<SearchModalProps> = ({ isOpen, onClose, onSelect }) => {
  const [query, setQuery] = useState('');
  const [filter, setFilter] = useState<'all' | 'medicines' | 'diseases' | 'articles'>('all');
  const { user, addRecentSearch } = useAuth();

  const results = useMemo(() => {
    if (!query.trim()) return [];
    const q = query.toLowerCase().trim();

    const matches: Array<{
      id: string;
      title: string;
      subtitle: string;
      type: 'medicine' | 'disease' | 'article';
      tag: string;
    }> = [];

    if (filter === 'all' || filter === 'medicines') {
      MEDICINES_DATA.forEach((m) => {
        if (
          m.genericName.toLowerCase().includes(q) ||
          m.brandNames.some((b) => b.toLowerCase().includes(q)) ||
          m.category.toLowerCase().includes(q) ||
          m.generalUses.some((u) => u.toLowerCase().includes(q))
        ) {
          matches.push({
            id: m.id,
            title: m.genericName,
            subtitle: `Brands: ${m.brandNames.slice(0, 3).join(', ')} • ${m.category}`,
            type: 'medicine',
            tag: m.scheduleType,
          });
        }
      });
    }

    if (filter === 'all' || filter === 'diseases') {
      DISEASES_DATA.forEach((d) => {
        if (
          d.name.toLowerCase().includes(q) ||
          d.category.toLowerCase().includes(q) ||
          d.commonSymptoms.some((s) => s.toLowerCase().includes(q)) ||
          d.overview.toLowerCase().includes(q)
        ) {
          matches.push({
            id: d.id,
            title: d.name,
            subtitle: `${d.category} • Symptoms: ${d.commonSymptoms.slice(0, 2).join(', ')}`,
            type: 'disease',
            tag: d.category,
          });
        }
      });
    }

    if (filter === 'all' || filter === 'articles') {
      HEALTH_ARTICLES.forEach((a) => {
        if (
          a.title.toLowerCase().includes(q) ||
          a.summary.toLowerCase().includes(q) ||
          a.category.toLowerCase().includes(q)
        ) {
          matches.push({
            id: a.id,
            title: a.title,
            subtitle: `${a.category} • ${a.organization}`,
            type: 'article',
            tag: a.readTime,
          });
        }
      });
    }

    return matches.slice(0, 10);
  }, [query, filter]);

  const handleSelect = (type: 'medicine' | 'disease' | 'article', id: string) => {
    addRecentSearch(query || id);
    onClose();
    onSelect(type, id);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-16 sm:pt-24 px-4 bg-slate-950/70 backdrop-blur-sm animate-fade-in">
      <div className="w-full max-w-2xl bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden">
        {/* Search Input Bar */}
        <div className="relative flex items-center p-4 border-b border-slate-200 dark:border-slate-800">
          <Search className="w-5 h-5 text-teal-600 dark:text-teal-400 mr-3 shrink-0" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search diseases, medicines, symptoms, antibiotics, interactions..."
            className="w-full bg-transparent text-sm md:text-base text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none"
            autoFocus
          />
          {query && (
            <button onClick={() => setQuery('')} className="p-1 text-slate-400 hover:text-slate-600">
              <X className="w-4 h-4" />
            </button>
          )}
          <button
            onClick={onClose}
            className="ml-3 px-2 py-1 text-xs font-semibold rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700"
          >
            ESC
          </button>
        </div>

        {/* Filter Pills */}
        <div className="flex items-center gap-2 px-4 py-2.5 bg-slate-50 dark:bg-slate-950/50 border-b border-slate-100 dark:border-slate-800 text-xs">
          <span className="text-slate-400 font-medium mr-1">Filter:</span>
          {(['all', 'medicines', 'diseases', 'articles'] as const).map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`px-2.5 py-1 rounded-lg capitalize transition-colors ${
                filter === f
                  ? 'bg-teal-600 text-white font-semibold'
                  : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
              }`}
            >
              {f}
            </button>
          ))}
          <button
            onClick={() => {
              onClose();
              onSelect('interactions');
            }}
            className="ml-auto text-teal-600 dark:text-teal-400 hover:underline flex items-center gap-1 font-semibold"
          >
            <Sparkles className="w-3.5 h-3.5" /> Interaction Checker &rarr;
          </button>
        </div>

        {/* Results or Suggestions */}
        <div className="max-h-96 overflow-y-auto p-2">
          {query ? (
            results.length > 0 ? (
              <div className="space-y-1">
                {results.map((item) => (
                  <button
                    key={`${item.type}-${item.id}`}
                    onClick={() => handleSelect(item.type, item.id)}
                    className="w-full text-left p-3 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors flex items-center justify-between group"
                  >
                    <div className="flex items-center gap-3">
                      <div className="p-2 rounded-lg bg-slate-100 dark:bg-slate-800 group-hover:bg-teal-100 dark:group-hover:bg-teal-950 text-teal-600">
                        {item.type === 'medicine' ? (
                          <Pill className="w-4 h-4" />
                        ) : item.type === 'disease' ? (
                          <Activity className="w-4 h-4" />
                        ) : (
                          <FileText className="w-4 h-4" />
                        )}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <p className="text-sm font-bold text-slate-900 dark:text-white group-hover:text-teal-600 dark:group-hover:text-teal-300">
                            {item.title}
                          </p>
                          <span className="text-[10px] px-1.5 py-0.2 rounded bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-medium">
                            {item.tag}
                          </span>
                        </div>
                        <p className="text-xs text-slate-500 line-clamp-1">{item.subtitle}</p>
                      </div>
                    </div>
                    <ArrowRight className="w-4 h-4 text-slate-300 group-hover:text-teal-600 transition-colors" />
                  </button>
                ))}
              </div>
            ) : (
              <div className="py-12 text-center text-slate-500 dark:text-slate-400">
                <p className="font-semibold text-sm">No clinical entries found for "{query}"</p>
                <p className="text-xs mt-1">Try searching by generic name, brand name, or symptom.</p>
              </div>
            )
          ) : (
            <div className="p-4 space-y-4">
              {/* Popular Searches */}
              <div>
                <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-teal-500" />
                  Popular Medical Inquiries
                </p>
                <div className="flex flex-wrap gap-2">
                  {['Warfarin + Aspirin', 'Paracetamol overdose', 'Dengue warning signs', 'Metformin side effects', 'Lisinopril cough', 'Asthma inhaler'].map(
                    (term) => (
                      <button
                        key={term}
                        onClick={() => setQuery(term)}
                        className="px-3 py-1.5 rounded-lg text-xs bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-teal-50 dark:hover:bg-teal-950 hover:text-teal-600 transition-colors"
                      >
                        {term}
                      </button>
                    )
                  )}
                </div>
              </div>

              {/* Recent Searches */}
              {user && user.recentSearches.length > 0 && (
                <div>
                  <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5" />
                    Recent Searches
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {user.recentSearches.slice(0, 5).map((term) => (
                      <button
                        key={term}
                        onClick={() => setQuery(term)}
                        className="px-3 py-1.5 rounded-lg text-xs border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                      >
                        {term}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
