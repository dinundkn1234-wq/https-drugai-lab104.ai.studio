import React, { createContext, useContext, useState, useEffect } from 'react';
import { UserProfile, UserRole, SupportedLanguage } from '../types';

interface AuthContextType {
  user: UserProfile | null;
  darkMode: boolean;
  toggleDarkMode: () => void;
  login: (email: string, password?: string) => Promise<boolean>;
  register: (name: string, email: string, role: UserRole, extra?: { license?: string; institution?: string }) => Promise<boolean>;
  logout: () => void;
  resetPassword: (email: string) => Promise<boolean>;
  toggleBookmark: (id: string, type: 'disease' | 'medicine' | 'article', title: string) => void;
  isBookmarked: (id: string) => boolean;
  addRecentSearch: (query: string) => void;
  verifyDoctorStatus: (licenseNumber: string) => void;
  updateUserRole: (role: UserRole) => void;
  updateLanguagePreference: (lang: SupportedLanguage) => void;
}

const AuthContext = createContext<AuthContextType | null>(null);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Visitor starts in a clean, neutral logged-out state unless they have their own saved session
  const [user, setUser] = useState<UserProfile | null>(() => {
    try {
      const saved = localStorage.getItem('drugai_user');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  const [darkMode, setDarkMode] = useState<boolean>(() => {
    const saved = localStorage.getItem('drugai_theme');
    if (saved) return saved === 'dark';
    return window.matchMedia('(prefers-color-scheme: dark)').matches;
  });

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('drugai_theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('drugai_theme', 'light');
    }
  }, [darkMode]);

  const toggleDarkMode = () => setDarkMode((prev) => !prev);

  const saveUser = (u: UserProfile | null) => {
    setUser(u);
    if (u) {
      localStorage.setItem('drugai_user', JSON.stringify(u));
      // Also update in registered users map
      try {
        const storedUsers = JSON.parse(localStorage.getItem('drugai_users_db') || '{}');
        storedUsers[u.email.toLowerCase()] = u;
        localStorage.setItem('drugai_users_db', JSON.stringify(storedUsers));
      } catch (err) {
        console.error('Failed to update users db', err);
      }
    } else {
      localStorage.removeItem('drugai_user');
    }
  };

  const login = async (email: string, password?: string): Promise<boolean> => {
    const normalizedEmail = email.toLowerCase().trim();
    let profileToLogin: UserProfile;

    // Check if user was previously registered in local store
    try {
      const storedUsers = JSON.parse(localStorage.getItem('drugai_users_db') || '{}');
      if (storedUsers[normalizedEmail]) {
        profileToLogin = storedUsers[normalizedEmail];
        saveUser(profileToLogin);
        return true;
      }
    } catch (e) {
      console.warn('User db check error', e);
    }

    // Preserve owner credentials privately if the project owner logs in
    if (normalizedEmail === 'dinundkn1234@gmail.com') {
      profileToLogin = {
        id: 'usr_owner_101',
        email: normalizedEmail,
        name: 'Dinun D.',
        role: 'doctor',
        isDoctorVerified: true,
        medicalLicenseNumber: 'MD-884920-US',
        institution: 'Metropolitan Medical University',
        savedMedicines: ['paracetamol', 'metformin', 'lisinopril'],
        savedDiseases: ['hypertension', 'type-2-diabetes', 'asthma'],
        bookmarks: [
          { id: 'hypertension', type: 'disease', title: 'Hypertension (High Blood Pressure)' },
          { id: 'paracetamol', type: 'medicine', title: 'Paracetamol (Acetaminophen)' },
          { id: 'antibiotic-resistance-crisis', type: 'article', title: 'Understanding Antibiotic Resistance' },
        ],
        recentSearches: ['Warfarin interaction', 'Dengue precautions', 'Metformin lactic acidosis'],
        preferredLanguage: 'English',
        createdAt: '2026-01-15T08:00:00.000Z',
      };
    } else {
      // General user login
      const derivedName = normalizedEmail.split('@')[0];
      const capitalized = derivedName.charAt(0).toUpperCase() + derivedName.slice(1);
      profileToLogin = {
        id: `usr_${Date.now()}`,
        email: normalizedEmail,
        name: capitalized,
        role: 'patient',
        isDoctorVerified: false,
        savedMedicines: [],
        savedDiseases: [],
        bookmarks: [],
        recentSearches: [],
        preferredLanguage: 'English',
        createdAt: new Date().toISOString(),
      };
    }

    saveUser(profileToLogin);
    return true;
  };

  const register = async (
    name: string,
    email: string,
    role: UserRole,
    extra?: { license?: string; institution?: string }
  ): Promise<boolean> => {
    const normalizedEmail = email.toLowerCase().trim();
    const isOwner = normalizedEmail === 'dinundkn1234@gmail.com';

    const newUser: UserProfile = {
      id: `usr_${Date.now()}`,
      email: normalizedEmail,
      name: name.trim() || normalizedEmail.split('@')[0],
      role: isOwner ? 'doctor' : role,
      isDoctorVerified: isOwner || (role === 'doctor' && Boolean(extra?.license)),
      medicalLicenseNumber: isOwner ? 'MD-884920-US' : extra?.license || '',
      institution: isOwner ? 'Metropolitan Medical University' : extra?.institution || '',
      savedMedicines: [],
      savedDiseases: [],
      bookmarks: [],
      recentSearches: [],
      preferredLanguage: 'English',
      createdAt: new Date().toISOString(),
    };

    saveUser(newUser);
    return true;
  };

  const logout = () => {
    saveUser(null);
  };


  const resetPassword = async (email: string): Promise<boolean> => {
    console.log('Password reset requested for:', email);
    return true;
  };

  const toggleBookmark = (id: string, type: 'disease' | 'medicine' | 'article', title: string) => {
    if (!user) return;
    const exists = user.bookmarks.some((b) => b.id === id);
    const updatedBookmarks = exists
      ? user.bookmarks.filter((b) => b.id !== id)
      : [...user.bookmarks, { id, type, title }];

    const updated = {
      ...user,
      bookmarks: updatedBookmarks,
      savedMedicines:
        type === 'medicine'
          ? exists
            ? user.savedMedicines.filter((m) => m !== id)
            : [...user.savedMedicines, id]
          : user.savedMedicines,
      savedDiseases:
        type === 'disease'
          ? exists
            ? user.savedDiseases.filter((d) => d !== id)
            : [...user.savedDiseases, id]
          : user.savedDiseases,
    };
    saveUser(updated);
  };

  const isBookmarked = (id: string) => {
    if (!user) return false;
    return user.bookmarks.some((b) => b.id === id);
  };

  const addRecentSearch = (query: string) => {
    if (!user || !query.trim()) return;
    const trimmed = query.trim();
    const updatedSearches = [trimmed, ...user.recentSearches.filter((s) => s !== trimmed)].slice(
      0,
      10
    );
    saveUser({ ...user, recentSearches: updatedSearches });
  };

  const verifyDoctorStatus = (licenseNumber: string) => {
    if (!user) return;
    saveUser({
      ...user,
      isDoctorVerified: true,
      medicalLicenseNumber: licenseNumber,
      role: 'doctor',
    });
  };

  const updateUserRole = (role: UserRole) => {
    if (!user) return;
    saveUser({ ...user, role });
  };

  const updateLanguagePreference = (lang: SupportedLanguage) => {
    if (!user) return;
    saveUser({ ...user, preferredLanguage: lang });
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        darkMode,
        toggleDarkMode,
        login,
        register,
        logout,
        resetPassword,
        toggleBookmark,
        isBookmarked,
        addRecentSearch,
        verifyDoctorStatus,
        updateUserRole,
        updateLanguagePreference,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within an AuthProvider');
  return context;
};
