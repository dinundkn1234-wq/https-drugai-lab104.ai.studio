import {
  Disease,
  Medicine,
  HealthArticle,
  EmergencyHospital,
  QuizQuestion,
  MedicalTerm,
} from '../types';

export const DISEASES_DATA: Disease[] = [
  {
    id: 'hypertension',
    name: 'Hypertension (High Blood Pressure)',
    scientificName: 'Essential / Secondary Hypertension',
    category: 'Cardiovascular',
    overview:
      'Hypertension is a chronic medical condition in which systemic arterial blood pressure is persistently elevated. Often dubbed the "silent killer," it rarely manifests overt symptoms until secondary organ damage has developed.',
    commonSymptoms: [
      'Often asymptomatic (most patients have zero noticeable symptoms)',
      'Occasional morning occipital headaches',
      'Shortness of breath with mild exertion',
      'Dizziness or transient visual disturbances',
      'Nosebleeds (epistaxis) in severe or hypertensive crisis states',
    ],
    causesAndRisks: [
      'High sodium dietary intake & low potassium intake',
      'Lack of physical exercise and sedentary lifestyle',
      'Chronic unmanaged psychological stress',
      'Genetic predisposition and family history',
      'Excessive alcohol consumption and tobacco use',
      'Obesity and underlying metabolic syndrome',
    ],
    types: [
      'Primary (Essential) Hypertension: Accounts for ~90-95% of adult cases with multi-factorial etiology.',
      'Secondary Hypertension: Blood pressure elevation secondary to identifiable renal, endocrine, or vascular causes.',
      'Hypertensive Crisis: Severe spike (systolic > 180 mmHg or diastolic > 120 mmHg) requiring prompt clinical intervention.',
    ],
    prevention: [
      'Adopt the DASH diet (rich in fruits, vegetables, whole grains, and lean proteins)',
      'Limit dietary sodium to under 2,000 mg daily',
      'Engage in 150+ minutes of moderate aerobic activity weekly',
      'Maintain healthy body weight (BMI between 18.5 - 24.9)',
      'Limit alcohol intake and completely avoid tobacco products',
    ],
    diagnosticTests: [
      'Serial automated and manual sphygmomanometer blood pressure readings',
      '24-Hour Ambulatory Blood Pressure Monitoring (ABPM)',
      'Basic metabolic panel (Serum creatinine, eGFR, electrolytes)',
      'Urinalysis (screening for proteinuria and microalbuminuria)',
      '12-Lead Electrocardiogram (ECG) to assess left ventricular hypertrophy',
    ],
    treatmentApproaches: [
      'Comprehensive lifestyle modifications as foundational therapy',
      'First-line antihypertensive pharmacotherapy customized to patient comorbidities',
      'Self-monitoring of blood pressure with validated home digital monitors',
      'Periodic cardiovascular risk assessments',
    ],
    medicineCategories: [
      'ACE Inhibitors (e.g., Lisinopril, Enalapril)',
      'Angiotensin Receptor Blockers / ARBs (e.g., Losartan, Telmisartan)',
      'Calcium Channel Blockers (e.g., Amlodipine)',
      'Thiazide Diuretics (e.g., Chlorthalidone, Hydrochlorothiazide)',
    ],
    whenToSeekHelp: [
      'Systolic blood pressure repeatedly reading 130–139 mmHg or diastolic 80–89 mmHg',
      'Persistent headaches, fatigue, or visual changes',
      'Swelling in ankles or feet while taking blood pressure medications',
    ],
    emergencyWarningSigns: [
      'Systolic BP > 180 or Diastolic BP > 120 with chest pain or shortness of breath',
      'Sudden severe headache, weakness, facial droop, or difficulty speaking',
      'Sudden visual loss, confusion, or seizures',
    ],
    faqs: [
      {
        question: 'Can hypertension be cured completely?',
        answer:
          'Primary hypertension cannot be cured, but it can be very successfully controlled through lifelong healthy lifestyle choices and prescribed medications.',
      },
      {
        question: 'Can I stop taking my blood pressure medicine if my numbers are normal?',
        answer:
          'No. Normal numbers usually mean the medication is working. Discontinuing therapy abruptly can cause rebound hypertension.',
      },
    ],
    sources: [
      { title: 'Hypertension Clinical Practice Guidelines', organization: 'World Health Organization (WHO)' },
      { title: 'High Blood Pressure Guidelines', organization: 'American Heart Association (AHA) / CDC' },
      { title: 'Hypertension in Adults: Diagnosis and Management', organization: 'National Institute for Health and Care Excellence (NICE)' },
    ],
  },
  {
    id: 'type-2-diabetes',
    name: 'Type 2 Diabetes Mellitus',
    scientificName: 'Non-Insulin Dependent Diabetes Mellitus (T2DM)',
    category: 'Endocrine & Metabolic',
    overview:
      'Type 2 diabetes is a chronic metabolic disorder characterized by peripheral insulin resistance and progressive pancreatic beta-cell secretory defect, resulting in chronic hyperglycemia.',
    commonSymptoms: [
      'Polydipsia (increased persistent thirst)',
      'Polyuria (frequent urination, especially at night)',
      'Unexplained weight loss despite normal appetite',
      'Persistent fatigue and generalized weakness',
      'Slow-healing cuts, sores, or recurrent skin infections',
      'Blurred vision',
    ],
    causesAndRisks: [
      'Insulin resistance combined with impaired insulin secretion',
      'Excess body adiposity, particularly visceral and abdominal fat',
      'Sedentary lifestyle and lack of routine exercise',
      'First-degree relative with Type 2 diabetes',
      'History of gestational diabetes or polycystic ovary syndrome (PCOS)',
    ],
    types: [
      'Type 2 Diabetes (Adult-onset / Insulin-resistant)',
      'Prediabetes (Impaired fasting glucose or impaired glucose tolerance)',
      'Latent Autoimmune Diabetes in Adults (LADA) - clinical mimic',
    ],
    prevention: [
      'Achieve and sustain 5-7% weight reduction if overweight',
      'Increase dietary fiber intake from vegetables and whole grains',
      'Eliminate sugar-sweetened beverages and ultra-processed snacks',
      'Participate in at least 150 minutes of aerobic and resistance exercise weekly',
    ],
    diagnosticTests: [
      'Hemoglobin A1c test (>= 6.5% confirms diagnosis)',
      'Fasting Plasma Glucose (FPG >= 126 mg/dL)',
      'Oral Glucose Tolerance Test (2-hour plasma glucose >= 200 mg/dL)',
      'Random plasma glucose >= 200 mg/dL in presence of classic symptoms',
    ],
    treatmentApproaches: [
      'Medical Nutrition Therapy (MNT) and tailored carbohydrate management',
      'Regular physical activity to enhance insulin sensitivity',
      'First-line oral antidiabetic agents (e.g., Metformin)',
      'Second-line GLP-1 receptor agonists or SGLT2 inhibitors for cardiovascular/renal protection',
      'Periodic screening for microvascular and macrovascular complications',
    ],
    medicineCategories: [
      'Biguanides (Metformin)',
      'SGLT2 Inhibitors (Empagliflozin, Dapagliflozin)',
      'GLP-1 Receptor Agonists (Semaglutide, Liraglutide)',
      'Sulfonylureas (Glipizide, Glimepiride)',
      'Basal and Bolus Insulins',
    ],
    whenToSeekHelp: [
      'Fasting blood sugar readings consistently exceeding target ranges',
      'Persistent tingling, numbness, or burning sensation in feet or toes',
      'Frequent urinary tract or skin fungal infections',
    ],
    emergencyWarningSigns: [
      'Extreme hyperglycemia (> 400 mg/dL) with confusion or profound dehydration (HHS)',
      'Deep, rapid breathing, fruity breath odor, severe abdominal pain (DKA)',
      'Severe hypoglycemia (< 54 mg/dL) with loss of consciousness or seizures',
    ],
    faqs: [
      {
        question: 'Is diabetes caused solely by eating too much sugar?',
        answer:
          'While excess sugar contributes to caloric surplus and obesity, diabetes results from a complex interplay of genetic predisposition, insulin resistance, and cellular metabolic dysregulation.',
      },
    ],
    sources: [
      { title: 'Standards of Care in Diabetes', organization: 'American Diabetes Association (ADA)' },
      { title: 'Diabetes Factsheet', organization: 'World Health Organization (WHO)' },
    ],
  },
  {
    id: 'asthma',
    name: 'Bronchial Asthma',
    scientificName: 'Asthma bronchiale',
    category: 'Respiratory',
    overview:
      'Asthma is a chronic inflammatory disorder of the airways characterized by variable and recurring symptoms, reversible airflow obstruction, and bronchospasm.',
    commonSymptoms: [
      'Wheezing (high-pitched whistling sound during exhalation)',
      'Shortness of breath and air hunger',
      'Chest tightness or feeling of compression',
      'Dry or productive cough, often worsening at night or early morning',
    ],
    causesAndRisks: [
      'Atopic diathesis and genetic predisposition to allergic sensitization',
      'Environmental airborne allergens (dust mites, pollen, animal dander, mold)',
      'Respiratory viral infections (e.g., rhinovirus)',
      'Tobacco smoke exposure and urban air pollution',
      'Exercise-induced bronchoconstriction in cold air',
    ],
    types: [
      'Allergic (Extrinsic) Asthma: Triggered by specific aeroallergens',
      'Non-Allergic (Intrinsic) Asthma: Triggered by cold air, viral illness, or stress',
      'Occupational Asthma: Induced by workplace irritants or dusts',
      'Severe / Refractory Asthma: Requires high-dose inhaled corticosteroids + biologics',
    ],
    prevention: [
      'Identify and minimize exposure to confirmed environmental triggers',
      'Adhere strictly to daily maintenance controller inhalers',
      'Receive annual influenza and recommended pneumococcal vaccinations',
      'Maintain an up-to-date personalized Asthma Action Plan',
    ],
    diagnosticTests: [
      'Spirometry with bronchodilator reversibility testing (FEV1/FVC ratio)',
      'Peak Expiratory Flow (PEF) diurnal variability monitoring',
      'Fractional Exhaled Nitric Oxide (FeNO) to assess eosinophilic airway inflammation',
      'Skin prick testing or serum specific IgE assays',
    ],
    treatmentApproaches: [
      'Two-track strategy: Daily Anti-inflammatory Controller + Rapid Rescue Reliever',
      'Stepwise pharmacological management based on GINA guidelines',
      'Proper inhaler technique training and spacer device utilization',
    ],
    medicineCategories: [
      'Inhaled Corticosteroids (ICS) (e.g., Fluticasone, Budesonide)',
      'Short-Acting Beta-2 Agonists (SABA) (e.g., Albuterol/Salbutamol)',
      'Long-Acting Beta-2 Agonists (LABA) (e.g., Formoterol, Salmeterol)',
      'Leukotriene Receptor Antagonists (e.g., Montelukast)',
    ],
    whenToSeekHelp: [
      'Needing rescue reliever inhaler more than 2 times per week',
      'Waking up at night due to coughing or wheezing',
      'Limitations in performing daily exercise or climbing stairs',
    ],
    emergencyWarningSigns: [
      'Severe breathlessness: unable to speak full sentences without gasping',
      'Rescue inhaler provides zero or minimal relief',
      'Cyanosis (bluish tint around lips, gums, or fingernails)',
      'Retraction of neck and intercostal muscles during breathing',
    ],
    faqs: [
      {
        question: 'Can someone outgrow childhood asthma?',
        answer:
          'Many children experience clinical symptom remission during adolescence, though underlying airway hyperresponsiveness can persist or recur in adulthood.',
      },
    ],
    sources: [
      { title: 'Global Strategy for Asthma Management and Prevention', organization: 'Global Initiative for Asthma (GINA)' },
      { title: 'Asthma Clinical Overview', organization: 'CDC & NIH / NHLBI' },
    ],
  },
  {
    id: 'dengue-fever',
    name: 'Dengue Fever',
    scientificName: 'Dengue virus infection (DENV 1-4)',
    category: 'Infectious Disease',
    overview:
      'Dengue is a mosquito-borne viral infection caused by the dengue virus, transmitted primarily by female Aedes aegypti and Aedes albopictus mosquitoes in tropical and subtropical regions.',
    commonSymptoms: [
      'Sudden high-grade fever (often reaching 40°C / 104°F)',
      'Severe headache, particularly intense retro-orbital (behind the eyes) pain',
      'Severe muscle and joint aches ("breakbone fever")',
      'Nausea, vomiting, and loss of appetite',
      'Maculopapular skin rash appearing 2-5 days after fever onset',
    ],
    causesAndRisks: [
      'Bite of an infected female Aedes mosquito',
      'Residence in or travel to tropical and subtropical areas',
      'Second infection with a different DENV serotype (heightened risk of Severe Dengue)',
    ],
    types: [
      'Dengue Fever without warning signs',
      'Dengue Fever with warning signs (abdominal pain, persistent vomiting, mucosal bleed)',
      'Severe Dengue (Dengue Hemorrhagic Fever / Dengue Shock Syndrome)',
    ],
    prevention: [
      'Eliminate stagnant water sources around residential habitats',
      'Apply DEET or picaridin-containing insect repellents on exposed skin',
      'Install mosquito screens on windows and sleep under treated mosquito nets',
      'Wear protective long-sleeved clothing during dawn and dusk',
    ],
    diagnosticTests: [
      'Dengue NS1 Antigen rapid test (most sensitive in first 1-5 days)',
      'Complete Blood Count (CBC) to monitor platelet count and hematocrit',
      'Dengue IgM/IgG antibody ELISA serology',
      'RT-PCR for viral RNA detection in early clinical phase',
    ],
    treatmentApproaches: [
      'Meticulous oral and intravenous rehydration therapy',
      'Antipyretic care: Paracetamol / Acetaminophen ONLY',
      'Strict AVOIDANCE of Aspirin, Ibuprofen, and NSAIDs due to severe platelet inhibition and hemorrhage risk',
      'Close daily hospital monitoring of hematocrit and platelet trends',
    ],
    medicineCategories: [
      'Analgesics/Antipyretics: Acetaminophen / Paracetamol ONLY',
      'Oral Rehydration Salts (ORS) and balanced isotonic intravenous fluids',
    ],
    whenToSeekHelp: [
      'High persistent fever during dengue season or post-travel',
      'Petechiae (tiny red spots on skin) or minor gum bleeding',
      'Platelet count dropping below 100,000 /mcL',
    ],
    emergencyWarningSigns: [
      'Severe, continuous abdominal pain and tenderness',
      'Persistent vomiting (unable to retain any fluids)',
      'Bleeding from nose, gums, or blood in vomit/stool (hematemesis/melena)',
      'Lethargy, extreme restlessness, cold clammy extremities (signs of dengue shock)',
    ],
    faqs: [
      {
        question: 'Why can I NOT take ibuprofen or aspirin for dengue fever?',
        answer:
          'Dengue virus already attacks blood platelets and impairs blood clotting. Ibuprofen, aspirin, and other NSAIDs further prevent platelet clotting and irritate the stomach lining, drastically increasing the danger of fatal internal bleeding.',
      },
    ],
    sources: [
      { title: 'Dengue Guidelines for Diagnosis, Treatment, Prevention and Control', organization: 'World Health Organization (WHO)' },
      { title: 'Dengue Clinical Guidance', organization: 'CDC' },
    ],
  },
  {
    id: 'gerd',
    name: 'Gastroesophageal Reflux Disease (GERD)',
    scientificName: 'GERD / Reflux Esophagitis',
    category: 'Gastroenterology',
    overview:
      'GERD is a chronic digestive disease that occurs when stomach acid or bile frequently flows back into the food pipe (esophagus), irritating its mucosal lining.',
    commonSymptoms: [
      'Pyrosis (retrosternal burning sensation or heartburn), especially after meals',
      'Regurgitation of food, sour liquid, or acid into the mouth',
      'Chronic dry cough or throat clearing',
      'Dysphagia (difficulty swallowing) or globus sensation',
      'Hoarseness, laryngitis, or disturbed sleep',
    ],
    causesAndRisks: [
      'Transient lower esophageal sphincter (LES) relaxations',
      'Hiatal hernia',
      'Obesity and elevated intra-abdominal pressure',
      'Delayed gastric emptying',
      'Trigger foods: fried/fatty foods, chocolate, caffeine, mint, citrus, alcohol',
      'Tobacco smoking and late-night heavy meals',
    ],
    types: [
      'Non-Erosive Reflux Disease (NERD): Symptoms present without mucosal breaks on endoscopy',
      'Erosive Esophagitis: Endoscopically visible ulcerations or mucosal inflammation',
      'Barrett Esophagus: Metaplastic conversion of esophageal epithelium requiring surveillance',
    ],
    prevention: [
      'Elevate head of bed by 6 inches during sleep',
      'Avoid lying down for at least 3 hours after eating',
      'Eat smaller, more frequent meals rather than large heavy dinners',
      'Weight loss in overweight individuals',
      'Avoid personal trigger foods and stop smoking',
    ],
    diagnosticTests: [
      'Upper Gastrointestinal Endoscopy (EGD)',
      '24-Hour Ambulatory Esophageal pH/Impedance monitoring',
      'Esophageal Manometry to evaluate motility and sphincter tone',
      'Barium swallow esophagram',
    ],
    treatmentApproaches: [
      'Dietary and lifestyle adjustments as initial baseline',
      'Acid suppression pharmacotherapy with PPIs or H2 blockers',
      'Antacids for immediate transient symptom relief',
      'Surgical intervention (e.g., Nissen fundoplication) in refractory structural cases',
    ],
    medicineCategories: [
      'Proton Pump Inhibitors (PPIs) (e.g., Omeprazole, Esomeprazole, Pantoprazole)',
      'H2-Receptor Antagonists (e.g., Famotidine)',
      'Antacids & Alginates',
      'Prokinetic agents',
    ],
    whenToSeekHelp: [
      'Heartburn occurring more than twice a week',
      'Over-the-counter antacids provide only temporary relief or no relief',
      'Persistent hoarseness or recurrent throat clearing',
    ],
    emergencyWarningSigns: [
      'Severe crushing chest pain radiating to arm, neck, or jaw (MUST rule out myocardial infarction immediately)',
      'Vomiting blood (bright red or coffee-ground appearance)',
      'Black, tarry stools (melena)',
      'Food feeling stuck in throat causing choking',
    ],
    faqs: [
      {
        question: 'How do I tell heartburn apart from a heart attack?',
        answer:
          'Because chest pain from severe acid reflux can feel identical to angina or a heart attack, NEVER assume chest pain is just heartburn. Any new, crushing, radiating, or exertion-related chest pain warrants immediate emergency medical evaluation.',
      },
    ],
    sources: [
      { title: 'Guidelines for the Diagnosis and Management of GERD', organization: 'American College of Gastroenterology (ACG)' },
      { title: 'Indigestion and Heartburn Clinical Guide', organization: 'NHS UK' },
    ],
  },
  {
    id: 'als',
    name: 'Amyotrophic Lateral Sclerosis (ALS)',
    scientificName: 'Motor Neuron Disease / Lou Gehrig Disease',
    category: 'Rare Neurological Diseases',
    isRareDisease: true,
    overview:
      'ALS is a progressive, fatal neurodegenerative disease that affects upper and lower motor neurons in the brain and spinal cord, leading to loss of voluntary muscle movement and respiratory failure.',
    commonSymptoms: [
      'Asymmetric focal limb weakness (dropping objects, stumbling, foot drop)',
      'Fasciculations (visible muscle twitches) and painful cramps',
      'Bulbar signs: dysarthria (slurred speech) and dysphagia (difficulty swallowing)',
      'Muscle atrophy and hyperreflexia/spasticity',
      'Shortness of breath and diaphragmatic weakness in later stages',
    ],
    causesAndRisks: [
      'Sporadic in ~90% of cases (exact etiology unknown; involving excitotoxicity, oxidative stress, TDP-43 protein aggregates)',
      'Familial / Genetic in ~10% (mutations in C9orf72, SOD1, TARDBP, FUS genes)',
      'Peak onset age 55–75 years; slightly higher in biological males',
    ],
    types: [
      'Limb-Onset ALS (~70%): Symptoms commence in arms or legs',
      'Bulbar-Onset ALS (~25%): Symptoms commence with speech and swallowing impairment',
      'Primary Lateral Sclerosis (PLS): Pure upper motor neuron variant with slower progression',
    ],
    prevention: [
      'No established preventive measures exist for sporadic ALS',
      'Genetic counseling for families with confirmed inherited familial ALS mutations',
    ],
    diagnosticTests: [
      'Electromyography (EMG) and Nerve Conduction Studies (NCS) demonstrating active denervation',
      'High-resolution Brain and Spinal Cord MRI to exclude compressive myelopathy or MS',
      'Comprehensive CSF and autoimmune panels to rule out multifocal motor neuropathy',
      'Genetic panel testing (C9orf72 repeat expansion, SOD1 mutations)',
    ],
    treatmentApproaches: [
      'Multidisciplinary ALS clinical team care (neurology, pulmonology, PT/OT, speech, nutrition)',
      'Disease-modifying glutamate release inhibitors and free-radical scavengers',
      'Non-invasive positive pressure ventilation (BiPAP) when forced vital capacity (FVC) drops',
      'Percutaneous endoscopic gastrostomy (PEG) feeding tube for severe dysphagia',
    ],
    medicineCategories: [
      'Glutamate Antagonists (e.g., Riluzole)',
      'Free Radical Scavengers (e.g., Edaravone)',
      'Antispasmodics (e.g., Baclofen, Tizanidine)',
      'Sialorrhea treatments (e.g., Glycopyrrolate, Amitriptyline)',
    ],
    whenToSeekHelp: [
      'Progressive painless muscle weakness in a hand, arm, or leg lasting weeks',
      'Unexplained difficulty swallowing saliva or progressive slurring of words',
      'Persistent muscle twitching accompanied by visible muscle thinning',
    ],
    emergencyWarningSigns: [
      'Acute respiratory distress or severe morning headaches from nocturnal hypoventilation',
      'Choking episodes with inability to clear airway secretions',
      'Aspiration pneumonia signs (high fever with acute breathlessness and coughing)',
    ],
    faqs: [
      {
        question: 'Does ALS impair memory or sensory nerves?',
        answer:
          'ALS selectively impairs motor neurons. Sensation, vision, hearing, and bowel/bladder sphincters are typically preserved, although frontotemporal dementia (FTD) can occur in up to 15% of individuals with specific genetic mutations.',
      },
    ],
    sources: [
      { title: 'ALS Practice Parameter Updates', organization: 'American Academy of Neurology (AAN)' },
      { title: 'Rare Disease Information: ALS', organization: 'National Organization for Rare Disorders (NORD) & NIH' },
    ],
  },
  {
    id: 'guillain-barre',
    name: 'Guillain-Barré Syndrome (GBS)',
    scientificName: 'Acute Inflammatory Demyelinating Polyradiculoneuropathy (AIDP)',
    category: 'Rare Neurological Diseases',
    isRareDisease: true,
    overview:
      'GBS is a rare, rapid-onset autoimmune disorder where the immune system mistakenly attacks peripheral nerves, triggering progressive ascending muscle weakness, paresthesia, and potential paralysis.',
    commonSymptoms: [
      'Symmetrical ascending muscle weakness (starting in legs and progressing upward to arms and face)',
      'Paresthesias ("pins and needles" tingling or burning in toes and fingertips)',
      'Loss of deep tendon reflexes (areflexia)',
      'Autonomic instability: fluctuating blood pressure, tachycardia, or arrhythmias',
      'Facial nerve weakness and respiratory muscle involvement in severe cases',
    ],
    causesAndRisks: [
      'Post-infectious molecular mimicry triggered by Campylobacter jejuni enteritis (~30%)',
      'Recent viral infections (Cytomegalovirus, Epstein-Barr virus, Zika virus, influenza)',
      'Rarely follows specific major surgical traumas',
    ],
    types: [
      'AIDP (Acute Inflammatory Demyelinating Polyradiculoneuropathy): Most common North American/European type',
      'AMAN (Acute Motor Axonal Neuropathy): Primary axonal injury, common in Asia/Latin America',
      'Miller Fisher Syndrome (MFS): Triad of ophthalmoplegia, ataxia, and areflexia',
    ],
    prevention: [
      'Proper food hygiene (cooking poultry thoroughly) to prevent Campylobacter gastroenteritis',
      'No specific vaccine or targeted prevention exists for GBS',
    ],
    diagnosticTests: [
      'Lumbar Puncture (CSF analysis demonstrating albuminocytological dissociation: high protein, normal WBC)',
      'Nerve Conduction Studies (NCS) demonstrating conduction blocks and prolonged F-waves',
      'Forced Vital Capacity (FVC) and Negative Inspiratory Force (NIF) bedside monitoring',
    ],
    treatmentApproaches: [
      'Emergency inpatient ICU/step-down admission for cardiac and respiratory telemetry',
      'Intravenous Immunoglobulin (IVIG) therapy over 5 days',
      'Plasma Exchange (Plasmapheresis) as alternative first-line immunotherapy',
      'Supportive mechanical ventilation if respiratory muscles are compromised',
      'Intensive post-acute neurological rehabilitation',
    ],
    medicineCategories: [
      'Intravenous Immunoglobulin (IVIG)',
      'Neuropathic analgesics (e.g., Gabapentin, Pregabalin)',
      'Low molecular weight heparin (DVT prophylaxis while immobile)',
    ],
    whenToSeekHelp: [
      'Any unexplained progressive tingling or weakness moving up from feet to legs',
      'Difficulty rising from a chair or climbing stairs following a recent diarrheal or viral illness',
    ],
    emergencyWarningSigns: [
      'Rapidly ascending paralysis reaching the chest or arms',
      'Difficulty breathing, swallowing, or speaking',
      'Severe blood pressure swings, irregular heart rhythm, or severe dizziness',
    ],
    faqs: [
      {
        question: 'Is Guillain-Barré Syndrome curable and do patients recover?',
        answer:
          'Yes, most patients (approx. 85%) achieve full or near-full functional recovery within 6 to 12 months, although fatigue and mild residual weakness may linger.',
      },
    ],
    sources: [
      { title: 'Diagnosis and Management of Guillain-Barré Syndrome in Ten Steps', organization: 'Nature Reviews Neurology & WHO' },
      { title: 'GBS Clinical Information', organization: 'National Institute of Neurological Disorders and Stroke (NINDS)' },
    ],
  },
  {
    id: 'systemic-lupus',
    name: 'Systemic Lupus Erythematosus (SLE)',
    scientificName: 'Systemic Lupus Erythematosus',
    category: 'Rare Autoimmune Diseases',
    isRareDisease: true,
    overview:
      'SLE is a chronic systemic autoimmune disease in which pathogenic autoantibodies attack nuclear antigens, causing widespread inflammation and tissue damage across joints, skin, kidneys, and blood vessels.',
    commonSymptoms: [
      'Malar "butterfly" rash over cheeks and bridge of nose (photosensitive)',
      'Symmetric polyarthritis or arthralgia without joint erosion',
      'Extreme debilitating chronic fatigue and low-grade fevers',
      'Pleuritic chest pain or pericarditis',
      'Lupus nephritis: proteinuria, foamy urine, and leg edema',
      'Oral or nasal painless ulcerations',
    ],
    causesAndRisks: [
      'Genetic susceptibility (HLA-DR2/DR3, complement deficiencies)',
      'Hormonal factors: 9:1 female-to-male ratio during reproductive years',
      'Environmental triggers: Ultraviolet (UV) light exposure, silica dust, smoking',
    ],
    types: [
      'Systemic Lupus Erythematosus (SLE): Multisystem organ involvement',
      'Cutaneous Lupus (Discoid Lupus): Primarily dermatological lesions',
      'Drug-Induced Lupus: Triggered by hydralazine, procainamide, or isoniazid',
      'Neonatal Lupus: Transient maternal anti-Ro/SSA antibody transfer',
    ],
    prevention: [
      'Strict photoprotection: broad-spectrum SPF 50+ sunscreen, UV-blocking hats/clothing',
      'Avoid smoking (significantly reduces hydroxychloroquine efficacy and worsens vascular risk)',
      'Prompt management of infections which can precipitate disease flares',
    ],
    diagnosticTests: [
      'Antinuclear Antibody (ANA) screen (high sensitivity >95%)',
      'Anti-double-stranded DNA (anti-dsDNA) and Anti-Smith (anti-Sm) antibodies (high specificity)',
      'Serum Complement levels (C3, C4) demonstrating consumption during flares',
      'Urinalysis and spot urine protein-to-creatinine ratio (screening for nephritis)',
      'Renal core biopsy for histological staging of glomerulonephritis',
    ],
    treatmentApproaches: [
      'Foundational antimalarial therapy (Hydroxychloroquine) for all SLE patients without contraindications',
      'Corticosteroids for acute disease flares, tapered to the lowest effective dose',
      'Immunosuppressive and B-cell targeted biologic therapies for organ-threatening disease',
    ],
    medicineCategories: [
      'Antimalarials (e.g., Hydroxychloroquine)',
      'Glucocorticoids (e.g., Prednisone, Methylprednisolone)',
      'Immunosuppressants (e.g., Mycophenolate Mofetil, Azathioprine, Methotrexate)',
      'Targeted Biologics (e.g., Belimumab, Anifrolumab)',
    ],
    whenToSeekHelp: [
      'Persistent joint swelling, unexplained fever, and facial rash worsening in the sun',
      'New swelling in ankles or puffy eyelids with dark/foamy urine',
    ],
    emergencyWarningSigns: [
      'Acute chest pain and severe shortness of breath (pleuritis, pericarditis, or pulmonary embolism)',
      'Sudden neurological symptoms: seizures, acute confusion, or stroke-like deficits (Lupus cerebritis)',
      'Rapidly declining urine output with hypertension (acute glomerulonephritis)',
    ],
    faqs: [
      {
        question: 'Can women with Lupus have safe, healthy pregnancies?',
        answer:
          'Yes, but pregnancies should be carefully planned during at least 6 months of quiescent disease remission under the joint care of a rheumatologist and maternal-fetal medicine specialist.',
      },
    ],
    sources: [
      { title: 'EULAR Recommendations for the Management of Systemic Lupus Erythematosus', organization: 'European Alliance of Associations for Rheumatology (EULAR)' },
      { title: 'Lupus Guidelines', organization: 'American College of Rheumatology (ACR)' },
    ],
  },
  {
    id: 'cystic-fibrosis',
    name: 'Cystic Fibrosis (CF)',
    scientificName: 'Mucoviscidosis / CFTR Deficiency',
    category: 'Rare Genetic Diseases',
    isRareDisease: true,
    overview:
      'Cystic Fibrosis is an autosomal recessive genetic disorder caused by mutations in the CFTR gene, resulting in abnormally thick, viscous mucus that obstructs airways, impairs pancreatic enzyme secretion, and causes chronic multiorgan damage.',
    commonSymptoms: [
      'Persistent productive cough with thick, viscous sputum',
      'Recurrent pulmonary infections (Pseudomonas aeruginosa, Staphylococcus aureus)',
      'Pancreatic insufficiency: malabsorption, failure to thrive, steatorrhea (oily foul stools)',
      'Salty-tasting skin (excessive chloride loss in sweat)',
      'Nasal polyps and chronic pansinusitis',
      'CF-related diabetes and male infertility (congenital bilateral absence of vas deferens)',
    ],
    causesAndRisks: [
      'Autosomal recessive inheritance: both parents must be carriers of pathogenic CFTR mutations',
      'Most prevalent mutation: F508del deletion on chromosome 7',
      'Prevalence ~1 in 3,000 live births in populations of European ancestry',
    ],
    types: [
      'Classic CF: Severe CFTR loss with both pulmonary and pancreatic insufficiency',
      'Non-Classic / Atypical CF: Residual CFTR function with milder adult-onset pulmonary disease',
    ],
    prevention: [
      'Preconception carrier genetic screening for prospective parents',
      'Routine universal Newborn Bloodspot Screening (immunoreactive trypsinogen / IRT testing)',
    ],
    diagnosticTests: [
      'Quantitative Pilocarpine Iontophoresis Sweat Chloride Test (gold standard: chloride >= 60 mmol/L)',
      'Comprehensive CFTR gene sequencing and mutation analysis',
      'High-resolution chest CT scan detecting early bronchiectasis',
      'Sputum microbiological culture and fecal elastase-1 testing',
    ],
    treatmentApproaches: [
      'Targeted CFTR Modulator therapy correcting underlying protein folding and gating defects',
      'Daily airway clearance therapy (oscillating positive expiratory pressure vests, chest physiotherapy)',
      'Inhaled mucolytics and hypertonic saline to hydrate airway surface liquid',
      'Pancreatic enzyme replacement therapy (PERT) with all meals and snacks',
      'Aggressive oral and intravenous antibiotic therapy for pulmonary exacerbations',
    ],
    medicineCategories: [
      'CFTR Modulators (e.g., Elexacaftor / Tezacaftor / Ivacaftor - Trikafta)',
      'Mucolytic Aerosols (e.g., Dornase alfa / Pulmozyme, Hypertonic Saline 7%)',
      'Inhaled Antibiotics (e.g., Tobramycin inhalation solution, Aztreonam)',
      'Pancreatic Enzyme Replacement Therapy (PERT) (e.g., Creon, Zenpep)',
    ],
    whenToSeekHelp: [
      'Increased coughing, changes in sputum color or volume, or low-grade fever',
      'Unexplained weight loss or digestive abdominal cramping',
    ],
    emergencyWarningSigns: [
      'Significant hemoptysis (coughing up large amounts of blood)',
      'Acute pneumothorax: sudden sharp unilateral chest pain with severe dyspnea',
      'Severe respiratory failure or oxygen desaturation below 90%',
    ],
    faqs: [
      {
        question: 'How have CFTR modulator therapies transformed life expectancy in Cystic Fibrosis?',
        answer:
          'Triple combination CFTR modulators (like Trikafta) directly address the root biological defect for up to 90% of patients, dramatically improving lung function, reducing hospitalizations, and elevating median predicted survival into the 50s and 60s.',
      },
    ],
    sources: [
      { title: 'Cystic Fibrosis Foundation Clinical Care Guidelines', organization: 'Cystic Fibrosis Foundation (CFF)' },
      { title: 'European Cystic Fibrosis Society (ECFS) Standards of Care', organization: 'ECFS' },
    ],
  },
];

export const MEDICINES_DATA: Medicine[] = [
  {
    id: 'paracetamol',
    genericName: 'Paracetamol (Acetaminophen)',
    brandNames: ['Tylenol', 'Panadol', 'Calpol', 'Dolo-650', 'Crocin'],
    category: 'Analgesics & Antipyretics (Non-opioid)',
    generalUses: [
      'Mild to moderate pain relief (headaches, toothache, muscle aches, osteoarthritis)',
      'Fever reduction in adults and pediatric patients',
      'First-line antipyretic in suspected viral hemorrhagic fevers like dengue',
    ],
    howItWorks:
      'Acts centrally by inhibiting prostaglandin synthesis in the central nervous system and modulating descending serotonergic inhibitory pathways. Unlike NSAIDs, it possesses negligible peripheral anti-inflammatory activity.',
    commonSideEffects: [
      'Generally well-tolerated at therapeutic dosages',
      'Nausea or abdominal discomfort (rare)',
      'Allergic skin rash (infrequent)',
    ],
    importantWarnings: [
      'Maximum adult daily dose is 4,000 mg (4 grams) from ALL sources combined. High doses lead to fatal acute hepatic necrosis (liver failure).',
      'Always check labels of cough/cold combination remedies to avoid accidental double-dosing of acetaminophen.',
      'Reduce maximum dosage in patients with chronic liver disease, chronic malnutrition, or heavy alcohol use.',
    ],
    commonInteractions: [
      'Warfarin: Chronic daily high doses may modestly enhance anticoagulant effect.',
      'Alcohol: Concurrent heavy alcohol consumption increases risk of toxic metabolite (NAPQI) accumulation.',
      'Isoniazid & enzyme-inducing anticonvulsants: May increase risk of hepatotoxicity.',
    ],
    contraindications: [
      'Severe active hepatic impairment or acute liver failure',
      'Known hypersensitivity to paracetamol / acetaminophen',
    ],
    storageInfo: 'Store at room temperature (20°C - 25°C / 68°F - 77°F) away from moisture and heat. Keep out of reach of children.',
    generalSafety:
      'One of the safest pain relievers when used strictly within recommended doses. Never exceed recommended maximums.',
    pregnancyWarning:
      'Generally considered the pain reliever of choice during pregnancy when clinically indicated, used at the lowest effective dose for the shortest duration.',
    ageSafetyWarning:
      'Pediatric dosing MUST be calculated strictly by weight (mg/kg), never by adult guessing. Use calibrated oral syringes, not household teaspoons.',
    whenProfessionalAdviceNecessary: [
      'Fever persists for more than 3 consecutive days',
      'Pain worsens or lasts longer than 5 to 7 days',
      'Accidental ingestion exceeding maximum daily thresholds',
    ],
    scheduleType: 'OTC',
  },
  {
    id: 'amoxicillin',
    genericName: 'Amoxicillin',
    brandNames: ['Amoxil', 'Moxatag', 'Novamox', 'Augmentin (when combined with Clavulanate)'],
    category: 'Antibiotics (Beta-lactam / Aminopenicillin)',
    generalUses: [
      'Bacterial infections of the ear, nose, throat (e.g., streptococcal pharyngitis, acute otitis media)',
      'Bacterial respiratory tract infections (pneumonia, acute exacerbation of chronic bronchitis)',
      'Helicobacter pylori eradication regimens (in combination therapy)',
    ],
    howItWorks:
      'Bactericidal antibiotic that inhibits bacterial cell wall synthesis by binding to penicillin-binding proteins (PBPs), leading to osmotic lysis and cell death.',
    commonSideEffects: [
      'Diarrhea and loose stools',
      'Nausea and stomach upset',
      'Non-allergic maculopapular rash',
      'Secondary yeast infection (oral thrush or vaginal candidiasis)',
    ],
    importantWarnings: [
      'Ineffective against viral illnesses like the common cold, flu, COVID-19, or acute bronchitis. Inappropriate use fuels global antimicrobial resistance.',
      'Complete the full course prescribed by your physician even if symptoms resolve earlier.',
      'Severe life-threatening allergic reactions (anaphylaxis) can occur in penicillin-allergic patients.',
    ],
    commonInteractions: [
      'Methotrexate: May decrease renal clearance of methotrexate, elevating toxicity.',
      'Warfarin: May prolong prothrombin time / INR by altering gut microflora.',
      'Allopurinol: Co-administration increases risk of developing a drug rash.',
    ],
    contraindications: [
      'History of severe hypersensitivity (anaphylaxis, angioedema) to penicillins or cephalosporins',
      'Infectious mononucleosis (causes high incidence of non-allergic erythematous rash)',
    ],
    storageInfo: 'Capsules/tablets at room temperature. Liquid suspensions usually require refrigeration (2°C - 8°C) and discard after 14 days.',
    generalSafety:
      'Must be taken under physician prescription. Do not share with friends or family members.',
    pregnancyWarning: 'FDA Pregnancy Category B. Generally considered safe when medically indicated during pregnancy.',
    ageSafetyWarning: 'Dosed by body weight in pediatric populations. Ensure adequate hydration.',
    whenProfessionalAdviceNecessary: [
      'Signs of allergy: hives, facial swelling, difficulty breathing (seek immediate emergency care)',
      'Severe, watery diarrhea lasting days or with blood/mucus (suspect C. difficile colitis)',
    ],
    scheduleType: 'Prescription',
  },
  {
    id: 'metformin',
    genericName: 'Metformin Hydrochloride',
    brandNames: ['Glucophage', 'Fortamet', 'Glumetza', 'Glycomet'],
    category: 'Antidiabetic Agents (Biguanides)',
    generalUses: [
      'First-line pharmacological management of Type 2 Diabetes Mellitus',
      'Off-label management of Polycystic Ovary Syndrome (PCOS)',
      'Prediabetes management in high-risk individuals',
    ],
    howItWorks:
      'Decreases hepatic glucose production (gluconeogenesis), reduces intestinal absorption of glucose, and improves peripheral insulin sensitivity via AMPK activation.',
    commonSideEffects: [
      'Gastrointestinal upset: nausea, diarrhea, abdominal cramps, flatulence (lessens when taken with meals or extended-release)',
      'Metallic taste in mouth',
      'Long-term use can reduce Vitamin B12 absorption',
    ],
    importantWarnings: [
      'Black Box Warning: Risk of Lactic Acidosis, a rare but life-threatening metabolic emergency.',
      'Must be temporarily withheld prior to and 48 hours following iodinated radiological contrast procedures in patients with reduced eGFR.',
      'Contraindicated in severe renal impairment (eGFR < 30 mL/min/1.73m2).',
    ],
    commonInteractions: [
      'Iodinated Contrast Media: Increased risk of acute kidney injury and lactic acidosis.',
      'Heavy Alcohol Consumption: Potentiates metformin effect on lactate metabolism.',
      'Carbonic Anhydrase Inhibitors (e.g., Topiramate): May increase risk of lactic acidosis.',
    ],
    contraindications: [
      'Severe renal impairment (eGFR < 30 mL/min)',
      'Acute or chronic metabolic acidosis, including diabetic ketoacidosis',
      'Severe heart failure, shock, or severe hepatic impairment',
    ],
    storageInfo: 'Store at 20°C - 25°C (68°F - 77°F). Protect from light and moisture.',
    generalSafety:
      'Does not typically cause hypoglycemia when used as monotherapy because it does not stimulate pancreatic insulin secretion.',
    pregnancyWarning:
      'Crosses the placenta. Historically insulin was preferred, but metformin is increasingly utilized under specialist obstetric endocrinology oversight.',
    ageSafetyWarning: 'Renal function must be regularly checked in elderly patients before initiation and at least annually.',
    whenProfessionalAdviceNecessary: [
      'Scheduled for surgery or contrast CT scan',
      'Symptoms of lactic acidosis: severe fatigue, muscle aches, breathing distress, unusual stomach discomfort',
    ],
    scheduleType: 'Prescription',
  },
  {
    id: 'lisinopril',
    genericName: 'Lisinopril',
    brandNames: ['Prinivil', 'Zestril', 'Qbrelis'],
    category: 'Antihypertensives (ACE Inhibitors)',
    generalUses: [
      'Treatment of essential and secondary hypertension',
      'Adjunctive therapy in heart failure with reduced ejection fraction',
      'Improvement of survival in hemodynamically stable patients within 24 hours of acute myocardial infarction',
      'Renal protection in diabetic nephropathy',
    ],
    howItWorks:
      'Competitively inhibits Angiotensin-Converting Enzyme (ACE), blocking the conversion of Angiotensin I to the potent vasoconstrictor Angiotensin II, reducing aldosterone secretion and systemic vascular resistance.',
    commonSideEffects: [
      'Persistent dry, hacking cough (due to bradykinin accumulation)',
      'Dizziness or orthostatic lightheadedness upon standing',
      'Hyperkalemia (mild elevation of blood potassium)',
      'Headache or fatigue',
    ],
    importantWarnings: [
      'Black Box Warning: Fetal Toxicity. Can cause death or injury to the developing fetus when used in pregnancy (2nd and 3rd trimesters). Discontinue immediately if pregnancy is confirmed.',
      'Angioedema risk: Sudden life-threatening swelling of face, lips, tongue, or larynx.',
    ],
    commonInteractions: [
      'Potassium Supplements & Potassium-Sparing Diuretics (Spironolactone): Danger of severe hyperkalemia.',
      'NSAIDs (Ibuprofen, Naproxen): May diminish antihypertensive effect and worsen renal function.',
      'Lithium: ACE inhibitors increase serum lithium concentrations and risk of lithium toxicity.',
    ],
    contraindications: [
      'History of ACE-inhibitor associated angioedema or hereditary angioedema',
      'Concomitant use with aliskiren in patients with diabetes',
      'Pregnancy',
    ],
    storageInfo: 'Store at 15°C - 30°C (59°F - 86°F) in a tightly closed container.',
    generalSafety: 'Serum creatinine and potassium should be tested within 1–2 weeks of starting or dose escalation.',
    pregnancyWarning: 'STRICT CONTRAINDICATION in pregnancy due to oligohydramnios, fetal renal failure, and neonatal hypotension.',
    ageSafetyWarning: 'Dose carefully in elderly patients due to greater frequency of decreased renal function.',
    whenProfessionalAdviceNecessary: [
      'Persistent dry cough that disrupts sleep or daily functioning',
      'Sudden swelling of lips, tongue, face, or throat (EMERGENCY)',
    ],
    scheduleType: 'Prescription',
  },
  {
    id: 'atorvastatin',
    genericName: 'Atorvastatin Calcium',
    brandNames: ['Lipitor', 'Atorva', 'Storvas'],
    category: 'Lipid-Lowering Agents (HMG-CoA Reductase Inhibitors / Statins)',
    generalUses: [
      'Reduction of elevated total cholesterol, LDL-C, and triglycerides',
      'Primary and secondary prevention of cardiovascular events (heart attack, stroke)',
    ],
    howItWorks:
      'Competitively inhibits 3-hydroxy-3-methylglutaryl-coenzyme A (HMG-CoA) reductase, the rate-limiting enzyme in cholesterol biosynthesis, up-regulating hepatic LDL receptors.',
    commonSideEffects: [
      'Myalgia (muscle aches or stiffness)',
      'Mild gastrointestinal symptoms (diarrhea, dyspepsia)',
      'Mild elevations in serum transaminases (ALT/AST)',
    ],
    importantWarnings: [
      'Rare risk of Rhabdomyolysis: Severe skeletal muscle breakdown leading to acute renal failure.',
      'Grapefruit and grapefruit juice inhibit CYP3A4 enzymes and significantly increase atorvastatin blood levels; avoid large quantities.',
    ],
    commonInteractions: [
      'CYP3A4 Inhibitors (Clarithromycin, Itraconazole, Ketoconazole): Greatly increase statin toxicity.',
      'Gemfibrozil and other fibrates: Substantially increases risk of severe myopathy.',
      'Cyclosporine: Increases statin exposure markedly.',
    ],
    contraindications: [
      'Active acute liver disease or unexplained persistent elevation of hepatic enzymes',
      'Hypersensitivity to atorvastatin',
      'Pregnancy and breastfeeding',
    ],
    storageInfo: 'Store at 20°C - 25°C (68°F - 77°F). Keep dry.',
    generalSafety: 'Cardiovascular benefit in reducing heart attacks is supported by massive randomized clinical trials.',
    pregnancyWarning: 'Contraindicated during pregnancy and lactation.',
    ageSafetyWarning: 'Monitor closely for muscle complaints in older adults.',
    whenProfessionalAdviceNecessary: [
      'Unexplained severe muscle pain, tenderness, or weakness',
      'Dark, tea-colored urine (potential rhabdomyolysis emergency)',
    ],
    scheduleType: 'Prescription',
  },
  {
    id: 'warfarin',
    genericName: 'Warfarin Sodium',
    brandNames: ['Coumadin', 'Jantoven'],
    category: 'Anticoagulants (Vitamin K Antagonists)',
    generalUses: [
      'Prophylaxis and treatment of venous thromboembolism (DVT and PE)',
      'Thromboembolism prevention in patients with atrial fibrillation or mechanical prosthetic heart valves',
    ],
    howItWorks:
      'Inhibits Vitamin K epoxide reductase complex 1 (VKORC1), depleting functional Vitamin K reserves needed for gamma-carboxylation of clotting factors II, VII, IX, X and proteins C and S.',
    commonSideEffects: [
      'Bleeding (minor bruising, prolonged clotting from cuts, gingival bleeding)',
      'Skin necrosis (rare)',
    ],
    importantWarnings: [
      'Narrow Therapeutic Index drug: Requires frequent blood monitoring (INR).',
      'High risk of life-threatening major bleeding.',
      'Dietary Vitamin K (spinach, kale, broccoli) must remain consistent, not drastically fluctuating.',
    ],
    commonInteractions: [
      'NSAIDs (Aspirin, Ibuprofen): Markedly increases major GI bleeding risk.',
      'Broad-spectrum antibiotics: Diminishes gut Vitamin K synthesis, spiking INR.',
      'St. John’s Wort & Carbamazepine: Induces CYP enzymes, lowering INR and risking blood clots.',
    ],
    contraindications: [
      'Active pathological bleeding or hemorrhagic tendencies',
      'Pregnancy (teratogenic, except in certain high-risk mechanical valve scenarios)',
      'Severe uncontrolled hypertension',
    ],
    storageInfo: 'Store at room temperature protected from light.',
    generalSafety: 'Carry a medical alert identification card stating you are taking an anticoagulant.',
    pregnancyWarning: 'Contraindicated in pregnancy due to fetal warfarin syndrome and bleeding risk.',
    ageSafetyWarning: 'High risk of subdural hematoma from falls in elderly patients.',
    whenProfessionalAdviceNecessary: [
      'Any signs of unusual bleeding, black stools, or severe fall/head strike',
      'Prior to any dental, surgical, or invasive procedure',
    ],
    scheduleType: 'Prescription',
  },
  {
    id: 'ibuprofen',
    genericName: 'Ibuprofen',
    brandNames: ['Advil', 'Motrin', 'Brufen', 'Nurofen'],
    category: 'Nonsteroidal Anti-inflammatory Drugs (NSAIDs)',
    generalUses: [
      'Relief of mild to moderate pain (dental pain, headache, dysmenorrhea, muscular aches)',
      'Reduction of inflammation in osteoarthritis and rheumatoid arthritis',
      'Reduction of fever',
    ],
    howItWorks:
      'Non-selective reversible inhibition of cyclooxygenase enzymes (COX-1 and COX-2), reducing the synthesis of inflammatory prostaglandins.',
    commonSideEffects: [
      'Dyspepsia, heartburn, epigastric distress',
      'Nausea and gastrointestinal irritation',
      'Fluid retention and mild blood pressure elevation',
    ],
    importantWarnings: [
      'Black Box Warning: Increased risk of serious cardiovascular thrombotic events (myocardial infarction, stroke).',
      'Black Box Warning: Serious gastrointestinal bleeding, ulceration, and perforation which can be fatal.',
      'Avoid in suspected dengue fever or active peptic ulcer disease.',
    ],
    commonInteractions: [
      'Anticoagulants (Warfarin, Apixaban): Major bleeding danger.',
      'ACE Inhibitors / ARBs: Blunts BP lowering and elevates acute kidney injury risk.',
      'Lithium: Decreases renal clearance of lithium, risking toxicity.',
    ],
    contraindications: [
      'History of asthma or urticaria triggered by aspirin or other NSAIDs',
      'Active gastrointestinal bleed or peptic ulcer disease',
      'Severe heart failure or severe renal failure',
      'In the setting of coronary artery bypass graft (CABG) surgery',
    ],
    storageInfo: 'Store at 20°C - 25°C. Keep away from excessive moisture.',
    generalSafety: 'Use the lowest effective dose for the shortest possible duration.',
    pregnancyWarning: 'Avoid during pregnancy, particularly from 20 weeks onward due to risk of premature closure of ductus arteriosus and oligohydramnios.',
    ageSafetyWarning: 'Heightened risk of GI ulceration and renal toxicity in adults over 65.',
    whenProfessionalAdviceNecessary: [
      'Black, bloody, or tarry stools',
      'Chest pain, shortness of breath, or sudden weakness',
    ],
    scheduleType: 'OTC',
  },
];

export const HEALTH_ARTICLES: HealthArticle[] = [
  {
    id: 'antibiotic-resistance-crisis',
    title: 'The Silent Threat: Understanding Antibiotic Resistance and Responsible Medicine Use',
    summary:
      'How the misuse and over-prescription of antibiotics fuels resistant superbugs, and what patients, students, and healthcare professionals must do to protect modern medicine.',
    category: 'Medication Safety',
    readTime: '6 min read',
    publishedDate: '2026-09-15',
    author: 'DRUGAI Clinical Safety Board',
    organization: 'World Health Organization (WHO) Collaborating Group',
    content: [
      'Antibiotics are among the greatest triumphs of 20th-century medicine. Before Alexander Fleming discovered penicillin in 1928, simple bacterial infections following minor scratches, dental procedures, or childbirth were routinely fatal. However, their very success has fostered widespread complacency.',
      'Every time an antibiotic is taken unnecessarily—such as for common viral colds, influenza, or viral sore throats—susceptible bacteria are eliminated while naturally resistant mutants survive and proliferate. These resistant bacteria can then share their resistance genes through plasmids with other species.',
      'According to global epidemiological studies, antimicrobial resistance (AMR) is already directly responsible for over 1.2 million deaths annually worldwide. If left unchecked, projections warn that resistant infections could claim 10 million lives annually by 2050.',
      'Responsible patient practices include never demanding antibiotics for viral symptoms, never saving leftover antibiotics for the next illness, never sharing prescription drugs with relatives, and always finishing the prescribed regimen exactly as instructed by a certified doctor.',
    ],
    keyTakeaways: [
      'Antibiotics kill bacteria, NEVER viruses (colds, flu, bronchitis are mostly viral).',
      'Taking antibiotics improperly accelerates bacterial resistance worldwide.',
      'Never share prescription medicines or use leftovers from a prior illness.',
      'Always wash hands, maintain vaccinations, and complete prescribed treatments.',
    ],
    references: [
      'WHO Global Action Plan on Antimicrobial Resistance (2025 Revision)',
      'CDC Core Elements of Hospital and Outpatient Antibiotic Stewardship',
      'The Lancet Infectious Diseases - Global Burden of Bacterial Antimicrobial Resistance',
    ],
  },
  {
    id: 'safe-medicine-storage-disposal',
    title: 'Safe Medicine Storage and Disposal: Protecting Your Family and the Environment',
    summary:
      'Where to store home medicines, why the bathroom cabinet is often the worst spot, and how to safely dispose of expired pharmaceuticals without contaminating waterways.',
    category: 'Drug Awareness',
    readTime: '5 min read',
    publishedDate: '2026-08-28',
    author: 'Pharmacy Safety Directorate',
    organization: 'FDA / EPA Public Health Standards',
    content: [
      'Many households instinctively store their medicines in the bathroom cabinet. In reality, the humidity and temperature fluctuations produced by hot showers accelerate chemical degradation of tablets, capsules, and active pharmaceutical ingredients.',
      'Medicines should almost always be kept in a cool, dry place away from direct sunlight, such as a high kitchen cabinet or bedroom closet drawer safely out of sight and reach of curious children and domestic pets.',
      'Flushing unwanted pills down the toilet or pouring liquid remedies down the drain can introduce bioactive chemicals into municipal water supplies, rivers, and aquatic ecosystems. Dedicated pharmaceutical take-back programs or safe disposal bags are the gold standard.',
    ],
    keyTakeaways: [
      'Never store medicines in damp, warm bathrooms.',
      'Keep all medications in their original child-resistant containers with labels intact.',
      'Utilize authorized pharmacy drop-box bins for expired or unused drugs.',
      'Keep the national poison control hotline easily accessible in your home.',
    ],
    references: [
      'U.S. Food and Drug Administration (FDA) - Where and How to Dispose of Unused Medicines',
      'American Society of Health-System Pharmacists Guidelines on Safe Medication Storage',
    ],
  },
  {
    id: 'stroke-warning-signs-fast',
    title: 'Recognizing Stroke Symptoms: The F.A.S.T. Protocol Can Save a Life',
    summary:
      'A stroke is a medical emergency where every passing second counts. Learn the critical neurological signs and how rapid action preserves brain tissue.',
    category: 'Emergency Care',
    readTime: '4 min read',
    publishedDate: '2026-07-19',
    author: 'Neurology Education Taskforce',
    organization: 'American Stroke Association & Stroke Alliance',
    content: [
      'When blood flow to a portion of the human brain is suddenly blocked (ischemic stroke) or when a cerebral blood vessel ruptures (hemorrhagic stroke), brain cells rapidly become deprived of oxygen and glucose, dying at a rate of roughly 1.9 million neurons every single minute.',
      'The acronym F.A.S.T. is the internationally validated mnemonic for rapid stroke recognition: F - Face Drooping (one side of the face hangs or smile is uneven); A - Arm Weakness (one arm drifts downward when both are raised); S - Speech Difficulty (slurred speech or inability to form words); T - Time to Call Emergency Services (call ambulance immediately).',
      'Do not wait to see if symptoms improve. Do NOT give the person aspirin without emergency evaluation, as aspirin can be catastrophic if the stroke is hemorrhagic (bleeding).',
    ],
    keyTakeaways: [
      'F = Face Drooping, A = Arm Weakness, S = Speech Difficulty, T = Time to Call Emergency.',
      'Brain tissue dies rapidly ("Time is Brain")—every minute saved preserves neurological function.',
      'Never administer aspirin until a brain CT scan has ruled out hemorrhage at the hospital.',
    ],
    references: [
      'AHA/ASA Guidelines for the Early Management of Patients with Acute Ischemic Stroke',
      'World Stroke Organization (WSO) Global Campaign',
    ],
  },
  {
    id: 'counterfeit-medicine-awareness',
    title: 'Combating Counterfeit Medicines: How to Spot Fakes and Stay Safe',
    summary:
      'Substandard and falsified medical products pose catastrophic risks. How to inspect packaging, verify authenticity, and identify authorized pharmacies.',
    category: 'Drug Awareness',
    readTime: '5 min read',
    publishedDate: '2026-06-11',
    author: 'Global Pharmaceutical Integrity Cell',
    organization: 'Interpol & WHO Counterfeit Drug Initiative',
    content: [
      'Falsified medical products range from pills containing zero active pharmaceutical ingredient, incorrect dosages, to dangerous products contaminated with toxic industrial dyes, heavy metals, or fentanyl.',
      'Always inspect the packaging carefully: look for blurry fonts, spelling errors, mismatched batch numbers, missing security holograms, or tamper-evident seals that appear breached.',
      'Purchase medications solely from state-licensed physical pharmacies or verified online pharmacies bearing official regulatory accreditation seals.',
    ],
    keyTakeaways: [
      'Only purchase from verified, government-licensed pharmacies.',
      'Be wary of websites selling prescription drugs without requiring a valid prescription.',
      'Check packaging for spelling errors, missing expiration dates, or altered batch numbers.',
      'Report suspected fake medicines to national regulatory authorities immediately.',
    ],
    references: [
      'WHO Substandard and Falsified Medical Products Global Surveillance System',
      'FDA BeSafeRx: Your Source for Online Pharmacy Information',
    ],
  },
];

export const EMERGENCY_HOSPITALS_DATA: EmergencyHospital[] = [
  {
    id: 'hosp-1',
    name: 'Metropolitan Central Medical Center & Trauma Institute',
    city: 'New York',
    distanceKm: 1.4,
    address: '525 East 68th Street, New York, NY 10065',
    phone: '+1 (212) 746-5454',
    emergencyDepartmentOpen24x7: true,
    traumaLevel: 'Level 1 Trauma Center',
    ambulanceContact: '911',
    coordinates: { lat: 40.7651, lng: -73.9542 },
  },
  {
    id: 'hosp-2',
    name: 'St. Jude University Emergency & Critical Care Hospital',
    city: 'London',
    distanceKm: 2.1,
    address: 'Westminster Bridge Rd, Lambeth, London SE1 7EH',
    phone: '+44 20 7188 7188',
    emergencyDepartmentOpen24x7: true,
    traumaLevel: 'Major Trauma Centre',
    ambulanceContact: '999',
    coordinates: { lat: 51.4988, lng: -0.1189 },
  },
  {
    id: 'hosp-3',
    name: 'Apollo Health City Emergency Hospital',
    city: 'Hyderabad',
    distanceKm: 2.8,
    address: 'Road No 72, Film Nagar, Jubilee Hills, Hyderabad 500033',
    phone: '+91 40 2360 7777',
    emergencyDepartmentOpen24x7: true,
    traumaLevel: '24/7 Super Specialty Trauma',
    ambulanceContact: '108',
    coordinates: { lat: 17.4265, lng: 78.4116 },
  },
  {
    id: 'hosp-4',
    name: 'All India Institute of Medical Sciences (AIIMS) Emergency',
    city: 'New Delhi',
    distanceKm: 3.2,
    address: 'Sri Aurobindo Marg, Ansari Nagar East, New Delhi 110029',
    phone: '+91 11 2658 8500',
    emergencyDepartmentOpen24x7: true,
    traumaLevel: 'Apex Level 1 Apex Trauma Centre',
    ambulanceContact: '102 / 108',
    coordinates: { lat: 28.5672, lng: 77.2100 },
  },
  {
    id: 'hosp-5',
    name: 'Bay Area Regional Emergency & Stroke Center',
    city: 'San Francisco',
    distanceKm: 1.8,
    address: '1001 Potrero Ave, San Francisco, CA 94110',
    phone: '+1 (415) 206-8000',
    emergencyDepartmentOpen24x7: true,
    traumaLevel: 'Level 1 Comprehensive Trauma',
    ambulanceContact: '911',
    coordinates: { lat: 37.7558, lng: -122.4055 },
  },
  {
    id: 'hosp-6',
    name: 'Sydney Royal Prince Alfred Emergency Hospital',
    city: 'Sydney',
    distanceKm: 2.5,
    address: 'Missenden Rd, Camperdown NSW 2050, Australia',
    phone: '+61 2 9515 6111',
    emergencyDepartmentOpen24x7: true,
    traumaLevel: 'Adult Major Trauma Service',
    ambulanceContact: '000',
    coordinates: { lat: -33.8893, lng: 151.1834 },
  },
];

export const STUDENT_QUIZZES: QuizQuestion[] = [
  {
    id: 'q1',
    category: 'Pharmacology',
    question: 'Why is aspirin contraindicated in a patient confirmed to have active Dengue fever?',
    options: [
      'Aspirin causes immediate bronchospasm in all viral fevers',
      'Aspirin inhibits platelets and increases the risk of severe life-threatening hemorrhaging',
      'Aspirin blocks the absorption of paracetamol in the kidneys',
      'Aspirin induces acute hepatic encephalopathy only in adults',
    ],
    correctIndex: 1,
    explanation:
      'Dengue virus infection induces severe thrombocytopenia (platelet depletion) and vascular permeability. Aspirin irreversibly inhibits platelet COX-1, dramatically worsening hemorrhage risk.',
  },
  {
    id: 'q2',
    category: 'Pharmacology',
    question: 'Which enzyme is inhibited by Atorvastatin to reduce endogenous cholesterol synthesis?',
    options: [
      'Angiotensin Converting Enzyme (ACE)',
      'HMG-CoA Reductase',
      'Cyclooxygenase-2 (COX-2)',
      'Cytochrome P450 3A4',
    ],
    correctIndex: 1,
    explanation:
      'Statins competitively inhibit 3-hydroxy-3-methylglutaryl-coenzyme A (HMG-CoA) reductase, which is the rate-limiting step in cholesterol biosynthesis.',
  },
  {
    id: 'q3',
    category: 'Pathology',
    question: 'What is the diagnostic HbA1c threshold for confirming Type 2 Diabetes Mellitus?',
    options: [
      '>= 5.7%',
      '>= 6.0%',
      '>= 6.5%',
      '>= 7.5%',
    ],
    correctIndex: 2,
    explanation:
      'According to ADA and WHO diagnostic criteria, an HbA1c of 6.5% or higher confirms diabetes mellitus (normal is below 5.7%, prediabetes is 5.7-6.4%).',
  },
  {
    id: 'q4',
    category: 'Emergency Care',
    question: 'What does the "A" stand for in the stroke assessment protocol F.A.S.T.?',
    options: [
      'Airway clearance',
      'Arm weakness',
      'Alertness score',
      'Arterial pressure',
    ],
    correctIndex: 1,
    explanation:
      'In the F.A.S.T. mnemonic: F = Face drooping, A = Arm weakness, S = Speech difficulty, T = Time to call emergency services.',
  },
  {
    id: 'q5',
    category: 'Pharmacology',
    question: 'Combining Lisinopril with Spironolactone requires close clinical vigilance for which electrolyte imbalance?',
    options: [
      'Hypokalemia (Low potassium)',
      'Hyperkalemia (High potassium)',
      'Hyponatremia (Low sodium)',
      'Hypercalcemia (High calcium)',
    ],
    correctIndex: 1,
    explanation:
      'Both ACE inhibitors (Lisinopril) and potassium-sparing diuretics (Spironolactone) reduce potassium excretion, creating a potent synergistic risk for dangerous hyperkalemia.',
  },
];

export const MEDICAL_TERMS: MedicalTerm[] = [
  {
    term: 'Pharmacokinetics (PK)',
    pronunciation: 'fahr-muh-koh-kih-NET-iks',
    simpleDefinition: 'What the body does to a drug: how it absorbs, moves, breaks down, and eliminates it (ADME).',
    clinicalDefinition:
      'The quantitative study of the time course of drug absorption, distribution, metabolism, and excretion within an organism.',
    exampleContext: 'Renal impairment drastically alters the pharmacokinetics of water-soluble antibiotics.',
  },
  {
    term: 'Pharmacodynamics (PD)',
    pronunciation: 'fahr-muh-koh-dye-NAM-iks',
    simpleDefinition: 'What the drug does to the body: its biochemical and physiological effects on cells and receptors.',
    clinicalDefinition:
      'The study of the biochemical and physiological effects of drugs and their mechanisms of action at macromolecular targets.',
    exampleContext: 'Beta-blockers exert their pharmacodynamics by competitively antagonizing beta-1 adrenergic receptors.',
  },
  {
    term: 'Half-Life (t1/2)',
    pronunciation: 'haf-lyfe',
    simpleDefinition: 'The time it takes for the concentration of a drug in the bloodstream to be cut in half.',
    clinicalDefinition:
      'The time required for the plasma concentration of a drug to decrease by 50% through elimination and metabolism processes.',
    exampleContext: 'Drugs with a long half-life require less frequent daily dosing to maintain steady-state plasma levels.',
  },
  {
    term: 'Contraindication',
    pronunciation: 'kon-truh-in-dih-KAY-shun',
    simpleDefinition: 'A specific condition or factor that makes a particular medicine or medical treatment unsafe to use.',
    clinicalDefinition:
      'A condition or factor that serves as a reason to withhold a certain medical treatment due to the harm that it would cause the patient.',
    exampleContext: 'Active peptic ulcer disease is an absolute contraindication for high-dose systemic NSAID therapy.',
  },
  {
    term: 'Bioavailability',
    pronunciation: 'bye-oh-uh-vay-luh-BIL-ih-tee',
    simpleDefinition: 'The percentage of an administered drug that actually reaches the bloodstream unchanged to do its job.',
    clinicalDefinition:
      'The fraction of an administered dose of unchanged drug that reaches the systemic circulation.',
    exampleContext: 'Intravenous drugs have 100% bioavailability by definition, whereas oral bioavailability is subject to first-pass metabolism.',
  },
];

export const COMMON_INTERACTION_PRESETS = [
  {
    name: 'Warfarin + Aspirin',
    drugs: ['Warfarin', 'Aspirin'],
    description: 'High risk of severe bleeding and hemorrhage due to additive anticoagulation & antiplatelet action.',
  },
  {
    name: 'Lisinopril + Spironolactone',
    drugs: ['Lisinopril', 'Spironolactone'],
    description: 'Dangerous additive hyperkalemia (high blood potassium) risking cardiac arrest.',
  },
  {
    name: 'Atorvastatin + Clarithromycin',
    drugs: ['Atorvastatin', 'Clarithromycin'],
    description: 'Inhibition of CYP3A4 metabolism, risking severe statin toxicity and rhabdomyolysis.',
  },
  {
    name: 'Metformin + CT Contrast Dye',
    drugs: ['Metformin', 'Iodinated Contrast'],
    description: 'Risk of contrast-induced acute kidney injury leading to toxic metformin lactic acidosis.',
  },
  {
    name: 'Sertraline + Tramadol',
    drugs: ['Sertraline', 'Tramadol'],
    description: 'Serotonin syndrome: tremor, hyperthermia, confusion, and autonomic instability.',
  },
  {
    name: 'Ciprofloxacin + Calcium Antacid',
    drugs: ['Ciprofloxacin', 'Calcium Carbonate'],
    description: 'Chelation complex formation blocking antibiotic absorption, risking treatment failure.',
  },
];
