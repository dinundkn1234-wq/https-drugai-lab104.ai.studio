import React, { useState } from 'react';
import {
  Activity,
  Users,
  ShieldCheck,
  Pill,
  FileText,
  AlertTriangle,
  CheckCircle2,
  Lock,
  Globe,
  BarChart3,
  Bot,
  Settings,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { DISEASES_DATA, MEDICINES_DATA } from '../data/mockData';

export const AdminDashboard: React.FC = () => {
  const { user } = useAuth();
  const [activeSection, setActiveSection] = useState<'analytics' | 'clinicians' | 'medicines' | 'ai-settings'>('analytics');

  // Simulated pending clinician verification list
  const [clinicians, setClinicians] = useState([
    {
      id: 'c1',
      name: 'Dr. Sarah Lin, MD',
      email: 's.lin@metromedical.org',
      license: 'MD-99482-NY',
      institution: 'Mount Sinai Hospital',
      status: 'Verified',
    },
    {
      id: 'c2',
      name: 'Dr. Rajesh Rao, MBBS, MD',
      email: 'rajesh.rao@aiims.edu',
      license: 'MCI-184920',
      institution: 'AIIMS New Delhi',
      status: 'Pending',
    },
    {
      id: 'c3',
      name: 'Dr. Michael Chen, PharmD',
      email: 'm.chen@ucsf.edu',
      license: 'RPH-88491-CA',
      institution: 'UCSF Medical Center',
      status: 'Pending',
    },
  ]);

  const handleApproveClinician = (id: string) => {
    setClinicians(
      clinicians.map((c) => (c.id === id ? { ...c, status: 'Verified' } : c))
    );
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 animate-fade-in pb-16 space-y-8">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-200 dark:border-slate-800">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-teal-50 dark:bg-teal-950 text-teal-700 dark:text-teal-300 text-xs font-bold mb-2">
            <ShieldCheck className="w-4 h-4" />
            <span>DRUGAI Administrative & Clinical Governance</span>
          </div>
          <h1 className="text-3xl font-black text-slate-900 dark:text-white">
            System Administration Console
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            Oversee clinical content catalog, clinician verifications, AI safety guardrails, and telemetry.
          </p>
        </div>

        <div className="px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-bold text-slate-600 dark:text-slate-300 flex items-center gap-2">
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
          <span>Core AI Services Healthy</span>
        </div>
      </div>

      {/* Analytics Stat Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
          <div className="text-xs font-bold text-slate-400 uppercase">Interaction Screenings</div>
          <div className="text-2xl font-black text-slate-900 dark:text-white mt-1">42,891</div>
          <div className="text-[10px] text-emerald-600 font-semibold mt-1">+18% this month</div>
        </div>
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
          <div className="text-xs font-bold text-slate-400 uppercase">Verified Clinicians</div>
          <div className="text-2xl font-black text-slate-900 dark:text-white mt-1">1,240</div>
          <div className="text-[10px] text-teal-600 font-semibold mt-1">Across 14 countries</div>
        </div>
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
          <div className="text-xs font-bold text-slate-400 uppercase">Supported Languages</div>
          <div className="text-2xl font-black text-slate-900 dark:text-white mt-1">11</div>
          <div className="text-[10px] text-indigo-600 font-semibold mt-1">100% localized dictionaries</div>
        </div>
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
          <div className="text-xs font-bold text-slate-400 uppercase">Emergency Triage Intercepts</div>
          <div className="text-2xl font-black text-red-600 mt-1">814</div>
          <div className="text-[10px] text-red-500 font-semibold mt-1">Prompted 911 / 112 directly</div>
        </div>
      </div>

      {/* Admin Nav Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 dark:border-slate-800 pb-3">
        {[
          { id: 'analytics', label: 'Platform Telemetry', icon: BarChart3 },
          { id: 'clinicians', label: 'Clinician Verifications', icon: Users },
          { id: 'medicines', label: 'Catalog Governance', icon: Pill },
          { id: 'ai-settings', label: 'AI Safety & Guardrails', icon: Bot },
        ].map((t) => {
          const Icon = t.icon;
          return (
            <button
              key={t.id}
              onClick={() => setActiveSection(t.id as any)}
              className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-colors ${
                activeSection === t.id
                  ? 'bg-teal-600 text-white shadow-sm'
                  : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-100'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{t.label}</span>
            </button>
          );
        })}
      </div>

      {/* 1. CLINICIAN VERIFICATION TAB */}
      {activeSection === 'clinicians' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm space-y-4">
          <h3 className="text-base font-bold text-slate-900 dark:text-white">
            Medical Practitioner Credential Queue
          </h3>
          <p className="text-xs text-slate-500">
            Verify medical licensing board registrations to grant verified badges and professional reference access.
          </p>

          <div className="divide-y divide-slate-100 dark:divide-slate-800">
            {clinicians.map((c) => (
              <div key={c.id} className="py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                <div>
                  <p className="font-bold text-slate-900 dark:text-white text-sm">{c.name}</p>
                  <p className="text-slate-500">{c.email} • {c.institution}</p>
                  <p className="text-teal-600 font-mono mt-0.5">License: {c.license}</p>
                </div>
                <div className="flex items-center gap-2">
                  <span
                    className={`px-2.5 py-1 rounded-full font-bold text-[10px] ${
                      c.status === 'Verified'
                        ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                        : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                    }`}
                  >
                    {c.status}
                  </span>
                  {c.status === 'Pending' && (
                    <button
                      onClick={() => handleApproveClinician(c.id)}
                      className="px-3 py-1 rounded-lg bg-teal-600 hover:bg-teal-700 text-white font-bold"
                    >
                      Approve License
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 2. CATALOG GOVERNANCE TAB */}
      {activeSection === 'medicines' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              Approved Monograph Catalog ({MEDICINES_DATA.length} Medicines, {DISEASES_DATA.length} Diseases)
            </h3>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {MEDICINES_DATA.map((m) => (
              <div key={m.id} className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-xs flex items-center justify-between">
                <div>
                  <p className="font-bold text-slate-900 dark:text-white">{m.genericName}</p>
                  <p className="text-slate-400">{m.category} • {m.scheduleType}</p>
                </div>
                <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 font-bold">
                  Published
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 3. AI SETTINGS & GUARDRAILS TAB */}
      {activeSection === 'ai-settings' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm space-y-6">
          <h3 className="text-base font-bold text-slate-900 dark:text-white">
            Clinical AI Safety & Guardrails Policy Engine
          </h3>
          <div className="space-y-4 text-xs">
            <div className="p-4 rounded-2xl bg-teal-50 dark:bg-teal-950/40 border border-teal-200 dark:border-teal-800 flex items-start gap-3">
              <CheckCircle2 className="w-5 h-5 text-teal-600 shrink-0 mt-0.5" />
              <div>
                <p className="font-bold text-teal-950 dark:text-teal-200">Rule 1: Strict Non-Diagnostic Enforcement</p>
                <p className="text-teal-900 dark:text-teal-300 mt-0.5">
                  The AI is systemically instructed to reject making final medical diagnoses or assigning personalized therapeutic regimens.
                </p>
              </div>
            </div>
            <div className="p-4 rounded-2xl bg-teal-50 dark:bg-teal-950/40 border border-teal-200 dark:border-teal-800 flex items-start gap-3">
              <CheckCircle2 className="w-5 h-5 text-teal-600 shrink-0 mt-0.5" />
              <div>
                <p className="font-bold text-teal-950 dark:text-teal-200">Rule 2: Automated Red-Flag Emergency Triage</p>
                <p className="text-teal-900 dark:text-teal-300 mt-0.5">
                  Any user prompt containing severe acute keywords (chest pain, stroke symptoms, respiratory arrest, severe hemorrhage) automatically triggers the high-priority Red Emergency Banner directing to local emergency numbers.
                </p>
              </div>
            </div>
            <div className="p-4 rounded-2xl bg-teal-50 dark:bg-teal-950/40 border border-teal-200 dark:border-teal-800 flex items-start gap-3">
              <CheckCircle2 className="w-5 h-5 text-teal-600 shrink-0 mt-0.5" />
              <div>
                <p className="font-bold text-teal-950 dark:text-teal-200">Rule 3: Prescription Drug Interaction Transparency</p>
                <p className="text-teal-900 dark:text-teal-300 mt-0.5">
                  All interaction check outputs must include pharmacological mechanisms, clinical signs, and explicit questions for the user's personal doctor or pharmacist.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 4. TELEMETRY TAB */}
      {activeSection === 'analytics' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm space-y-4">
          <h3 className="text-base font-bold text-slate-900 dark:text-white">
            System Telemetry & Health Metrics
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
              <p className="text-slate-400 font-semibold">Gemini 3.8 Flash Latency (p95)</p>
              <p className="text-xl font-bold text-slate-900 dark:text-white mt-1">420 ms</p>
              <p className="text-[10px] text-emerald-500 font-semibold mt-1">Optimal execution</p>
            </div>
            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
              <p className="text-slate-400 font-semibold">Interaction Screening Success Rate</p>
              <p className="text-xl font-bold text-slate-900 dark:text-white mt-1">99.98%</p>
              <p className="text-[10px] text-emerald-500 font-semibold mt-1">Active fallback redundancy</p>
            </div>
            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
              <p className="text-slate-400 font-semibold">Active Geolocation Nodes</p>
              <p className="text-xl font-bold text-slate-900 dark:text-white mt-1">Global 24/7 ERs</p>
              <p className="text-[10px] text-teal-500 font-semibold mt-1">Zero persistent PII stored</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
