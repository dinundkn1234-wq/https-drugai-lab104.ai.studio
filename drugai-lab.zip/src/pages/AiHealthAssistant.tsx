import React, { useState, useRef, useEffect } from 'react';
import {
  Bot,
  Send,
  Sparkles,
  AlertTriangle,
  ShieldAlert,
  ShieldCheck,
  User,
  RefreshCw,
  HelpCircle,
  Stethoscope,
  Volume2,
  Globe,
  Mic,
  MicOff,
  Copy,
  Check,
} from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import { SupportedLanguage } from '../types';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  isEmergency?: boolean;
  timestamp: string;
  detectedLang?: string;
}

const LANGUAGE_OPTIONS: Array<{ code: SupportedLanguage; label: string; nativeName: string; speechCode: string }> = [
  { code: 'English', label: 'English', nativeName: 'English', speechCode: 'en-US' },
  { code: 'Telugu', label: 'Telugu', nativeName: 'తెలుగు', speechCode: 'te-IN' },
  { code: 'Hindi', label: 'Hindi', nativeName: 'हिन्दी', speechCode: 'hi-IN' },
  { code: 'Tamil', label: 'Tamil', nativeName: 'தமிழ்', speechCode: 'ta-IN' },
  { code: 'Kannada', label: 'Kannada', nativeName: 'ಕನ್ನಡ', speechCode: 'kn-IN' },
  { code: 'Malayalam', label: 'Malayalam', nativeName: 'മലയാളം', speechCode: 'ml-IN' },
  { code: 'Marathi', label: 'Marathi', nativeName: 'मराठी', speechCode: 'mr-IN' },
  { code: 'Bengali', label: 'Bengali', nativeName: 'বাংলা', speechCode: 'bn-IN' },
  { code: 'Gujarati', label: 'Gujarati', nativeName: 'ગુજરાતી', speechCode: 'gu-IN' },
  { code: 'Punjabi', label: 'Punjabi', nativeName: 'ਪੰਜਾਬੀ', speechCode: 'pa-IN' },
  { code: 'Urdu', label: 'Urdu', nativeName: 'اردو', speechCode: 'ur-PK' },
  { code: 'Spanish', label: 'Spanish', nativeName: 'Español', speechCode: 'es-ES' },
];

const LOCALIZED_QUESTIONS: Record<string, string[]> = {
  Telugu: [
    'జ్వరం ఎందుకు వస్తుంది?',
    'మధుమేహం (షుగర్) ప్రారంభ లక్షణాలు ఏమిటి?',
    'పారాసిటమాల్ వాడేటప్పుడు తీసుకోవాల్సిన జాగ్రత్తలు ఏమిటి?',
    'బీపీ (రక్తపోటు) నియంత్రణకు జీవనశైలి మార్పులు ఏమిటి?',
    'గుండెపోటు హెచ్చరిక సంకేతాలు ఏమిటి?',
  ],
  Hindi: [
    'बुखार के सामान्य कारण क्या होते हैं?',
    'मधुमेह (डायबिटीज) के शुरुआती लक्षण क्या हैं?',
    'पैरासिटामोल लेते समय क्या सावधानियां रखनी चाहिए?',
    'हाई ब्लड प्रेशर को नियंत्रित करने के तरीके क्या हैं?',
    'दिल के दौरे के चेतावनी संकेत क्या हैं?',
  ],
  Tamil: [
    'காய்ச்சல் ஏற்படுவதற்கான காரணங்கள் என்ன?',
    'நீரிழிவு நோயின் ஆரம்ப அறிகுறிகள் என்ன?',
    'பாராசிட்டமால் உட்கொள்ளும் போது என்ன முன்னெச்சரிக்கைகள் தேவை?',
    'மாரடைப்பின் எச்சரிக்கை அறிகுறிகள் என்ன?',
  ],
  English: [
    'What causes a high fever and when to see a doctor?',
    'What are early signs of Type 2 Diabetes?',
    'What precautions should I know about taking Paracetamol?',
    'What are the emergency warning signs of a heart attack or stroke?',
    'What is the difference between generic and brand-name drugs?',
  ],
};

export const AiHealthAssistant: React.FC<{ onOpenEmergency: () => void }> = ({
  onOpenEmergency,
}) => {
  const { language, setLanguage } = useLanguage();
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'welcome_1',
      role: 'assistant',
      content: `Hello! I am the **DRUGAI Multilingual Health Assistant**.\n\n🌍 **Smart Language Engine Active:** You can ask me questions in **Telugu (తెలుగు), Hindi (हिन्दी), Tamil (தமிழ்), Kannada (ಕನ್ನಡ), English**, or any regional language. I will automatically detect your language and reply directly in that native script.\n\n*Important Clinical Safety Notice:* I provide healthcare education only. I cannot make personal diagnoses or prescribe medications. In an emergency, call **108 / 112 / 911** immediately.`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [beginnerMode, setBeginnerMode] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [speakingMsgId, setSpeakingMsgId] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const recognitionRef = useRef<any>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, loading]);

  const activeLangConfig = LANGUAGE_OPTIONS.find((l) => l.code === language) || LANGUAGE_OPTIONS[0];

  // Speech Recognition setup
  const toggleSpeechRecognition = () => {
    if (isListening) {
      if (recognitionRef.current) recognitionRef.current.stop();
      setIsListening(false);
      return;
    }

    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      alert('Speech Recognition is not supported by your browser. Please type your message.');
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.lang = activeLangConfig.speechCode;
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;

    recognition.onstart = () => setIsListening(true);
    recognition.onend = () => setIsListening(false);
    recognition.onerror = (e: any) => {
      console.warn('Speech error:', e.error);
      setIsListening(false);
    };
    recognition.onresult = (e: any) => {
      const transcript = e.results[0][0].transcript;
      setInput((prev) => (prev ? `${prev} ${transcript}` : transcript));
    };

    recognitionRef.current = recognition;
    recognition.start();
  };

  // Text-to-speech
  const speakMessage = (id: string, text: string) => {
    if (!('speechSynthesis' in window)) return;

    if (speakingMsgId === id) {
      window.speechSynthesis.cancel();
      setSpeakingMsgId(null);
      return;
    }

    window.speechSynthesis.cancel();
    const cleanText = text.replace(/[*#_`]/g, '');
    const utterance = new SpeechSynthesisUtterance(cleanText);
    utterance.lang = activeLangConfig.speechCode;
    utterance.onend = () => setSpeakingMsgId(null);
    utterance.onerror = () => setSpeakingMsgId(null);

    setSpeakingMsgId(id);
    window.speechSynthesis.speak(utterance);
  };

  const copyMessage = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleSend = async (textToSend?: string) => {
    const text = (textToSend || input).trim();
    if (!text || loading) return;

    const userMsg: Message = {
      id: `usr_${Date.now()}`,
      role: 'user',
      content: text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInput('');
    setLoading(true);

    try {
      const response = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: text,
          conversationHistory: messages.slice(-6).map((m) => ({
            role: m.role,
            content: m.content,
          })),
          expertType: 'general',
          language,
          beginnerMode,
        }),
      });

      if (!response.ok) throw new Error('Network error');

      const data = await response.json();
      const assistantMsg: Message = {
        id: `ai_${Date.now()}`,
        role: 'assistant',
        content: data.reply,
        isEmergency: data.isEmergency,
        detectedLang: data.language,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages((prev) => [...prev, assistantMsg]);
    } catch (err) {
      console.error('Chat error:', err);
      const fallbackMsg: Message = {
        id: `ai_${Date.now()}`,
        role: 'assistant',
        content:
          language === 'Telugu'
            ? 'క్షమించండి, సర్వర్ కనెక్షన్ లో సమస్య ఏర్పడింది. అత్యవసర పరిస్థితుల్లో వెంటనే 108 లేదా స్థానిక వైద్యుడిని సంప్రదించండి.'
            : language === 'Hindi'
            ? 'क्षमा करें, सर्वर से जुड़ने में समस्या हुई। किसी भी आपातकालीन स्थिति में 108 या डॉक्टर से संपर्क करें।'
            : 'I apologize, but I am currently having difficulty connecting to the medical AI engine. For urgent health concerns, please consult a healthcare professional immediately.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, fallbackMsg]);
    } finally {
      setLoading(false);
    }
  };

  const activeQuestions =
    LOCALIZED_QUESTIONS[language] || LOCALIZED_QUESTIONS.English;

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-6 animate-fade-in flex flex-col h-[calc(100vh-140px)] min-h-[640px]">
      {/* 1. Header with Language Selector & Beginner Toggle */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-200 dark:border-slate-800">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-teal-600 text-white flex items-center justify-center shadow-md">
            <Bot className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg font-bold text-slate-900 dark:text-white">
                DRUGAI Multilingual Health Assistant
              </h1>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-teal-100 dark:bg-teal-950 text-teal-700 dark:text-teal-300 border border-teal-200 dark:border-teal-800">
                Native Script AI
              </span>
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400">
              Auto-detects language • Answers in native script (తెలుగు, हिन्दी, தமிழ், etc.)
            </p>
          </div>
        </div>

        {/* Controls: Language Selector + Beginner Mode */}
        <div className="flex flex-wrap items-center gap-3">
          {/* Language Selector Dropdown */}
          <div className="flex items-center gap-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 px-3 py-1.5 rounded-xl shadow-sm">
            <Globe className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400 shrink-0" />
            <select
              value={language}
              onChange={(e) => setLanguage(e.target.value as SupportedLanguage)}
              className="bg-transparent text-xs font-bold text-slate-800 dark:text-slate-200 focus:outline-none cursor-pointer pr-1"
            >
              {LANGUAGE_OPTIONS.map((opt) => (
                <option key={opt.code} value={opt.code} className="dark:bg-slate-800">
                  {opt.nativeName} ({opt.label})
                </option>
              ))}
            </select>
          </div>

          {/* Beginner Mode Toggle */}
          <label className="flex items-center gap-2 text-xs font-semibold text-slate-700 dark:text-slate-300 cursor-pointer bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 px-3 py-1.5 rounded-xl shadow-sm">
            <input
              type="checkbox"
              checked={beginnerMode}
              onChange={(e) => setBeginnerMode(e.target.checked)}
              className="rounded text-teal-600 focus:ring-teal-500 h-3.5 w-3.5 cursor-pointer"
            />
            <span className="text-[11px]">Beginner Mode</span>
          </label>
        </div>
      </div>

      {/* Safety Guardrails Banner */}
      <div className="my-2.5 p-3 rounded-2xl bg-teal-50/70 dark:bg-teal-950/30 border border-teal-200/80 dark:border-teal-800/80 text-teal-950 dark:text-teal-200 text-xs flex items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-teal-600 dark:text-teal-400 shrink-0" />
          <span>
            <strong>Clinical Safety Protocol:</strong> Evidence-based healthcare education only. The AI never prescribes drugs or replaces a physician.
          </span>
        </div>
        <button
          onClick={onOpenEmergency}
          className="text-[11px] font-bold text-red-600 dark:text-red-400 hover:underline shrink-0 flex items-center gap-1"
        >
          Emergency Hotlines &rarr;
        </button>
      </div>

      {/* Messages Feed */}
      <div className="flex-1 overflow-y-auto space-y-4 py-3 pr-1">
        {messages.map((m) => (
          <div
            key={m.id}
            className={`flex gap-3 ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            {m.role === 'assistant' && (
              <div className="w-8 h-8 rounded-xl bg-teal-600 text-white flex items-center justify-center shrink-0 mt-1 shadow-sm">
                <Bot className="w-4 h-4" />
              </div>
            )}

            <div
              className={`max-w-[88%] sm:max-w-[80%] rounded-2xl p-4 text-xs sm:text-sm leading-relaxed ${
                m.role === 'user'
                  ? 'bg-teal-600 text-white rounded-br-none shadow-sm'
                  : m.isEmergency
                  ? 'bg-red-50 dark:bg-red-950/50 border-2 border-red-500 text-slate-900 dark:text-white rounded-bl-none shadow-md'
                  : 'bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-100 rounded-bl-none shadow-sm'
              }`}
            >
              {m.isEmergency && (
                <div className="mb-3 p-3 rounded-xl bg-red-100 dark:bg-red-900/40 border border-red-300 dark:border-red-700 text-red-900 dark:text-red-200 text-xs flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <ShieldAlert className="w-5 h-5 text-red-600 animate-pulse shrink-0" />
                    <span className="font-bold">MEDICAL EMERGENCY ALERT</span>
                  </div>
                  <button
                    onClick={onOpenEmergency}
                    className="px-2.5 py-1 rounded-lg bg-red-600 hover:bg-red-700 text-white font-bold text-[10px] whitespace-nowrap transition-colors"
                  >
                    Call 911 / 112 / 108 &rarr;
                  </button>
                </div>
              )}

              <div className="whitespace-pre-wrap space-y-2 font-normal font-sans">
                {m.content}
              </div>

              {/* Message Footer Actions */}
              <div className="flex items-center justify-between mt-2 pt-2 border-t border-slate-100 dark:border-slate-800/80 text-[11px] opacity-70">
                <span className="text-[10px]">{m.timestamp}</span>

                {m.role === 'assistant' && (
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => speakMessage(m.id, m.content)}
                      className="hover:text-teal-600 flex items-center gap-1 cursor-pointer"
                      title="Listen aloud"
                    >
                      <Volume2 className={`w-3.5 h-3.5 ${speakingMsgId === m.id ? 'text-teal-600 animate-pulse' : ''}`} />
                      <span>{speakingMsgId === m.id ? 'Stop' : 'Listen'}</span>
                    </button>
                    <button
                      onClick={() => copyMessage(m.id, m.content)}
                      className="hover:text-teal-600 flex items-center gap-1 cursor-pointer"
                      title="Copy text"
                    >
                      {copiedId === m.id ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                )}
              </div>
            </div>

            {m.role === 'user' && (
              <div className="w-8 h-8 rounded-xl bg-slate-700 text-white flex items-center justify-center shrink-0 mt-1 shadow-sm">
                <User className="w-4 h-4" />
              </div>
            )}
          </div>
        ))}

        {loading && (
          <div className="flex gap-3 items-center text-xs text-slate-400">
            <div className="w-8 h-8 rounded-xl bg-teal-600/60 text-white flex items-center justify-center animate-pulse">
              <Bot className="w-4 h-4" />
            </div>
            <span className="flex items-center gap-1.5">
              <RefreshCw className="w-3.5 h-3.5 animate-spin text-teal-500" />
              DRUGAI is reviewing medical guidelines and drafting in {activeLangConfig.nativeName}...
            </span>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Suggested Quick Questions in Selected Native Language */}
      <div className="py-2 border-t border-slate-200/80 dark:border-slate-800/80">
        <p className="text-[11px] font-semibold text-slate-400 mb-1.5 flex items-center gap-1">
          <Sparkles className="w-3 h-3 text-teal-500" /> Suggested in {activeLangConfig.nativeName} ({activeLangConfig.label}):
        </p>
        <div className="flex flex-wrap gap-1.5">
          {activeQuestions.map((q, idx) => (
            <button
              key={idx}
              onClick={() => handleSend(q)}
              className="text-[11px] px-3 py-1.5 rounded-xl bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-teal-50 dark:hover:bg-teal-950/60 hover:text-teal-600 transition-colors border border-slate-200 dark:border-slate-700 cursor-pointer shadow-sm text-left"
            >
              {q}
            </button>
          ))}
        </div>
      </div>

      {/* Input Form with Voice Button */}
      <div className="pt-2">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSend();
          }}
          className="flex items-center gap-2"
        >
          <div className="relative flex-1">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder={`Ask in ${activeLangConfig.nativeName} or English (e.g. "జ్వరం ఎందుకు వస్తుంది?", "Fever causes")...`}
              className="w-full pl-4 pr-12 py-3 rounded-2xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white placeholder-slate-400 text-sm focus:outline-none focus:ring-2 focus:ring-teal-500 shadow-sm"
            />
            {/* Voice Input Button inside search bar */}
            <button
              type="button"
              onClick={toggleSpeechRecognition}
              className={`absolute right-3 top-1/2 -translate-y-1/2 p-1.5 rounded-xl transition-all cursor-pointer ${
                isListening
                  ? 'bg-red-500 text-white animate-pulse'
                  : 'text-slate-400 hover:text-teal-600 dark:hover:text-teal-400'
              }`}
              title={`Voice input (${activeLangConfig.nativeName})`}
            >
              {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
            </button>
          </div>

          <button
            type="submit"
            disabled={!input.trim() || loading}
            className="px-5 py-3 rounded-2xl bg-teal-600 hover:bg-teal-700 disabled:opacity-50 text-white font-bold text-sm flex items-center gap-2 transition-all shadow-md cursor-pointer shrink-0"
          >
            <Send className="w-4 h-4" />
            <span className="hidden sm:inline">Send</span>
          </button>
        </form>
      </div>
    </div>
  );
};
