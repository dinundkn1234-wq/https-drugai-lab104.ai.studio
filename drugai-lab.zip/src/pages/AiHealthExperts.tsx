import React, { useState } from 'react';
import {
  Sparkles,
  Bot,
  Pill,
  BookOpen,
  Apple,
  Brain,
  HeartPulse,
  GraduationCap,
  Microscope,
  Send,
  ShieldCheck,
  ArrowLeft,
} from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

interface ExpertDef {
  id: string;
  name: string;
  roleTitle: string;
  icon: any;
  color: string;
  description: string;
  sampleQuestion: string;
}

const EXPERTS: ExpertDef[] = [
  {
    id: 'general',
    name: 'AI General Health Assistant',
    roleTitle: 'General Wellness & Pathology Education',
    icon: HeartPulse,
    color: 'teal',
    description: 'Evidence-based guidance on common conditions, health literacy, and preventive habits.',
    sampleQuestion: 'What are the main risk factors for developing hypertension?',
  },
  {
    id: 'medicine',
    name: 'AI Medicine Information Assistant',
    roleTitle: 'Drug Profiles & Label Awareness',
    icon: Pill,
    color: 'cyan',
    description: 'Explaining active ingredients, drug classes, precautions, and safe administration.',
    sampleQuestion: 'What is the difference between Ibuprofen and Paracetamol?',
  },
  {
    id: 'pharmacology',
    name: 'AI Pharmacology Learning Assistant',
    roleTitle: 'ADME & Receptor Dynamics',
    icon: Sparkles,
    color: 'indigo',
    description: 'Detailed pharmacokinetics, cytochrome P450 pathways, and biochemical mechanisms.',
    sampleQuestion: 'How does the hepatic first-pass effect impact oral bioavailability?',
  },
  {
    id: 'nutrition',
    name: 'AI Nutrition Education Assistant',
    roleTitle: 'Dietary Science & Drug-Food Interactions',
    icon: Apple,
    color: 'emerald',
    description: 'Micronutrient balances, vitamin requirements, and foods that interact with therapies.',
    sampleQuestion: 'Why does grapefruit juice interfere with statin cholesterol drugs?',
  },
  {
    id: 'mental',
    name: 'AI Mental Wellness Information Assistant',
    roleTitle: 'Psychoeducation & Coping Strategies',
    icon: Brain,
    color: 'purple',
    description: 'Evidence-based education on stress, sleep hygiene, and mental wellbeing resources.',
    sampleQuestion: 'What evidence-based lifestyle changes help alleviate chronic daily stress?',
  },
  {
    id: 'firstaid',
    name: 'AI First-Aid Education Assistant',
    roleTitle: 'First Response & Triage Protocols',
    icon: ShieldCheck,
    color: 'red',
    description: 'Step-by-step guidance on basic wound dressing, burn management, and emergency recognition.',
    sampleQuestion: 'What are the correct first-aid steps for a minor second-degree kitchen burn?',
  },
  {
    id: 'tutor',
    name: 'AI Student Medical Tutor',
    roleTitle: 'Academic Companion & Case Scenarios',
    icon: GraduationCap,
    color: 'blue',
    description: 'Helps medical and pharmacy students master high-yield concepts and clinical cases.',
    sampleQuestion: 'Can you give me a case scenario on diagnosing early Type 2 Diabetes?',
  },
  {
    id: 'research',
    name: 'AI Medical Research Assistant',
    roleTitle: 'Clinical Trials & Peer-Reviewed Literature',
    icon: Microscope,
    color: 'slate',
    description: 'Explains statistical trial endpoints, meta-analyses, and literature search methodology.',
    sampleQuestion: 'How do double-blind randomized controlled trials minimize confounding bias?',
  },
];

export const AiHealthExperts: React.FC = () => {
  const { language } = useLanguage();
  const [activeExpert, setActiveExpert] = useState<ExpertDef | null>(null);
  const [messages, setMessages] = useState<Array<{ role: 'user' | 'assistant'; text: string }>>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);

  const startExpertChat = (expert: ExpertDef) => {
    setActiveExpert(expert);
    setMessages([
      {
        role: 'assistant',
        text: `Welcome! I am the **${expert.name}**.\n\n*Educational Scope:* I provide evidence-based educational insights in ${expert.roleTitle}. I do not provide medical diagnosis or personalized treatment. Ask me anything within my specialty!`,
      },
    ]);
  };

  const handleSend = async (customText?: string) => {
    const text = (customText || input).trim();
    if (!text || loading || !activeExpert) return;

    setMessages((prev) => [...prev, { role: 'user', text }]);
    setInput('');
    setLoading(true);

    try {
      const response = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: text,
          expertType: activeExpert.id,
          language,
        }),
      });

      const data = await response.json();
      setMessages((prev) => [...prev, { role: 'assistant', text: data.reply }]);
    } catch {
      setMessages((prev) => [
        ...prev,
        { role: 'assistant', text: 'Error connecting to expert AI. Please retry.' },
      ]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 animate-fade-in pb-16">
      {!activeExpert ? (
        <div className="space-y-8">
          {/* Header */}
          <div className="text-center max-w-3xl mx-auto">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-teal-50 dark:bg-teal-950 text-teal-700 dark:text-teal-300 text-xs font-bold mb-3">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Specialized AI Educational Personas</span>
            </div>
            <h1 className="text-3xl sm:text-4xl font-black text-slate-900 dark:text-white tracking-tight">
              AI Health & Clinical Experts
            </h1>
            <p className="text-sm text-slate-500 mt-2">
              Select an educational AI assistant specialized in pharmacology, medical tutoring, nutrition, or research methodology.
            </p>
          </div>

          {/* Grid of 8 Experts */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {EXPERTS.map((exp) => {
              const Icon = exp.icon;
              return (
                <div
                  key={exp.id}
                  onClick={() => startExpertChat(exp)}
                  className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm hover:shadow-xl hover:border-teal-500 transition-all cursor-pointer flex flex-col justify-between group"
                >
                  <div>
                    <div className="w-12 h-12 rounded-2xl bg-teal-50 dark:bg-teal-950/60 text-teal-600 flex items-center justify-center mb-4 group-hover:scale-105 transition-transform">
                      <Icon className="w-6 h-6" />
                    </div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                      {exp.roleTitle}
                    </span>
                    <h3 className="text-base font-bold text-slate-900 dark:text-white mt-1">
                      {exp.name}
                    </h3>
                    <p className="text-xs text-slate-500 mt-2 leading-relaxed">
                      {exp.description}
                    </p>
                  </div>
                  <div className="mt-6 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs font-bold text-teal-600">
                    <span>Consult Persona</span>
                    <span>&rarr;</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      ) : (
        /* Chat view with selected expert */
        <div className="max-w-4xl mx-auto space-y-4">
          <button
            onClick={() => setActiveExpert(null)}
            className="flex items-center gap-2 text-xs font-semibold text-slate-500 hover:text-teal-600"
          >
            <ArrowLeft className="w-4 h-4" /> Back to All AI Experts
          </button>

          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-xl flex flex-col h-[650px]">
            {/* Header */}
            <div className="flex items-center gap-3 pb-4 border-b border-slate-100 dark:border-slate-800">
              <div className="w-10 h-10 rounded-2xl bg-teal-600 text-white flex items-center justify-center font-bold">
                <activeExpert.icon className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-base font-bold text-slate-900 dark:text-white">
                  {activeExpert.name}
                </h2>
                <p className="text-xs text-slate-500">{activeExpert.roleTitle}</p>
              </div>
            </div>

            {/* Messages feed */}
            <div className="flex-1 overflow-y-auto space-y-4 py-4 pr-1">
              {messages.map((m, idx) => (
                <div
                  key={idx}
                  className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div
                    className={`max-w-[80%] rounded-2xl p-4 text-xs sm:text-sm leading-relaxed whitespace-pre-wrap ${
                      m.role === 'user'
                        ? 'bg-teal-600 text-white rounded-br-none'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-white rounded-bl-none'
                    }`}
                  >
                    {m.text}
                  </div>
                </div>
              ))}
              {loading && (
                <div className="text-xs text-slate-400 flex items-center gap-2">
                  <Bot className="w-4 h-4 animate-spin text-teal-600" />
                  <span>{activeExpert.name} is compiling clinical reference...</span>
                </div>
              )}
            </div>

            {/* Sample Question pill */}
            {messages.length === 1 && (
              <div className="py-2">
                <button
                  onClick={() => handleSend(activeExpert.sampleQuestion)}
                  className="text-xs text-teal-600 dark:text-teal-400 bg-teal-50 dark:bg-teal-950 px-3 py-1.5 rounded-lg border border-teal-200 dark:border-teal-800 text-left hover:bg-teal-100 transition-colors"
                >
                  Example prompt: “{activeExpert.sampleQuestion}” &rarr;
                </button>
              </div>
            )}

            {/* Input bar */}
            <div className="pt-2">
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  handleSend();
                }}
                className="flex gap-2"
              >
                <input
                  type="text"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder={`Ask ${activeExpert.name}...`}
                  className="flex-1 px-4 py-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-sm focus:outline-none focus:ring-2 focus:ring-teal-500"
                />
                <button
                  type="submit"
                  disabled={!input.trim() || loading}
                  className="px-5 py-3 rounded-xl bg-teal-600 hover:bg-teal-700 disabled:opacity-50 text-white font-bold text-sm"
                >
                  <Send className="w-4 h-4" />
                </button>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
