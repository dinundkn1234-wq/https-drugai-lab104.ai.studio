import React, { useState, useEffect, useRef } from 'react';
import {
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  Sparkles,
  Bot,
  AlertTriangle,
  ShieldCheck,
  RefreshCw,
  Globe,
} from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import { SupportedLanguage } from '../types';

const LANGUAGE_SPEECH_MAP: Record<
  SupportedLanguage,
  { label: string; nativeName: string; code: string; sample: string }
> = {
  'Auto-Detect': {
    label: 'Auto-Detect',
    nativeName: 'Auto (ఆటో / ऑटो)',
    code: 'en-US',
    sample: 'What are the early warning signs of diabetes?',
  },
  English: {
    label: 'English',
    nativeName: 'English',
    code: 'en-US',
    sample: 'What are the early warning signs of diabetes?',
  },
  Telugu: {
    label: 'Telugu',
    nativeName: 'తెలుగు',
    code: 'te-IN',
    sample: 'జ్వరం ఎందుకు వస్తుంది?',
  },
  Hindi: {
    label: 'Hindi',
    nativeName: 'हिन्दी',
    code: 'hi-IN',
    sample: 'बुखार के सामान्य कारण क्या हैं?',
  },
  Tamil: {
    label: 'Tamil',
    nativeName: 'தமிழ்',
    code: 'ta-IN',
    sample: 'காய்ச்சல் அறிகுறிகள் என்ன?',
  },
  Kannada: {
    label: 'Kannada',
    nativeName: 'ಕನ್ನಡ',
    code: 'kn-IN',
    sample: 'ಜ್ವರದ ಸಾಮಾನ್ಯ ಲಕ್ಷಣಗಳೇನು?',
  },
  Malayalam: {
    label: 'Malayalam',
    nativeName: 'മലയാളം',
    code: 'ml-IN',
    sample: 'പനിയുടെ ലക്ഷണങ്ങൾ എന്തൊക്കെയാണ്?',
  },
  Marathi: {
    label: 'Marathi',
    nativeName: 'मराठी',
    code: 'mr-IN',
    sample: 'तापाची लक्षणे कोणती आहेत?',
  },
  Bengali: {
    label: 'Bengali',
    nativeName: 'বাংলা',
    code: 'bn-IN',
    sample: 'জ্বরের কারণ কী?',
  },
  Gujarati: {
    label: 'Gujarati',
    nativeName: 'ગુજરાતી',
    code: 'gu-IN',
    sample: 'તાવના લક્ષણો શું છે?',
  },
  Punjabi: {
    label: 'Punjabi',
    nativeName: 'ਪੰਜਾਬੀ',
    code: 'pa-IN',
    sample: 'ਬੁਖਾਰ ਦੇ ਲੱਛਣ ਕੀ ਹਨ?',
  },
  Urdu: {
    label: 'Urdu',
    nativeName: 'اردو',
    code: 'ur-PK',
    sample: 'بخار کی علامات کیا ہیں؟',
  },
  Spanish: {
    label: 'Spanish',
    nativeName: 'Español',
    code: 'es-ES',
    sample: '¿Cuáles son las causas de la fiebre?',
  },
};

export const AiVoiceAssistant: React.FC<{ onOpenEmergency: () => void }> = ({
  onOpenEmergency,
}) => {
  const { language, setLanguage } = useLanguage();
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [aiResponse, setAiResponse] = useState('');
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const recognitionRef = useRef<any>(null);
  const activeLangConfig = LANGUAGE_SPEECH_MAP[language] || LANGUAGE_SPEECH_MAP.English;

  useEffect(() => {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (SpeechRecognition) {
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.lang = activeLangConfig.code;

      recognition.onresult = (event: any) => {
        const text = event.results[0][0].transcript;
        setTranscript(text);
        setIsListening(false);
        processVoiceQuery(text);
      };

      recognition.onerror = (event: any) => {
        console.warn('Speech recognition error:', event.error);
        setIsListening(false);
        setErrorMsg('Microphone input ended or was not captured. Please try again.');
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognitionRef.current = recognition;
    }
  }, [language, activeLangConfig]);

  const toggleListening = () => {
    setErrorMsg('');
    if (isListening) {
      recognitionRef.current?.stop();
      setIsListening(false);
    } else {
      setTranscript('');
      setAiResponse('');
      stopSpeaking();

      if (recognitionRef.current) {
        try {
          recognitionRef.current.lang = activeLangConfig.code;
          recognitionRef.current.start();
          setIsListening(true);
        } catch (e) {
          console.error(e);
          simulateSpeechQuery();
        }
      } else {
        simulateSpeechQuery();
      }
    }
  };

  const simulateSpeechQuery = () => {
    setIsListening(true);
    setTimeout(() => {
      const sample = activeLangConfig.sample;
      setTranscript(sample);
      setIsListening(false);
      processVoiceQuery(sample);
    }, 1500);
  };

  const processVoiceQuery = async (query: string) => {
    if (!query) return;
    setLoading(true);
    setErrorMsg('');

    try {
      const response = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: query,
          expertType: 'general',
          language,
          beginnerMode: true,
        }),
      });

      const data = await response.json();
      setAiResponse(data.reply);
      speakText(data.reply);
    } catch (e) {
      console.error(e);
      setErrorMsg('Failed to fetch voice response from DRUGAI server.');
    } finally {
      setLoading(false);
    }
  };

  const speakText = (text: string) => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const clean = text.replace(/[*#_`]/g, '');
      const utterance = new SpeechSynthesisUtterance(clean);
      utterance.lang = activeLangConfig.code;
      utterance.rate = 1.0;
      utterance.pitch = 1.0;
      utterance.onstart = () => setIsSpeaking(true);
      utterance.onend = () => setIsSpeaking(false);
      utterance.onerror = () => setIsSpeaking(false);
      window.speechSynthesis.speak(utterance);
    }
  };

  const stopSpeaking = () => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10 animate-fade-in text-center space-y-8">
      {/* Top Banner */}
      <div>
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-teal-50 dark:bg-teal-950 text-teal-700 dark:text-teal-300 text-xs font-bold mb-3 border border-teal-200 dark:border-teal-800">
          <Mic className="w-3.5 h-3.5" />
          <span>Multilingual Speech Interface ({activeLangConfig.nativeName})</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-black text-slate-900 dark:text-white tracking-tight">
          AI Voice Health Assistant
        </h1>
        <p className="text-sm text-slate-500 max-w-xl mx-auto mt-2">
          Speak in your native language ({activeLangConfig.nativeName}). DRUGAI will understand your voice query, process evidence-based medical knowledge, and speak the reply in your language.
        </p>
      </div>

      {/* Language Selector Bar */}
      <div className="flex items-center justify-center gap-2">
        <div className="inline-flex items-center gap-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 px-4 py-2 rounded-2xl shadow-sm">
          <Globe className="w-4 h-4 text-teal-600 dark:text-teal-400" />
          <span className="text-xs font-semibold text-slate-500">Language:</span>
          <select
            value={language}
            onChange={(e) => setLanguage(e.target.value as SupportedLanguage)}
            className="bg-transparent text-xs font-bold text-slate-900 dark:text-white focus:outline-none cursor-pointer"
          >
            {Object.entries(LANGUAGE_SPEECH_MAP).map(([code, meta]) => (
              <option key={code} value={code} className="dark:bg-slate-800">
                {meta.nativeName} ({meta.label})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Safety Disclaimer */}
      <div className="max-w-xl mx-auto p-3.5 rounded-2xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800 text-amber-900 dark:text-amber-200 text-xs flex items-center justify-between gap-2 text-left">
        <div className="flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-amber-600 shrink-0" />
          <span>
            <strong>Voice Safety Notice:</strong> The voice assistant provides general health education only. In emergencies, immediately call <strong>108 / 112 / 911</strong>.
          </span>
        </div>
        <button
          onClick={onOpenEmergency}
          className="text-[11px] font-bold text-red-600 dark:text-red-400 hover:underline shrink-0"
        >
          SOS &rarr;
        </button>
      </div>

      {/* Central Animated Mic Orb */}
      <div className="py-6 flex flex-col items-center justify-center">
        <div className="relative">
          {isListening && (
            <div className="absolute inset-0 rounded-full bg-teal-500/20 animate-ping"></div>
          )}
          <button
            onClick={toggleListening}
            className={`relative w-28 h-28 sm:w-36 sm:h-36 rounded-full flex items-center justify-center transition-all shadow-2xl cursor-pointer ${
              isListening
                ? 'bg-red-500 text-white scale-105 shadow-red-500/50'
                : 'bg-gradient-to-tr from-teal-600 to-cyan-500 text-white hover:scale-105 shadow-teal-500/30'
            }`}
          >
            {isListening ? (
              <MicOff className="w-12 h-12 animate-pulse" />
            ) : (
              <Mic className="w-12 h-12" />
            )}
          </button>
        </div>

        <p className="text-xs sm:text-sm font-bold mt-6 text-slate-700 dark:text-slate-300">
          {isListening ? (
            <span className="text-red-500 animate-pulse">Listening in {activeLangConfig.nativeName}... Speak now</span>
          ) : loading ? (
            <span className="text-teal-600 flex items-center gap-1.5">
              <RefreshCw className="w-3.5 h-3.5 animate-spin" /> Processing medical response in {activeLangConfig.nativeName}...
            </span>
          ) : (
            `Tap Microphone to Ask in ${activeLangConfig.nativeName} (e.g. "${activeLangConfig.sample}")`
          )}
        </p>

        {errorMsg && (
          <p className="text-xs text-amber-600 dark:text-amber-400 mt-2">{errorMsg}</p>
        )}
      </div>

      {/* Speech Audio Controls */}
      {isSpeaking && (
        <div className="flex items-center justify-center gap-3 animate-fade-in">
          <button
            onClick={stopSpeaking}
            className="px-4 py-2 rounded-xl bg-red-100 dark:bg-red-950 text-red-700 dark:text-red-300 text-xs font-bold flex items-center gap-2 cursor-pointer shadow-sm hover:bg-red-200 transition-colors"
          >
            <VolumeX className="w-4 h-4" /> Stop Voice Playback
          </button>
        </div>
      )}

      {/* User Transcript */}
      {transcript && (
        <div className="max-w-2xl mx-auto p-4 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-left shadow-sm">
          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">
            You Spoke ({activeLangConfig.nativeName}):
          </p>
          <p className="text-sm font-semibold text-slate-900 dark:text-white leading-relaxed">“{transcript}”</p>
        </div>
      )}

      {/* AI Voice Output Display */}
      {aiResponse && (
        <div className="max-w-2xl mx-auto p-6 rounded-3xl bg-teal-50/60 dark:bg-slate-900 border border-teal-200 dark:border-teal-900 text-left shadow-md space-y-3 animate-fade-in">
          <div className="flex items-center justify-between border-b border-teal-100 dark:border-slate-800 pb-2">
            <span className="text-xs font-bold text-teal-700 dark:text-teal-300 flex items-center gap-1.5">
              <Bot className="w-4 h-4" /> DRUGAI Spoken Response ({activeLangConfig.nativeName})
            </span>
            <button
              onClick={() => speakText(aiResponse)}
              className="p-1 text-slate-400 hover:text-teal-600 cursor-pointer"
              title="Replay Voice"
            >
              <Volume2 className="w-4 h-4" />
            </button>
          </div>
          <div className="text-xs sm:text-sm text-slate-800 dark:text-slate-200 whitespace-pre-wrap leading-relaxed font-sans">
            {aiResponse}
          </div>
        </div>
      )}
    </div>
  );
};
