import React from 'react';
import { ArrowLeft, Clock, Bookmark, Share2, ShieldCheck, ExternalLink } from 'lucide-react';
import { HEALTH_ARTICLES } from '../data/mockData';
import { useAuth } from '../context/AuthContext';

export const ArticleDetail: React.FC<{
  articleId: string;
  onBack: () => void;
}> = ({ articleId, onBack }) => {
  const { toggleBookmark, isBookmarked } = useAuth();
  const article = HEALTH_ARTICLES.find((a) => a.id === articleId) || HEALTH_ARTICLES[0];

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10 animate-fade-in pb-16 space-y-8">
      {/* Back & Actions */}
      <div className="flex items-center justify-between">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-xs font-semibold text-slate-500 hover:text-teal-600"
        >
          <ArrowLeft className="w-4 h-4" /> Back to Articles
        </button>
        <button
          onClick={() => toggleBookmark(article.id, 'article', article.title)}
          className={`px-3 py-1.5 rounded-lg border text-xs font-semibold flex items-center gap-1.5 ${
            isBookmarked(article.id)
              ? 'bg-teal-50 border-teal-300 text-teal-600'
              : 'border-slate-200 text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Bookmark className="w-3.5 h-3.5" />
          {isBookmarked(article.id) ? 'Saved' : 'Bookmark'}
        </button>
      </div>

      {/* Header */}
      <div className="space-y-4">
        <div className="flex items-center gap-2 text-xs text-slate-400">
          <span className="text-teal-600 font-bold uppercase tracking-wider">{article.category}</span>
          <span>•</span>
          <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> {article.readTime}</span>
          <span>•</span>
          <span>Published {article.publishedDate}</span>
        </div>

        <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 dark:text-white leading-tight">
          {article.title}
        </h1>

        <p className="text-sm text-slate-500 italic">
          Author: {article.author} ({article.organization})
        </p>
      </div>

      {/* Key Takeaways Box */}
      <div className="p-6 rounded-2xl bg-teal-50/70 dark:bg-teal-950/40 border border-teal-200 dark:border-teal-800 space-y-2">
        <h3 className="text-xs font-bold uppercase tracking-wider text-teal-900 dark:text-teal-200">
          Key Educational Takeaways:
        </h3>
        <ul className="space-y-1.5 text-xs text-teal-950 dark:text-teal-200">
          {article.keyTakeaways.map((take, idx) => (
            <li key={idx} className="flex items-start gap-2">
              <span className="text-teal-600 font-bold">•</span>
              <span>{take}</span>
            </li>
          ))}
        </ul>
      </div>

      {/* Article Body */}
      <div className="space-y-4 text-sm sm:text-base text-slate-700 dark:text-slate-300 leading-relaxed font-normal">
        {article.content.map((p, idx) => (
          <p key={idx}>{p}</p>
        ))}
      </div>

      {/* References & Citations */}
      <div className="mt-8 p-6 rounded-2xl bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-2">
        <h4 className="text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-300">
          Verified References & Guidelines:
        </h4>
        <ul className="space-y-1 text-xs text-slate-500">
          {article.references.map((ref, idx) => (
            <li key={idx} className="flex items-center gap-2">
              <span>• {ref}</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};
