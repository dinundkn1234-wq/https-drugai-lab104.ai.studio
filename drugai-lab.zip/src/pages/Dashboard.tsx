import React from 'react';
import {
  User,
  Bookmark,
  Pill,
  Activity,
  FileText,
  Clock,
  ShieldCheck,
  CheckCircle2,
  Trash2,
  ArrowRight,
  Globe,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';
import { UserRole, SupportedLanguage } from '../types';

interface DashboardProps {
  onNavigate: (tab: string, param?: string) => void;
}

export const Dashboard: React.FC<DashboardProps> = ({ onNavigate }) => {
  const { user, updateUserRole, updateLanguagePreference, toggleBookmark } = useAuth();
  const { language, setLanguage } = useLanguage();

  if (!user) {
    return (
      <div className="max-w-md mx-auto py-20 text-center animate-fade-in">
        <h2 className="text-xl font-bold mb-2">Sign in to view your dashboard</h2>
        <button
          onClick={() => onNavigate('login')}
          className="px-6 py-2.5 rounded-xl bg-teal-600 text-white font-bold text-xs"
        >
          Go to Sign In
        </button>
      </div>
    );
  }

  const handleRoleChange = (newRole: UserRole) => {
    updateUserRole(newRole);
  };

  const handleLangChange = (lang: SupportedLanguage) => {
    setLanguage(lang);
    updateLanguagePreference(lang);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 animate-fade-in pb-16 space-y-8">
      {/* Welcome Banner */}
      <div className="p-6 sm:p-8 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-teal-600 text-white font-black text-2xl flex items-center justify-center uppercase">
            {user.name.charAt(0)}
          </div>
          <div>
            <h1 className="text-2xl font-black text-slate-900 dark:text-white">
              Welcome back, {user.name}
            </h1>
            <p className="text-xs text-slate-500 mt-0.5">
              Account: {user.email} • Role:{' '}
              <span className="font-bold uppercase text-teal-600">{user.role}</span>
            </p>
          </div>
        </div>

        {/* Role Selector */}
        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-400 font-semibold">Switch Role:</span>
          {(['patient', 'student', 'doctor', 'researcher'] as UserRole[]).map((r) => (
            <button
              key={r}
              onClick={() => handleRoleChange(r)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold capitalize transition-colors ${
                user.role === r
                  ? 'bg-teal-600 text-white shadow-sm'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
              }`}
            >
              {r}
            </button>
          ))}
        </div>
      </div>

      {/* Safety Notice */}
      <div className="p-3.5 rounded-2xl bg-slate-100 dark:bg-slate-800/60 text-slate-500 dark:text-slate-400 text-xs flex items-center gap-2 border border-slate-200 dark:border-slate-700">
        <ShieldCheck className="w-4 h-4 text-teal-600 shrink-0" />
        <span>
          <strong>Privacy Safeguard:</strong> DRUGAI-LAB never generates clinical diagnoses, predictions, or automated prescriptions from your account activity or bookmarks.
        </span>
      </div>

      {/* Grid of Saved Collections */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Bookmarked Topics */}
        <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold uppercase tracking-wider text-slate-900 dark:text-white flex items-center gap-2">
              <Bookmark className="w-4 h-4 text-teal-600" /> Bookmarked Items ({user.bookmarks.length})
            </h3>
          </div>

          <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
            {user.bookmarks.length === 0 ? (
              <p className="text-xs text-slate-400 italic">No bookmarks saved yet.</p>
            ) : (
              user.bookmarks.map((b) => (
                <div
                  key={b.id}
                  className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs group"
                >
                  <button
                    onClick={() => {
                      if (b.type === 'disease') onNavigate('disease-detail', b.id);
                      else if (b.type === 'medicine') onNavigate('medicine-detail', b.id);
                      else onNavigate('article-detail', b.id);
                    }}
                    className="text-left font-semibold text-slate-800 dark:text-slate-200 hover:text-teal-600 truncate flex-1"
                  >
                    {b.title}
                  </button>
                  <button
                    onClick={() => toggleBookmark(b.id, b.type, b.title)}
                    className="p-1 text-slate-400 hover:text-red-500 ml-2"
                    title="Remove"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Recent Searches */}
        <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
          <h3 className="text-sm font-bold uppercase tracking-wider text-slate-900 dark:text-white flex items-center gap-2">
            <Clock className="w-4 h-4 text-teal-600" /> Recent Search History
          </h3>

          <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
            {user.recentSearches.length === 0 ? (
              <p className="text-xs text-slate-400 italic">No search history recorded.</p>
            ) : (
              user.recentSearches.map((s, idx) => (
                <div
                  key={idx}
                  className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 text-xs font-medium text-slate-700 dark:text-slate-300"
                >
                  {s}
                </div>
              ))
            )}
          </div>
        </div>

        {/* Preferences & Language */}
        <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
          <h3 className="text-sm font-bold uppercase tracking-wider text-slate-900 dark:text-white flex items-center gap-2">
            <Globe className="w-4 h-4 text-teal-600" /> Account Preferences
          </h3>

          <div className="space-y-3 text-xs">
            <div>
              <label className="block text-slate-500 font-semibold mb-1">Preferred Language:</label>
              <select
                value={language}
                onChange={(e) => handleLangChange(e.target.value as SupportedLanguage)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
              >
                {[
                  'English',
                  'Telugu',
                  'Hindi',
                  'Tamil',
                  'Kannada',
                  'Malayalam',
                  'Marathi',
                  'Bengali',
                  'Gujarati',
                  'Punjabi',
                  'Urdu',
                ].map((l) => (
                  <option key={l} value={l}>
                    {l}
                  </option>
                ))}
              </select>
            </div>

            <div className="pt-3 border-t border-slate-100 dark:border-slate-800 space-y-2">
              <p className="font-semibold text-slate-700 dark:text-slate-300">Quick Portal Shortcuts:</p>
              <button
                onClick={() => onNavigate('interactions')}
                className="w-full text-left p-2 rounded-lg bg-teal-50 dark:bg-teal-950/60 text-teal-700 dark:text-teal-300 font-semibold"
              >
                &bull; Drug Interaction Checker
              </button>
              <button
                onClick={() => onNavigate('student-hub')}
                className="w-full text-left p-2 rounded-lg bg-slate-50 dark:bg-slate-850 text-slate-700 dark:text-slate-300 font-semibold"
              >
                &bull; Student Academic Hub & Quizzes
              </button>
              <button
                onClick={() => onNavigate('emergency-near-me')}
                className="w-full text-left p-2 rounded-lg bg-red-50 dark:bg-red-950/40 text-red-700 dark:text-red-300 font-semibold"
              >
                &bull; Emergency Near Me Locator
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
