import React from 'react';
import {
  ArrowLeft,
  Bookmark,
  Share2,
  AlertTriangle,
  ShieldAlert,
  ShieldCheck,
  Stethoscope,
  Pill,
  HelpCircle,
  ExternalLink,
  Activity,
  HeartPulse,
} from 'lucide-react';
import { DISEASES_DATA } from '../data/mockData';
import { useAuth } from '../context/AuthContext';

interface DiseaseDetailProps {
  diseaseId: string;
  onBack: () => void;
  onNavigateToMedicine: (medicineId: string) => void;
  onOpenEmergency: () => void;
}

export const DiseaseDetail: React.FC<DiseaseDetailProps> = ({
  diseaseId,
  onBack,
  onNavigateToMedicine,
  onOpenEmergency,
}) => {
  const { toggleBookmark, isBookmarked } = useAuth();
  const disease = DISEASES_DATA.find((d) => d.id === diseaseId) || DISEASES_DATA[0];

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-10 animate-fade-in pb-16">
      {/* Back button & top bar */}
      <div className="flex items-center justify-between mb-6">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-xs font-semibold text-slate-500 hover:text-teal-600 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" /> Back to Disease Explorer
        </button>
        <div className="flex items-center gap-2">
          <button
            onClick={() => toggleBookmark(disease.id, 'disease', disease.name)}
            className={`px-3 py-1.5 rounded-lg border text-xs font-semibold flex items-center gap-1.5 transition-colors ${
              isBookmarked(disease.id)
                ? 'bg-teal-50 dark:bg-teal-950 border-teal-300 text-teal-600'
                : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-100'
            }`}
          >
            <Bookmark className="w-3.5 h-3.5" />
            {isBookmarked(disease.id) ? 'Saved' : 'Bookmark'}
          </button>
        </div>
      </div>

      {/* Disease Title Header */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-8 shadow-sm mb-8">
        <span className="text-xs font-bold uppercase tracking-wider text-teal-600 dark:text-teal-400 bg-teal-50 dark:bg-teal-950 px-2.5 py-1 rounded-md">
          {disease.category}
        </span>
        <h1 className="text-2xl sm:text-4xl font-extrabold text-slate-900 dark:text-white mt-3">
          {disease.name}
        </h1>
        {disease.scientificName && (
          <p className="text-xs sm:text-sm text-slate-400 italic mt-1">{disease.scientificName}</p>
        )}
        <p className="mt-4 text-sm sm:text-base text-slate-700 dark:text-slate-300 leading-relaxed">
          {disease.overview}
        </p>

        {/* Mandatory Educational Notice */}
        <div className="mt-6 p-4 rounded-xl bg-teal-50/70 dark:bg-teal-950/40 border border-teal-200 dark:border-teal-800 text-teal-950 dark:text-teal-200 text-xs flex items-center gap-3">
          <ShieldCheck className="w-5 h-5 text-teal-600 shrink-0" />
          <div>
            <strong>Educational Health Knowledge Only:</strong> This information is for education and does not replace a qualified healthcare professional. DRUGAI-LAB never makes definitive clinical diagnoses.
          </div>
        </div>
      </div>

      {/* Emergency Red Flags Callout */}
      <div className="mb-8 p-6 rounded-3xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 shadow-sm">
        <div className="flex items-center justify-between gap-4 mb-3">
          <h2 className="text-base font-bold text-red-900 dark:text-red-200 flex items-center gap-2">
            <ShieldAlert className="w-5 h-5 text-red-600 animate-pulse" />
            Critical Emergency Warning Signs:
          </h2>
          <button
            onClick={onOpenEmergency}
            className="px-3 py-1 rounded-lg bg-red-600 hover:bg-red-700 text-white text-xs font-bold transition-colors shrink-0"
          >
            Emergency Dial & ERs &rarr;
          </button>
        </div>
        <ul className="grid grid-cols-1 md:grid-cols-2 gap-2 text-xs text-red-950 dark:text-red-200">
          {disease.emergencyWarningSigns.map((sign, idx) => (
            <li key={idx} className="flex items-start gap-2 bg-white/60 dark:bg-red-900/20 p-2.5 rounded-xl border border-red-200/60 dark:border-red-800/60">
              <span className="text-red-600 font-bold">•</span>
              <span>{sign}</span>
            </li>
          ))}
        </ul>
      </div>

      {/* Structured Sections Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
        {/* Common Symptoms */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm">
          <h3 className="text-sm font-bold uppercase tracking-wider text-slate-900 dark:text-white mb-3 flex items-center gap-2">
            <Activity className="w-4 h-4 text-teal-600" /> Common Symptoms
          </h3>
          <ul className="space-y-2 text-xs text-slate-600 dark:text-slate-300">
            {disease.commonSymptoms.map((sym, i) => (
              <li key={i} className="flex items-start gap-2">
                <span className="text-teal-600 font-bold">•</span>
                <span>{sym}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Causes & Risk Factors */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm">
          <h3 className="text-sm font-bold uppercase tracking-wider text-slate-900 dark:text-white mb-3 flex items-center gap-2">
            <HeartPulse className="w-4 h-4 text-teal-600" /> Possible Causes & Risk Factors
          </h3>
          <ul className="space-y-2 text-xs text-slate-600 dark:text-slate-300">
            {disease.causesAndRisks.map((cause, i) => (
              <li key={i} className="flex items-start gap-2">
                <span className="text-teal-600 font-bold">•</span>
                <span>{cause}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Diagnostic Tests */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm">
          <h3 className="text-sm font-bold uppercase tracking-wider text-slate-900 dark:text-white mb-3 flex items-center gap-2">
            <Stethoscope className="w-4 h-4 text-teal-600" /> Common Diagnostic Tests
          </h3>
          <ul className="space-y-2 text-xs text-slate-600 dark:text-slate-300">
            {disease.diagnosticTests.map((test, i) => (
              <li key={i} className="flex items-start gap-2">
                <span className="text-teal-600 font-bold">•</span>
                <span>{test}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Prevention */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm">
          <h3 className="text-sm font-bold uppercase tracking-wider text-slate-900 dark:text-white mb-3 flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-teal-600" /> General Prevention Protocols
          </h3>
          <ul className="space-y-2 text-xs text-slate-600 dark:text-slate-300">
            {disease.prevention.map((prev, i) => (
              <li key={i} className="flex items-start gap-2">
                <span className="text-teal-600 font-bold">•</span>
                <span>{prev}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* Treatment & Medicine Categories */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm mb-8">
        <h3 className="text-base font-bold text-slate-900 dark:text-white mb-3 flex items-center gap-2">
          <Pill className="w-5 h-5 text-teal-600" /> General Treatment Approaches & Medicine Categories
        </h3>
        <p className="text-xs text-slate-500 mb-4">
          Dosage and suitability depend on the individual; consult a qualified healthcare professional and follow the official label/prescription.
        </p>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
            <h4 className="text-xs font-bold text-slate-700 dark:text-slate-300 uppercase mb-2">
              Clinical Treatment Approaches:
            </h4>
            <ul className="space-y-1.5 text-xs text-slate-600 dark:text-slate-300">
              {disease.treatmentApproaches.map((app, idx) => (
                <li key={idx} className="flex items-start gap-1.5">
                  <span className="text-teal-600 font-bold">•</span>
                  <span>{app}</span>
                </li>
              ))}
            </ul>
          </div>
          <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
            <h4 className="text-xs font-bold text-slate-700 dark:text-slate-300 uppercase mb-2">
              Commonly Prescribed Drug Classes:
            </h4>
            <ul className="space-y-1.5 text-xs text-slate-600 dark:text-slate-300">
              {disease.medicineCategories.map((medCat, idx) => (
                <li key={idx} className="flex items-start gap-1.5">
                  <span className="text-teal-600 font-bold">•</span>
                  <span>{medCat}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>

      {/* Frequently Asked Questions */}
      {disease.faqs.length > 0 && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm mb-8">
          <h3 className="text-base font-bold text-slate-900 dark:text-white mb-4 flex items-center gap-2">
            <HelpCircle className="w-5 h-5 text-teal-600" /> Frequently Asked Questions
          </h3>
          <div className="space-y-3">
            {disease.faqs.map((faq, idx) => (
              <div key={idx} className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700">
                <p className="text-xs font-bold text-slate-900 dark:text-white mb-1">{faq.question}</p>
                <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* References & Trusted Sources */}
      <div className="p-4 rounded-xl bg-slate-100 dark:bg-slate-800/40 text-slate-500 dark:text-slate-400 text-xs border border-slate-200 dark:border-slate-700">
        <h4 className="font-bold uppercase tracking-wider text-[11px] text-slate-600 dark:text-slate-300 mb-2">
          Clinical References & Guidelines:
        </h4>
        <ul className="space-y-1">
          {disease.sources.map((src, idx) => (
            <li key={idx} className="flex items-center gap-2">
              <span>• {src.title} — <strong>{src.organization}</strong></span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};
