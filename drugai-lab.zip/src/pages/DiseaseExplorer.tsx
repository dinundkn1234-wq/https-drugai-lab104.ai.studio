import React, { useState, useMemo } from 'react';
import { Activity, Search, Bookmark, ChevronRight, AlertTriangle, ShieldCheck, Filter } from 'lucide-react';
import { DISEASES_DATA } from '../data/mockData';
import { useAuth } from '../context/AuthContext';

interface DiseaseExplorerProps {
  onSelectDisease: (id: string) => void;
}

export const DiseaseExplorer: React.FC<DiseaseExplorerProps> = ({ onSelectDisease }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [rarityFilter, setRarityFilter] = useState<'all' | 'common' | 'rare'>('all');
  const { toggleBookmark, isBookmarked } = useAuth();

  const categories = useMemo(() => {
    const cats = Array.from(new Set(DISEASES_DATA.map((d) => d.category)));
    return ['All', ...cats];
  }, []);

  const filteredDiseases = useMemo(() => {
    return DISEASES_DATA.filter((d) => {
      const matchesSearch =
        d.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        d.commonSymptoms.some((s) => s.toLowerCase().includes(searchTerm.toLowerCase())) ||
        d.overview.toLowerCase().includes(searchTerm.toLowerCase());

      const matchesCat = selectedCategory === 'All' || d.category === selectedCategory;

      const matchesRarity =
        rarityFilter === 'all'
          ? true
          : rarityFilter === 'rare'
          ? Boolean(d.isRareDisease)
          : !d.isRareDisease;

      return matchesSearch && matchesCat && matchesRarity;
    });
  }, [searchTerm, selectedCategory, rarityFilter]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 animate-fade-in">
      {/* Header */}
      <div className="mb-8">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-teal-50 dark:bg-teal-950 text-teal-700 dark:text-teal-300 text-xs font-bold mb-2">
          <Activity className="w-3.5 h-3.5" />
          <span>Clinical Pathology Reference</span>
        </div>
        <h1 className="text-3xl font-extrabold text-slate-900 dark:text-white">
          Disease Information Database
        </h1>
        <p className="text-sm text-slate-500 mt-1">
          Explore evidence-based pathology summaries, symptoms, diagnostic tests, and prevention protocols.
        </p>

        {/* Mandatory Educational Disclaimer */}
        <div className="mt-4 p-3.5 rounded-xl bg-slate-100 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-xs text-slate-600 dark:text-slate-300 flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-teal-600 shrink-0" />
          <span>
            <strong>Educational Notice:</strong> This database is intended strictly for educational health literacy and does not replace a professional medical consultation or diagnostic evaluation.
          </span>
        </div>
      </div>

      {/* Search & Category Filter Controls */}
      <div className="flex flex-col gap-3 mb-8">
        <div className="flex flex-col md:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search by disease name, symptoms (e.g. fever, numbness, cough, ALS)..."
              className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-teal-500 shadow-sm"
            />
          </div>

          {/* Rarity Filter */}
          <div className="flex items-center gap-1.5 bg-white dark:bg-slate-800 p-1 rounded-xl border border-slate-200 dark:border-slate-700 shrink-0">
            <button
              onClick={() => setRarityFilter('all')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
                rarityFilter === 'all'
                  ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900 shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              All Conditions ({DISEASES_DATA.length})
            </button>
            <button
              onClick={() => setRarityFilter('common')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
                rarityFilter === 'common'
                  ? 'bg-teal-600 text-white shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              Common Diseases
            </button>
            <button
              onClick={() => setRarityFilter('rare')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
                rarityFilter === 'rare'
                  ? 'bg-purple-600 text-white shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              Rare & Orphan Diseases
            </button>
          </div>
        </div>

        {/* Categories Bar */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-2 md:pb-0">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer ${
                selectedCategory === cat
                  ? 'bg-teal-600 text-white shadow-sm'
                  : 'bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Disease Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredDiseases.map((d) => (
          <div
            key={d.id}
            className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm hover:shadow-md transition-all flex flex-col justify-between group"
          >
            <div>
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-1.5">
                  <span className="text-xs font-semibold text-teal-600 dark:text-teal-400">
                    {d.category}
                  </span>
                  {d.isRareDisease && (
                    <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-purple-100 dark:bg-purple-950 text-purple-700 dark:text-purple-300 border border-purple-200 dark:border-purple-800">
                      Rare Disease
                    </span>
                  )}
                </div>
                <button
                  onClick={() => toggleBookmark(d.id, 'disease', d.name)}
                  className={`p-1.5 rounded-lg border text-xs transition-colors ${
                    isBookmarked(d.id)
                      ? 'bg-teal-50 dark:bg-teal-950 border-teal-300 text-teal-600'
                      : 'border-slate-200 dark:border-slate-700 text-slate-400 hover:text-slate-600'
                  }`}
                  title="Save disease"
                >
                  <Bookmark className="w-3.5 h-3.5" />
                </button>
              </div>

              <h3
                onClick={() => onSelectDisease(d.id)}
                className="text-lg font-bold text-slate-900 dark:text-white group-hover:text-teal-600 cursor-pointer transition-colors"
              >
                {d.name}
              </h3>
              {d.scientificName && (
                <p className="text-[11px] text-slate-400 italic mb-2">{d.scientificName}</p>
              )}

              <p className="text-xs text-slate-600 dark:text-slate-300 line-clamp-3 leading-relaxed mb-4">
                {d.overview}
              </p>

              {/* Symptoms Preview */}
              <div className="mb-4">
                <p className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                  Common Symptoms:
                </p>
                <div className="flex flex-wrap gap-1.5">
                  {d.commonSymptoms.slice(0, 3).map((sym, idx) => (
                    <span
                      key={idx}
                      className="text-[10px] bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 px-2 py-0.5 rounded-md"
                    >
                      {sym.split('(')[0].trim()}
                    </span>
                  ))}
                  {d.commonSymptoms.length > 3 && (
                    <span className="text-[10px] text-slate-400 px-1 py-0.5">
                      +{d.commonSymptoms.length - 3} more
                    </span>
                  )}
                </div>
              </div>
            </div>

            <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
              <span className="text-[11px] text-red-500 font-semibold flex items-center gap-1">
                <AlertTriangle className="w-3 h-3" /> {d.emergencyWarningSigns.length} Emergency Red Flags
              </span>
              <button
                onClick={() => onSelectDisease(d.id)}
                className="text-xs font-bold text-teal-600 hover:text-teal-700 flex items-center gap-1 group-hover:translate-x-1 transition-transform"
              >
                Full Guide &rarr;
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
