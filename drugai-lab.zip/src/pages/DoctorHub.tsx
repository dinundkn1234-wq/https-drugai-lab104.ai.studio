import React, { useState } from 'react';
import {
  Stethoscope,
  ShieldCheck,
  CheckCircle2,
  FileText,
  Search,
  ExternalLink,
  Sparkles,
  Award,
  AlertTriangle,
  Lock,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { COMMON_INTERACTION_PRESETS } from '../data/mockData';

export const DoctorHub: React.FC<{ onNavigateToInteractions: () => void }> = ({
  onNavigateToInteractions,
}) => {
  const { user, verifyDoctorStatus } = useAuth();
  const [licenseInput, setLicenseInput] = useState('');
  const [institutionInput, setInstitutionInput] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const isVerified = user?.isDoctorVerified;

  const handleVerify = (e: React.FormEvent) => {
    e.preventDefault();
    if (!licenseInput.trim()) return;
    verifyDoctorStatus(licenseInput.trim());
    setSubmitted(true);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 animate-fade-in pb-16 space-y-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-slate-200 dark:border-slate-800">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-50 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 text-xs font-bold mb-2">
            <Stethoscope className="w-4 h-4" />
            <span>Professional Clinical Portal</span>
          </div>
          <h1 className="text-3xl font-black text-slate-900 dark:text-white">
            Doctor & Healthcare Professional Hub
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            Clinical reference library, drug-drug interaction matrix, and evidence-based practice guidelines.
          </p>
        </div>

        {/* Verification Status Badge */}
        <div>
          {isVerified ? (
            <div className="flex items-center gap-2 px-4 py-2 rounded-2xl bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-300 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200 text-xs font-bold shadow-sm">
              <CheckCircle2 className="w-5 h-5 text-emerald-600" />
              <div>
                <p>Verified Practitioner</p>
                <p className="text-[10px] font-normal opacity-80">
                  License: {user?.medicalLicenseNumber || 'MD-ACTIVE'}
                </p>
              </div>
            </div>
          ) : (
            <div className="flex items-center gap-2 px-4 py-2 rounded-2xl bg-amber-50 dark:bg-amber-950/60 border border-amber-300 dark:border-amber-800 text-amber-800 dark:text-amber-200 text-xs font-bold">
              <Lock className="w-4 h-4 text-amber-600" />
              <span>Unverified Account</span>
            </div>
          )}
        </div>
      </div>

      {/* Verification Prompt (If not verified) */}
      {!isVerified && (
        <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border-2 border-indigo-200 dark:border-indigo-900 shadow-xl space-y-4">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-indigo-100 dark:bg-indigo-950 text-indigo-600 rounded-xl">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-slate-900 dark:text-white">
                Healthcare Professional Verification
              </h3>
              <p className="text-xs text-slate-500">
                To prevent unverified users from claiming clinician status, enter your medical license or council registration number to access high-density tools.
              </p>
            </div>
          </div>

          <form onSubmit={handleVerify} className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
            <input
              type="text"
              value={licenseInput}
              onChange={(e) => setLicenseInput(e.target.value)}
              placeholder="Medical License # (e.g. MD-98214-US)"
              required
              className="px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs focus:ring-2 focus:ring-indigo-500"
            />
            <input
              type="text"
              value={institutionInput}
              onChange={(e) => setInstitutionInput(e.target.value)}
              placeholder="Hospital / University Institution"
              className="px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs focus:ring-2 focus:ring-indigo-500"
            />
            <button
              type="submit"
              className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-sm transition-colors"
            >
              Verify Credentials
            </button>
          </form>
        </div>
      )}

      {/* Clinical Reference Tools */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Tool 1: Interaction Matrix */}
        <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
          <div>
            <div className="w-10 h-10 rounded-xl bg-teal-100 dark:bg-teal-950 text-teal-600 flex items-center justify-center mb-3">
              <Sparkles className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              Clinical Interaction Engine
            </h3>
            <p className="text-xs text-slate-500 mt-1 leading-relaxed">
              Screen polypharmacy regimens against CYP450 enzymes, P-glycoprotein efflux, and synergistic QT prolongation.
            </p>
          </div>
          <button
            onClick={onNavigateToInteractions}
            className="mt-4 w-full py-2.5 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold transition-colors"
          >
            Launch Interaction Screener &rarr;
          </button>
        </div>

        {/* Tool 2: Clinical Guidelines Search */}
        <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
          <div>
            <div className="w-10 h-10 rounded-xl bg-indigo-100 dark:bg-indigo-950 text-indigo-600 flex items-center justify-center mb-3">
              <FileText className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              Evidence-Based Practice Guidelines
            </h3>
            <p className="text-xs text-slate-500 mt-1 leading-relaxed">
              Direct access to updated AHA/ACC, ADA, GINA, and WHO therapeutic guidelines and treatment algorithms.
            </p>
          </div>
          <a
            href="https://www.who.int/publications/guidelines"
            target="_blank"
            rel="noopener noreferrer"
            className="mt-4 w-full py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 text-xs font-bold text-center hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors flex items-center justify-center gap-1.5"
          >
            Browse WHO Guidelines <ExternalLink className="w-3.5 h-3.5" />
          </a>
        </div>

        {/* Tool 3: PubMed & Clinical Trials Index */}
        <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
          <div>
            <div className="w-10 h-10 rounded-xl bg-purple-100 dark:bg-purple-950 text-purple-600 flex items-center justify-center mb-3">
              <Search className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              ClinicalTrials.gov & PubMed
            </h3>
            <p className="text-xs text-slate-500 mt-1 leading-relaxed">
              Locate active phase III/IV clinical trials, investigational drug status, and peer-reviewed safety bulletins.
            </p>
          </div>
          <a
            href="https://clinicaltrials.gov"
            target="_blank"
            rel="noopener noreferrer"
            className="mt-4 w-full py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 text-xs font-bold text-center hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors flex items-center justify-center gap-1.5"
          >
            Access ClinicalTrials.gov <ExternalLink className="w-3.5 h-3.5" />
          </a>
        </div>
      </div>

      {/* Presets Table for Doctors */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm">
        <h3 className="text-base font-bold text-slate-900 dark:text-white mb-4">
          High-Risk Pharmacological Combinations Under Surveillance
        </h3>
        <div className="divide-y divide-slate-100 dark:divide-slate-800 text-xs">
          {COMMON_INTERACTION_PRESETS.map((p, idx) => (
            <div key={idx} className="py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <p className="font-bold text-slate-900 dark:text-white">{p.name}</p>
                <p className="text-slate-500 text-[11px]">{p.description}</p>
              </div>
              <span className="text-[10px] font-bold px-2.5 py-1 rounded-full bg-red-100 dark:bg-red-950 text-red-700 dark:text-red-300 shrink-0">
                Surveillance Active
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
