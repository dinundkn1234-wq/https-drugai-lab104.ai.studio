import React, { useState } from 'react';
import {
  ShieldAlert,
  AlertTriangle,
  Pill,
  Sparkles,
  HelpCircle,
  FileCheck,
  CheckCircle2,
  Trash2,
  Lock,
  Search,
  ArrowRight,
  ShieldCheck,
  Stethoscope,
} from 'lucide-react';
import { MEDICINES_DATA } from '../data/mockData';

interface DrugAwarenessProps {
  onCheckInteraction: (med: string) => void;
}

export const DrugAwarenessCenter: React.FC<DrugAwarenessProps> = ({ onCheckInteraction }) => {
  const [knowMedSearch, setKnowMedSearch] = useState('');
  const [searchedMed, setSearchedMed] = useState<(typeof MEDICINES_DATA)[0] | null>(null);

  const handleLookup = () => {
    if (!knowMedSearch.trim()) return;
    const found = MEDICINES_DATA.find(
      (m) =>
        m.genericName.toLowerCase().includes(knowMedSearch.toLowerCase().trim()) ||
        m.brandNames.some((b) => b.toLowerCase().includes(knowMedSearch.toLowerCase().trim()))
    );
    setSearchedMed(found || null);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 animate-fade-in pb-16 space-y-12">
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-teal-50 dark:bg-teal-950 text-teal-700 dark:text-teal-300 text-xs font-bold mb-3">
          <ShieldAlert className="w-3.5 h-3.5" />
          <span>Patient & Community Safety Center</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-black text-slate-900 dark:text-white tracking-tight">
          Drug Awareness & Medication Safety
        </h1>
        <p className="text-sm sm:text-base text-slate-600 dark:text-slate-300 mt-2">
          Promoting rational medicine use, combating antibiotic resistance, understanding active ingredients, and preventing medication errors.
        </p>
      </div>

      {/* Feature: "Know Your Medicine" Interactive Tool */}
      <div className="bg-gradient-to-br from-teal-900 via-slate-900 to-teal-950 text-white rounded-3xl p-6 sm:p-10 shadow-2xl">
        <div className="max-w-3xl">
          <span className="text-xs font-bold uppercase tracking-wider text-teal-400">
            Interactive Safety Tool
          </span>
          <h2 className="text-2xl sm:text-3xl font-extrabold mt-1">Know Your Medicine</h2>
          <p className="text-xs sm:text-sm text-slate-300 mt-2">
            Enter any prescription or OTC medication name to discover its primary purpose, safety checkpoints, and essential questions to ask your pharmacist.
          </p>

          <div className="mt-6 flex flex-col sm:flex-row gap-2 max-w-xl">
            <input
              type="text"
              value={knowMedSearch}
              onChange={(e) => setKnowMedSearch(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleLookup()}
              placeholder="e.g. Paracetamol, Metformin, Amoxicillin, Lisinopril..."
              className="flex-1 px-4 py-3 rounded-xl bg-white/10 border border-white/20 text-white placeholder-slate-400 text-sm focus:outline-none focus:ring-2 focus:ring-teal-400"
            />
            <button
              onClick={handleLookup}
              className="px-6 py-3 rounded-xl bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold text-sm transition-colors flex items-center justify-center gap-2"
            >
              <Search className="w-4 h-4" /> Lookup Drug
            </button>
          </div>
        </div>

        {/* Lookup Result Box */}
        {searchedMed && (
          <div className="mt-8 p-6 rounded-2xl bg-white/10 border border-white/15 backdrop-blur-md animate-fade-in text-slate-100">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-white/10 pb-3 mb-4">
              <div>
                <h3 className="text-xl font-bold text-white">{searchedMed.genericName}</h3>
                <p className="text-xs text-teal-300">
                  Brands: {searchedMed.brandNames.join(', ')} • {searchedMed.scheduleType}
                </p>
              </div>
              <button
                onClick={() => onCheckInteraction(searchedMed.genericName)}
                className="px-3 py-1.5 rounded-lg bg-teal-600 hover:bg-teal-500 text-white text-xs font-semibold"
              >
                Screen Interactions &rarr;
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
              <div className="space-y-1">
                <p className="font-bold text-teal-300">What it is generally used for:</p>
                <p className="text-slate-200">{searchedMed.generalUses.join(' • ')}</p>
              </div>
              <div className="space-y-1">
                <p className="font-bold text-amber-300">Important Safety Warning:</p>
                <p className="text-slate-200">{searchedMed.importantWarnings[0]}</p>
              </div>
              <div className="space-y-1">
                <p className="font-bold text-cyan-300">Common Precautions:</p>
                <p className="text-slate-200">{searchedMed.contraindications.join(', ')}</p>
              </div>
              <div className="space-y-1">
                <p className="font-bold text-purple-300">Questions to Ask Your Pharmacist:</p>
                <ul className="space-y-0.5 text-slate-200">
                  <li>• Does this medication interact with any vitamins or other pills I take?</li>
                  <li>• Should I take this with meals or on an empty stomach?</li>
                  <li>• What should I do if I accidentally miss a scheduled dose?</li>
                </ul>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Safety Awareness Topics Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Topic 1: Antibiotic Resistance Crisis */}
        <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-3">
          <div className="w-10 h-10 rounded-xl bg-red-100 dark:bg-red-950 text-red-600 flex items-center justify-center">
            <AlertTriangle className="w-5 h-5" />
          </div>
          <h3 className="text-base font-bold text-slate-900 dark:text-white">
            Antibiotic Resistance & Misuse
          </h3>
          <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
            Antibiotics only kill bacteria, never viruses (colds, influenza, COVID-19). Taking antibiotics unnecessarily trains bacteria to survive, creating untreatable superbugs worldwide. Always complete the entire prescribed course.
          </p>
          <ul className="text-[11px] text-slate-500 space-y-1 pt-2 border-t border-slate-100 dark:border-slate-800">
            <li>• Never save leftover antibiotics for future illnesses.</li>
            <li>• Never share prescription antibiotics with family members.</li>
          </ul>
        </div>

        {/* Topic 2: Prescription vs OTC Medicines */}
        <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-3">
          <div className="w-10 h-10 rounded-xl bg-teal-100 dark:bg-teal-950 text-teal-600 flex items-center justify-center">
            <Pill className="w-5 h-5" />
          </div>
          <h3 className="text-base font-bold text-slate-900 dark:text-white">
            Reading Labels & Active Ingredients
          </h3>
          <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
            Many over-the-counter cough, cold, sinus, and sleep remedies contain identical active ingredients (e.g., Acetaminophen/Paracetamol). Taking multiple multi-symptom products simultaneously can cause accidental fatal overdose.
          </p>
          <ul className="text-[11px] text-slate-500 space-y-1 pt-2 border-t border-slate-100 dark:border-slate-800">
            <li>• Always check the "Active Ingredients" box on the back label.</li>
            <li>• Use calibrated oral measuring syringes, never household spoons.</li>
          </ul>
        </div>

        {/* Topic 3: Counterfeit Medicine Awareness */}
        <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-3">
          <div className="w-10 h-10 rounded-xl bg-amber-100 dark:bg-amber-950 text-amber-600 flex items-center justify-center">
            <Lock className="w-5 h-5" />
          </div>
          <h3 className="text-base font-bold text-slate-900 dark:text-white">
            Spotting Fakes & Counterfeit Drugs
          </h3>
          <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
            Counterfeit medicines may contain zero active ingredients or deadly adulterants. Only purchase medications from government-licensed pharmacies. Be wary of online stores offering prescription drugs without prescriptions.
          </p>
          <ul className="text-[11px] text-slate-500 space-y-1 pt-2 border-t border-slate-100 dark:border-slate-800">
            <li>• Check for security holograms and unbreached tamper seals.</li>
            <li>• Report spelling mistakes or blurry fonts to regulatory authorities.</li>
          </ul>
        </div>

        {/* Topic 4: Safe Storage & Eco-Friendly Disposal */}
        <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-100 dark:bg-emerald-950 text-emerald-600 flex items-center justify-center">
            <Trash2 className="w-5 h-5" />
          </div>
          <h3 className="text-base font-bold text-slate-900 dark:text-white">
            Safe Storage & Eco Disposal
          </h3>
          <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
            Never store medicines in warm, humid bathrooms. Keep them in a cool, dry place out of reach of children. Avoid flushing pills down the toilet to prevent contaminating municipal waterways; use pharmacy take-back drop boxes.
          </p>
        </div>

        {/* Topic 5: Dependence & Pain Medications */}
        <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-3">
          <div className="w-10 h-10 rounded-xl bg-purple-100 dark:bg-purple-950 text-purple-600 flex items-center justify-center">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <h3 className="text-base font-bold text-slate-900 dark:text-white">
            Pain Medicines & Sedating Drugs
          </h3>
          <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
            Opioids, benzodiazepines, and muscle relaxants carry risks of psychological and physiological dependence. Combining sedating medicines with alcohol drastically suppresses respiratory drive and can be fatal.
          </p>
        </div>

        {/* Topic 6: Risks of Sharing Prescriptions */}
        <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-3">
          <div className="w-10 h-10 rounded-xl bg-cyan-100 dark:bg-cyan-950 text-cyan-600 flex items-center justify-center">
            <Stethoscope className="w-5 h-5" />
          </div>
          <h3 className="text-base font-bold text-slate-900 dark:text-white">
            Risks of Unsupervised Sharing
          </h3>
          <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
            A medicine that successfully treats one family member might cause kidney failure, liver toxicity, or fatal allergic shock in another due to unseen drug interactions, undisclosed allergies, or organ differences.
          </p>
        </div>
      </div>
    </div>
  );
};
