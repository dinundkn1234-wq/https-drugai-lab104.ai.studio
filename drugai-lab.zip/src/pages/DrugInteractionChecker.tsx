import React, { useState } from 'react';
import {
  Pill,
  AlertTriangle,
  ShieldCheck,
  Plus,
  X,
  Sparkles,
  RefreshCw,
  HelpCircle,
  Stethoscope,
  Info,
  CheckCircle2,
  Bookmark,
  Share2,
  Printer,
  ChevronRight,
  Flame,
  ArrowRight,
} from 'lucide-react';
import { COMMON_INTERACTION_PRESETS, MEDICINES_DATA } from '../data/mockData';
import { DrugInteractionResponse, DrugInteractionPair } from '../types';
import { useLanguage } from '../context/LanguageContext';
import { useAuth } from '../context/AuthContext';

export const DrugInteractionChecker: React.FC = () => {
  const { language } = useLanguage();
  const { user, toggleBookmark } = useAuth();

  const [medications, setMedications] = useState<string[]>(['Warfarin', 'Aspirin']);
  const [inputValue, setInputValue] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<DrugInteractionResponse | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [savedReport, setSavedReport] = useState(false);

  const handleAddMedication = (name: string) => {
    const trimmed = name.trim();
    if (!trimmed) return;
    if (medications.some((m) => m.toLowerCase() === trimmed.toLowerCase())) {
      return;
    }
    setMedications([...medications, trimmed]);
    setInputValue('');
    setError(null);
  };

  const handleRemoveMedication = (index: number) => {
    setMedications(medications.filter((_, i) => i !== index));
    if (result) setResult(null);
  };

  const handleApplyPreset = (drugs: string[]) => {
    setMedications(drugs);
    setResult(null);
    setError(null);
  };

  const handleCheckInteractions = async () => {
    if (medications.length < 2) {
      setError('Please add at least 2 medications to screen for drug-drug interactions.');
      return;
    }

    setLoading(true);
    setError(null);
    setResult(null);
    setSavedReport(false);

    try {
      const response = await fetch('/api/ai/interaction-checker', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          medications,
          language,
        }),
      });

      if (!response.ok) {
        throw new Error('Server returned an error processing interactions');
      }

      const data: DrugInteractionResponse = await response.json();
      setResult(data);
    } catch (err: any) {
      console.error('Interaction checker error:', err);
      setError(
        'Unable to complete AI interaction screening at this time. Please check your connection and try again.'
      );
    } finally {
      setLoading(false);
    }
  };

  // Severity style helper
  const getSeverityBadge = (severity: string) => {
    switch (severity) {
      case 'Major':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-red-100 text-red-800 dark:bg-red-950 dark:text-red-300 border border-red-300 dark:border-red-800">
            <Flame className="w-3.5 h-3.5 text-red-600 animate-pulse" />
            MAJOR CLINICAL SEVERITY
          </span>
        );
      case 'Moderate':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300 border border-amber-300 dark:border-amber-800">
            <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
            MODERATE CLINICAL SEVERITY
          </span>
        );
      case 'Minor':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-sky-100 text-sky-800 dark:bg-sky-950 dark:text-sky-300 border border-sky-300 dark:border-sky-800">
            <Info className="w-3.5 h-3.5 text-sky-600" />
            MINOR INTERACTION
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
            NO SEVERE INTERACTION FOUND
          </span>
        );
    }
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-10 animate-fade-in">
      {/* Header & Tagline */}
      <div className="text-center max-w-3xl mx-auto mb-8">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-teal-50 dark:bg-teal-950/60 border border-teal-200 dark:border-teal-800 text-teal-700 dark:text-teal-300 text-xs font-semibold mb-3">
          <Sparkles className="w-3.5 h-3.5" />
          <span>DRUGAI Clinical Pharmacology Engine</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 dark:text-white tracking-tight">
          AI-Powered Drug Interaction Checker
        </h1>
        <p className="text-sm sm:text-base text-slate-600 dark:text-slate-300 mt-2">
          Screen for potential pharmacological interactions, synergistic adverse reactions, and contraindications across generic and brand-name medications.
        </p>
      </div>

      {/* Prominent Mandatory Safety Disclaimer Box */}
      <div className="mb-8 p-4 sm:p-5 rounded-2xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800/60 text-amber-900 dark:text-amber-200 text-xs sm:text-sm flex items-start gap-3 shadow-sm">
        <AlertTriangle className="w-5 h-5 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
        <div>
          <p className="font-bold">Important Clinical Safety & Medical Regimen Disclaimer:</p>
          <p className="mt-1 text-xs text-amber-800 dark:text-amber-300 leading-relaxed">
            This AI interaction screener provides educational pharmacology insights and is <strong>NOT a substitute for professional clinical judgment</strong>. Never stop, change dosages, or start any medication without explicit guidance from your prescribing physician or licensed dispensing pharmacist. In an emergency, dial local emergency medical services immediately.
          </p>
        </div>
      </div>

      {/* Main Interactive Checker Panel */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-8 shadow-xl mb-10">
        <label className="block text-sm font-bold text-slate-900 dark:text-white mb-2">
          Enter Medications to Screen (Generic or Brand Names):
        </label>

        {/* Input & Add Row */}
        <div className="flex flex-col sm:flex-row gap-2 mb-4">
          <div className="relative flex-1">
            <input
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  e.preventDefault();
                  handleAddMedication(inputValue);
                }
              }}
              placeholder="e.g. Warfarin, Aspirin, Metformin, Lisinopril, Atorvastatin..."
              className="w-full px-4 py-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white placeholder-slate-400 text-sm focus:outline-none focus:ring-2 focus:ring-teal-500"
            />
          </div>
          <button
            onClick={() => handleAddMedication(inputValue)}
            className="px-5 py-3 rounded-xl bg-teal-600 hover:bg-teal-700 text-white font-bold text-sm flex items-center justify-center gap-2 transition-colors shadow-sm"
          >
            <Plus className="w-4 h-4" />
            Add Medicine
          </button>
        </div>

        {/* Added Medication Pills */}
        <div className="mb-6">
          <div className="text-xs font-semibold text-slate-500 dark:text-slate-400 mb-2">
            Selected Medications for Analysis ({medications.length}):
          </div>
          <div className="flex flex-wrap gap-2 min-h-[42px] p-2 rounded-xl bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800 items-center">
            {medications.length === 0 ? (
              <span className="text-xs text-slate-400 italic px-2">
                No medications added yet. Type a medicine above or click a preset below.
              </span>
            ) : (
              medications.map((med, idx) => (
                <span
                  key={`${med}-${idx}`}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-teal-100 text-teal-900 dark:bg-teal-950 dark:text-teal-200 text-xs font-semibold border border-teal-200 dark:border-teal-800 animate-fade-in"
                >
                  <Pill className="w-3.5 h-3.5 text-teal-600" />
                  {med}
                  <button
                    onClick={() => handleRemoveMedication(idx)}
                    className="p-0.5 hover:bg-teal-200 dark:hover:bg-teal-900 rounded-full transition-colors text-teal-700 dark:text-teal-400"
                    title={`Remove ${med}`}
                  >
                    <X className="w-3 h-3" />
                  </button>
                </span>
              ))
            )}
          </div>
        </div>

        {/* Quick Common Presets */}
        <div className="mb-6">
          <p className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">
            Quick Clinical Test Presets:
          </p>
          <div className="flex flex-wrap gap-2">
            {COMMON_INTERACTION_PRESETS.map((p) => (
              <button
                key={p.name}
                onClick={() => handleApplyPreset(p.drugs)}
                className="px-3 py-1.5 rounded-lg text-xs bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-teal-50 dark:hover:bg-teal-950/60 hover:text-teal-700 dark:hover:text-teal-300 border border-slate-200 dark:border-slate-700 transition-colors"
                title={p.description}
              >
                {p.name}
              </button>
            ))}
          </div>
        </div>

        {/* Error Callout */}
        {error && (
          <div className="mb-6 p-4 rounded-xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-800 text-red-700 dark:text-red-300 text-xs flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {/* Action Button */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-2 border-t border-slate-100 dark:border-slate-800">
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Analyzing {medications.length} drug{medications.length !== 1 ? 's' : ''} with current language: <strong>{language}</strong>
          </p>
          <button
            onClick={handleCheckInteractions}
            disabled={loading || medications.length < 2}
            className={`w-full sm:w-auto px-7 py-3 rounded-xl font-bold text-sm flex items-center justify-center gap-2 transition-all shadow-md ${
              loading || medications.length < 2
                ? 'bg-slate-300 dark:bg-slate-800 text-slate-500 cursor-not-allowed'
                : 'bg-gradient-to-r from-teal-600 to-cyan-600 hover:from-teal-700 hover:to-cyan-700 text-white shadow-teal-500/20 hover:scale-[1.01]'
            }`}
          >
            {loading ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                Screening Pharmacology Database...
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                Analyze Drug Interactions
              </>
            )}
          </button>
        </div>
      </div>

      {/* Loading Skeleton Indicator */}
      {loading && (
        <div className="p-8 text-center bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xl mb-10 animate-pulse">
          <div className="w-12 h-12 mx-auto rounded-full bg-teal-100 dark:bg-teal-950 flex items-center justify-center text-teal-600 mb-4">
            <RefreshCw className="w-6 h-6 animate-spin" />
          </div>
          <h3 className="text-base font-bold text-slate-900 dark:text-white">
            Running Pharmacodynamic & Cytochrome P450 Analysis...
          </h3>
          <p className="text-xs text-slate-500 mt-1">
            Cross-referencing drug metabolism pathways, receptor competition, and clinical adverse profiles.
          </p>
        </div>
      )}

      {/* Interaction Results Section */}
      {result && (
        <div className="space-y-6 animate-fade-in mb-12">
          {/* Top Overall Result Banner */}
          <div
            className={`p-6 sm:p-8 rounded-3xl border shadow-xl ${
              result.overallRisk === 'Major'
                ? 'bg-red-50/80 dark:bg-red-950/30 border-red-200 dark:border-red-900'
                : result.overallRisk === 'Moderate'
                ? 'bg-amber-50/80 dark:bg-amber-950/30 border-amber-200 dark:border-amber-900'
                : result.overallRisk === 'Minor'
                ? 'bg-sky-50/80 dark:bg-sky-950/30 border-sky-200 dark:border-sky-900'
                : 'bg-emerald-50/80 dark:bg-emerald-950/30 border-emerald-200 dark:border-emerald-900'
            }`}
          >
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-4">
              <div>
                <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                  Comprehensive Screening Assessment
                </span>
                <div className="mt-1">{getSeverityBadge(result.overallRisk)}</div>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => window.print()}
                  className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 flex items-center gap-1.5"
                >
                  <Printer className="w-3.5 h-3.5" /> Print / Save PDF
                </button>
                <button
                  onClick={() => {
                    toggleBookmark(
                      `interaction_${medications.join('_')}`,
                      'medicine',
                      `Interaction: ${medications.join(' + ')}`
                    );
                    setSavedReport(true);
                  }}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 border transition-colors ${
                    savedReport
                      ? 'bg-teal-600 text-white border-teal-600'
                      : 'bg-white dark:bg-slate-800 border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                  }`}
                >
                  <Bookmark className="w-3.5 h-3.5" />
                  {savedReport ? 'Saved to Bookmarks' : 'Bookmark Report'}
                </button>
              </div>
            </div>

            <p className="text-sm sm:text-base font-semibold text-slate-900 dark:text-white leading-relaxed">
              {result.summary}
            </p>

            <div className="mt-3 text-[11px] text-slate-500 dark:text-slate-400 flex items-center gap-2">
              <span className="font-semibold">Analyzed Sources:</span> {result.source || 'DRUGAI Intelligence'}
            </div>
          </div>

          {/* Pairwise Interactions List */}
          {result.interactions.length > 0 ? (
            <div className="space-y-4">
              <h3 className="text-base font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-amber-500" />
                Detected Drug-Drug Pair Interactions ({result.interactions.length}):
              </h3>

              {result.interactions.map((interaction, i) => (
                <div
                  key={i}
                  className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-md"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 dark:border-slate-800 pb-3 mb-4">
                    <div className="flex items-center gap-2">
                      <span className="text-base font-bold text-slate-900 dark:text-white">
                        {interaction.pair[0]} <span className="text-teal-600">&harr;</span> {interaction.pair[1]}
                      </span>
                    </div>
                    <div>{getSeverityBadge(interaction.severity)}</div>
                  </div>

                  <p className="text-sm font-medium text-slate-800 dark:text-slate-200 mb-4">
                    {interaction.description}
                  </p>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                    {/* Mechanism Box */}
                    <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/80">
                      <h4 className="font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider text-[11px] mb-1.5 flex items-center gap-1.5">
                        <Info className="w-3.5 h-3.5 text-teal-600" />
                        Pharmacological Mechanism:
                      </h4>
                      <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
                        {interaction.mechanism}
                      </p>
                    </div>

                    {/* Clinical Manifestations */}
                    <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/80">
                      <h4 className="font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider text-[11px] mb-1.5 flex items-center gap-1.5">
                        <AlertTriangle className="w-3.5 h-3.5 text-amber-500" />
                        Adverse Manifestations to Watch For:
                      </h4>
                      <ul className="space-y-1 text-slate-600 dark:text-slate-300">
                        {interaction.clinicalEffects.map((effect, effIdx) => (
                          <li key={effIdx} className="flex items-start gap-1.5">
                            <span className="text-red-500 font-bold">•</span>
                            <span>{effect}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    {/* Precautions */}
                    <div className="p-3.5 rounded-xl bg-teal-50/50 dark:bg-teal-950/20 border border-teal-200/60 dark:border-teal-800/60">
                      <h4 className="font-bold text-teal-900 dark:text-teal-200 uppercase tracking-wider text-[11px] mb-1.5 flex items-center gap-1.5">
                        <ShieldCheck className="w-3.5 h-3.5 text-teal-600" />
                        Recommended Clinical Precautions:
                      </h4>
                      <ul className="space-y-1 text-teal-950 dark:text-teal-200">
                        {interaction.precautions.map((prec, pIdx) => (
                          <li key={pIdx} className="flex items-start gap-1.5">
                            <span className="text-teal-600 font-bold">•</span>
                            <span>{prec}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    {/* Questions for Clinician */}
                    <div className="p-3.5 rounded-xl bg-indigo-50/50 dark:bg-indigo-950/20 border border-indigo-200/60 dark:border-indigo-800/60">
                      <h4 className="font-bold text-indigo-900 dark:text-indigo-200 uppercase tracking-wider text-[11px] mb-1.5 flex items-center gap-1.5">
                        <Stethoscope className="w-3.5 h-3.5 text-indigo-600" />
                        Questions to Ask Your Doctor or Pharmacist:
                      </h4>
                      <ul className="space-y-1 text-indigo-950 dark:text-indigo-200">
                        {interaction.questionsForClinician.map((q, qIdx) => (
                          <li key={qIdx} className="flex items-start gap-1.5">
                            <span className="text-indigo-600 font-bold">?</span>
                            <span>{q}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="p-8 text-center bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-md">
              <CheckCircle2 className="w-10 h-10 text-emerald-500 mx-auto mb-3" />
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                No Known Severe Documented Interactions
              </h3>
              <p className="text-xs text-slate-500 mt-1 max-w-md mx-auto">
                No primary adverse combinations were detected in our screening database for these specific medications. Still inform your doctor of any changes.
              </p>
            </div>
          )}

          {/* General Safe Medication Notes */}
          {result.generalSafetyNotes && result.generalSafetyNotes.length > 0 && (
            <div className="p-6 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-2">
                Standard Safe Medication Protocols:
              </h4>
              <ul className="text-xs text-slate-600 dark:text-slate-300 space-y-1.5">
                {result.generalSafetyNotes.map((note, idx) => (
                  <li key={idx} className="flex items-start gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-teal-600 shrink-0 mt-0.5" />
                    <span>{note}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Footer Official Disclaimer */}
          <div className="p-4 rounded-xl bg-slate-100 dark:bg-slate-950 text-slate-500 dark:text-slate-400 text-[11px] leading-relaxed border border-slate-200 dark:border-slate-800">
            <strong>Clinical Safety Rule:</strong> {result.disclaimer}
          </div>
        </div>
      )}
    </div>
  );
};
