import React, { useState } from 'react';
import { FileText, Clock, ExternalLink, ArrowRight, Bookmark } from 'lucide-react';
import { HEALTH_ARTICLES } from '../data/mockData';
import { useAuth } from '../context/AuthContext';

export const HealthArticles: React.FC<{ onSelectArticle: (id: string) => void }> = ({
  onSelectArticle,
}) => {
  const { toggleBookmark, isBookmarked } = useAuth();
  const [filterCat, setFilterCat] = useState('All');

  const categories = ['All', 'Medication Safety', 'Drug Awareness', 'Emergency Care'];

  const filtered =
    filterCat === 'All'
      ? HEALTH_ARTICLES
      : HEALTH_ARTICLES.filter((a) => a.category === filterCat);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 animate-fade-in pb-16 space-y-8">
      {/* Header */}
      <div>
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-teal-50 dark:bg-teal-950 text-teal-700 dark:text-teal-300 text-xs font-bold mb-2">
          <FileText className="w-3.5 h-3.5" />
          <span>Public Health Education</span>
        </div>
        <h1 className="text-3xl font-extrabold text-slate-900 dark:text-white">
          Health Education & Awareness Articles
        </h1>
        <p className="text-sm text-slate-500 mt-1">
          Evidence-based articles on disease prevention, medicine safety, antibiotic stewardship, and first aid.
        </p>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 dark:border-slate-800 pb-3">
        {categories.map((c) => (
          <button
            key={c}
            onClick={() => setFilterCat(c)}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-colors ${
              filterCat === c
                ? 'bg-teal-600 text-white'
                : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-100'
            }`}
          >
            {c}
          </button>
        ))}
      </div>

      {/* Articles Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {filtered.map((art) => (
          <div
            key={art.id}
            className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-8 shadow-sm hover:shadow-md transition-all flex flex-col justify-between group"
          >
            <div>
              <div className="flex items-center justify-between text-xs text-slate-400 mb-3">
                <span className="text-teal-600 dark:text-teal-400 font-bold uppercase tracking-wider text-[10px]">
                  {art.category}
                </span>
                <div className="flex items-center gap-2">
                  <span className="flex items-center gap-1">
                    <Clock className="w-3 h-3" /> {art.readTime}
                  </span>
                  <button
                    onClick={() => toggleBookmark(art.id, 'article', art.title)}
                    className={`p-1.5 rounded-lg border text-xs ${
                      isBookmarked(art.id)
                        ? 'bg-teal-50 border-teal-300 text-teal-600'
                        : 'border-slate-200 text-slate-400'
                    }`}
                  >
                    <Bookmark className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              <h3
                onClick={() => onSelectArticle(art.id)}
                className="text-xl font-bold text-slate-900 dark:text-white group-hover:text-teal-600 cursor-pointer transition-colors leading-snug"
              >
                {art.title}
              </h3>

              <p className="text-xs text-slate-600 dark:text-slate-300 mt-3 line-clamp-3 leading-relaxed">
                {art.summary}
              </p>

              <div className="mt-4 p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 text-slate-500 text-[11px]">
                <strong>Key Takeaway:</strong> {art.keyTakeaways[0]}
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
              <span className="text-slate-400">By {art.organization}</span>
              <button
                onClick={() => onSelectArticle(art.id)}
                className="font-bold text-teal-600 hover:text-teal-700 flex items-center gap-1 group-hover:translate-x-1 transition-transform"
              >
                Read Full Article &rarr;
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
