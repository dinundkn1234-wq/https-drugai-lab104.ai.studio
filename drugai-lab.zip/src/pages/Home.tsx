import React from 'react';
import {
  Activity,
  Search,
  Sparkles,
  Bot,
  Mic,
  ShieldAlert,
  Pill,
  BookOpen,
  Stethoscope,
  MapPin,
  FileText,
  AlertTriangle,
  ArrowRight,
  ShieldCheck,
  ChevronRight,
  Bookmark,
  Users,
  Compass,
} from 'lucide-react';
import { DISEASES_DATA, MEDICINES_DATA, HEALTH_ARTICLES, EMERGENCY_HOSPITALS_DATA } from '../data/mockData';
import { useLanguage } from '../context/LanguageContext';

interface HomeProps {
  onNavigate: (tab: string, param?: string) => void;
  onOpenEmergency: () => void;
  onOpenSearch: () => void;
}

export const Home: React.FC<HomeProps> = ({ onNavigate, onOpenEmergency, onOpenSearch }) => {
  const { t } = useLanguage();

  return (
    <div className="space-y-16 animate-fade-in pb-16">
      {/* 1. Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-b from-teal-50/60 via-white to-slate-50 dark:from-slate-900/60 dark:via-slate-900 dark:to-slate-950 pt-12 pb-20 border-b border-slate-200/60 dark:border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
          {/* Subtle Tagline Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-teal-100/70 dark:bg-teal-950/80 border border-teal-200 dark:border-teal-800 text-teal-800 dark:text-teal-200 text-xs font-bold tracking-wide mb-6">
            <Sparkles className="w-4 h-4 text-teal-600 dark:text-teal-400" />
            <span>AI-POWERED HEALTH KNOWLEDGE, MEDICINE AWARENESS & EMERGENCY SUPPORT</span>
          </div>

          {/* Main Title & Subtitle */}
          <h1 className="text-4xl sm:text-6xl font-black text-slate-900 dark:text-white tracking-tight max-w-4xl mx-auto leading-tight">
            DRUGAI<span className="text-teal-600 dark:text-teal-400">-LAB</span>
            <span className="block text-2xl sm:text-4xl font-extrabold text-slate-700 dark:text-slate-300 mt-2">
              AI-Powered Health Knowledge & Medicine Awareness
            </span>
          </h1>

          <p className="mt-5 text-base sm:text-lg text-slate-600 dark:text-slate-300 max-w-2xl mx-auto leading-relaxed">
            Explore trusted health information, understand medicines, learn about diseases, use AI-powered health education tools, and find emergency healthcare facilities near you.
          </p>

          {/* Universal Search Bar Trigger */}
          <div className="mt-8 max-w-2xl mx-auto">
            <div
              onClick={onOpenSearch}
              className="flex items-center w-full px-5 py-4 rounded-2xl bg-white dark:bg-slate-800 border-2 border-slate-200 dark:border-slate-700 shadow-xl hover:border-teal-500 dark:hover:border-teal-500 cursor-pointer transition-all group"
            >
              <Search className="w-5 h-5 text-teal-600 dark:text-teal-400 mr-3 group-hover:scale-110 transition-transform" />
              <span className="text-sm sm:text-base text-slate-400 font-medium">
                Search disease, medicine, symptom or health topic...
              </span>
              <kbd className="ml-auto hidden sm:inline-block px-2 py-1 text-xs font-mono bg-slate-100 dark:bg-slate-900 text-slate-500 rounded border border-slate-200 dark:border-slate-700">
                Press / to search
              </kbd>
            </div>
          </div>

          {/* Main Hero Buttons */}
          <div className="mt-8 flex flex-wrap items-center justify-center gap-3 sm:gap-4">
            <button
              onClick={() => onNavigate('medicines')}
              className="px-6 py-3 rounded-xl bg-teal-600 hover:bg-teal-700 text-white font-bold text-sm shadow-lg shadow-teal-600/20 transition-all hover:scale-[1.02]"
            >
              Explore Medicines
            </button>
            <button
              onClick={() => onNavigate('interactions')}
              className="px-6 py-3 rounded-xl bg-gradient-to-r from-teal-700 to-cyan-700 hover:from-teal-800 hover:to-cyan-800 text-white font-bold text-sm shadow-lg shadow-cyan-600/20 transition-all hover:scale-[1.02] flex items-center gap-2"
            >
              <Sparkles className="w-4 h-4 text-cyan-200" />
              Check Drug Interactions
            </button>
            <button
              onClick={() => onNavigate('ai-assistant')}
              className="px-6 py-3 rounded-xl bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-900 dark:text-white font-bold text-sm border border-slate-200 dark:border-slate-700 shadow-sm transition-all"
            >
              Ask AI Assistant
            </button>
            <button
              onClick={() => onNavigate('emergency-near-me')}
              className="px-6 py-3 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-sm shadow-lg shadow-red-600/20 transition-all hover:scale-[1.02] flex items-center gap-2"
            >
              <ShieldAlert className="w-4 h-4" />
              Emergency Near Me
            </button>
          </div>
        </div>
      </section>

      {/* 2. Prominent Emergency Notice Banner */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="p-4 sm:p-5 rounded-2xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-800 flex flex-col md:flex-row items-center justify-between gap-4 shadow-sm">
          <div className="flex items-center gap-3 text-red-900 dark:text-red-200 text-xs sm:text-sm">
            <AlertTriangle className="w-6 h-6 text-red-600 shrink-0" />
            <div>
              <p className="font-bold">Life-Threatening Emergency Notice:</p>
              <p className="text-red-700 dark:text-red-300 text-xs mt-0.5">
                “For life-threatening emergencies, contact your local emergency services or visit the nearest emergency department.”
              </p>
            </div>
          </div>
          <button
            onClick={onOpenEmergency}
            className="w-full md:w-auto px-5 py-2 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-bold whitespace-nowrap shadow-sm transition-colors"
          >
            Emergency Guidance & Helpline &rarr;
          </button>
        </div>
      </section>

      {/* 3. Quick Action Hubs Grid */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white">
              Clinical & AI Portals
            </h2>
            <p className="text-xs sm:text-sm text-slate-500">
              Tailored tools for patients, students, doctors, researchers, and public awareness.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {/* Card 1: Interaction Checker */}
          <div
            onClick={() => onNavigate('interactions')}
            className="p-5 rounded-2xl bg-gradient-to-br from-teal-50 to-white dark:from-slate-900 dark:to-slate-800 border border-teal-200 dark:border-teal-900/60 shadow-md hover:shadow-xl transition-all cursor-pointer group"
          >
            <div className="w-10 h-10 rounded-xl bg-teal-600 text-white flex items-center justify-center mb-3 group-hover:scale-105 transition-transform">
              <Pill className="w-5 h-5" />
            </div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-teal-600 dark:text-teal-400">
              AI CLINICAL TOOL
            </span>
            <h3 className="text-base font-bold text-slate-900 dark:text-white mt-1">
              Drug Interaction Checker
            </h3>
            <p className="text-xs text-slate-500 mt-1 line-clamp-2">
              Screen multi-drug combinations for severity, mechanisms, and precautions.
            </p>
          </div>

          {/* Card 2: AI Health Assistant */}
          <div
            onClick={() => onNavigate('ai-assistant')}
            className="p-5 rounded-2xl bg-gradient-to-br from-cyan-50 to-white dark:from-slate-900 dark:to-slate-800 border border-cyan-200 dark:border-cyan-900/60 shadow-md hover:shadow-xl transition-all cursor-pointer group"
          >
            <div className="w-10 h-10 rounded-xl bg-cyan-600 text-white flex items-center justify-center mb-3 group-hover:scale-105 transition-transform">
              <Bot className="w-5 h-5" />
            </div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-cyan-600 dark:text-cyan-400">
              CONVERSATIONAL AI
            </span>
            <h3 className="text-base font-bold text-slate-900 dark:text-white mt-1">
              DRUGAI Assistant
            </h3>
            <p className="text-xs text-slate-500 mt-1 line-clamp-2">
              Natural language answers, symptom guidance, and multi-language support.
            </p>
          </div>

          {/* Card 3: Voice Assistant */}
          <div
            onClick={() => onNavigate('ai-voice')}
            className="p-5 rounded-2xl bg-gradient-to-br from-indigo-50 to-white dark:from-slate-900 dark:to-slate-800 border border-indigo-200 dark:border-indigo-900/60 shadow-md hover:shadow-xl transition-all cursor-pointer group"
          >
            <div className="w-10 h-10 rounded-xl bg-indigo-600 text-white flex items-center justify-center mb-3 group-hover:scale-105 transition-transform">
              <Mic className="w-5 h-5" />
            </div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400">
              HANDS-FREE
            </span>
            <h3 className="text-base font-bold text-slate-900 dark:text-white mt-1">
              AI Voice Assistant
            </h3>
            <p className="text-xs text-slate-500 mt-1 line-clamp-2">
              Speech-to-text with spoken AI audio readout in multiple languages.
            </p>
          </div>

          {/* Card 4: Emergency Near Me */}
          <div
            onClick={() => onNavigate('emergency-near-me')}
            className="p-5 rounded-2xl bg-gradient-to-br from-red-50 to-white dark:from-slate-900 dark:to-slate-800 border border-red-200 dark:border-red-900/60 shadow-md hover:shadow-xl transition-all cursor-pointer group"
          >
            <div className="w-10 h-10 rounded-xl bg-red-600 text-white flex items-center justify-center mb-3 group-hover:scale-105 transition-transform">
              <MapPin className="w-5 h-5" />
            </div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-red-600 dark:text-red-400">
              GEOLOCATION ER
            </span>
            <h3 className="text-base font-bold text-slate-900 dark:text-white mt-1">
              Emergency Near Me
            </h3>
            <p className="text-xs text-slate-500 mt-1 line-clamp-2">
              Find 24/7 trauma hospitals, distance, phone numbers, and driving routes.
            </p>
          </div>
        </div>
      </section>

      {/* 4. Disease Database Highlights */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white">
              Disease Information Database
            </h2>
            <p className="text-xs sm:text-sm text-slate-500">
              Educational pathology, diagnostic testing protocols, and treatment approaches.
            </p>
          </div>
          <button
            onClick={() => onNavigate('diseases')}
            className="text-teal-600 dark:text-teal-400 text-xs font-bold hover:underline flex items-center gap-1"
          >
            View All Diseases ({DISEASES_DATA.length}) <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {DISEASES_DATA.slice(0, 3).map((d) => (
            <div
              key={d.id}
              onClick={() => onNavigate('disease-detail', d.id)}
              className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm hover:shadow-md transition-all cursor-pointer group"
            >
              <div className="flex items-center justify-between text-xs font-semibold text-teal-600 dark:text-teal-400 mb-2">
                <span>{d.category}</span>
                <span className="text-[10px] bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 px-2 py-0.5 rounded">
                  Clinical Entry
                </span>
              </div>
              <h3 className="text-lg font-bold text-slate-900 dark:text-white group-hover:text-teal-600 transition-colors">
                {d.name}
              </h3>
              <p className="text-xs text-slate-500 mt-2 line-clamp-3 leading-relaxed">
                {d.overview}
              </p>
              <div className="mt-4 pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs text-slate-500">
                <span>Symptoms: {d.commonSymptoms.length} documented</span>
                <span className="font-bold text-teal-600 group-hover:translate-x-1 transition-transform">
                  Read Guide &rarr;
                </span>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 5. Medicine Database Explorer Highlights */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white">
              Medicine Information Database
            </h2>
            <p className="text-xs sm:text-sm text-slate-500">
              Pharmacodynamics, common side effects, black-box warnings, and precautions.
            </p>
          </div>
          <button
            onClick={() => onNavigate('medicines')}
            className="text-teal-600 dark:text-teal-400 text-xs font-bold hover:underline flex items-center gap-1"
          >
            View All Medicines ({MEDICINES_DATA.length}) <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {MEDICINES_DATA.slice(0, 3).map((m) => (
            <div
              key={m.id}
              onClick={() => onNavigate('medicine-detail', m.id)}
              className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm hover:shadow-md transition-all cursor-pointer group"
            >
              <div className="flex items-center justify-between text-xs mb-2">
                <span className="text-teal-600 dark:text-teal-400 font-semibold">{m.category}</span>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                  {m.scheduleType}
                </span>
              </div>
              <h3 className="text-lg font-bold text-slate-900 dark:text-white group-hover:text-teal-600 transition-colors">
                {m.genericName}
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                Common Brands: {m.brandNames.slice(0, 3).join(', ')}
              </p>
              <p className="text-xs text-slate-600 dark:text-slate-300 mt-2 line-clamp-2 leading-relaxed">
                {m.howItWorks}
              </p>
              <div className="mt-4 pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs text-slate-500">
                <span className="text-amber-600 font-medium">Warnings: {m.importantWarnings.length}</span>
                <span className="font-bold text-teal-600 group-hover:translate-x-1 transition-transform">
                  View Drug Card &rarr;
                </span>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 6. Drug Awareness & Safety Center Showcase */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="p-8 rounded-3xl bg-gradient-to-r from-teal-900 via-slate-900 to-teal-950 text-white shadow-2xl relative overflow-hidden">
          <div className="max-w-2xl relative z-10">
            <span className="text-xs font-bold uppercase tracking-wider text-teal-400">
              PUBLIC SAFETY INITIATIVE
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold mt-1">
              Drug Awareness & Safe Medicine Center
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 mt-2 leading-relaxed">
              Combat antibiotic resistance, understand OTC vs prescription medications, prevent fatal drug interactions, and learn safe disposal methods to protect families and waterways.
            </p>
            <div className="mt-6 flex flex-wrap gap-3">
              <button
                onClick={() => onNavigate('awareness')}
                className="px-5 py-2.5 rounded-xl bg-teal-500 hover:bg-teal-600 text-slate-950 font-bold text-xs transition-colors"
              >
                Enter Drug Awareness Center &rarr;
              </button>
              <button
                onClick={() => onNavigate('categories')}
                className="px-5 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white font-semibold text-xs border border-white/20 transition-colors"
              >
                Medicine Categories Directory
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* 7. Student & Doctor Hub Callout */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Student Hub */}
          <div
            onClick={() => onNavigate('student-hub')}
            className="p-6 sm:p-8 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-lg hover:border-teal-500 cursor-pointer transition-all group"
          >
            <div className="w-12 h-12 rounded-2xl bg-teal-100 dark:bg-teal-950 text-teal-600 flex items-center justify-center mb-4 group-hover:scale-105 transition-transform">
              <BookOpen className="w-6 h-6" />
            </div>
            <span className="text-[11px] font-bold uppercase tracking-wider text-teal-600 dark:text-teal-400">
              ACADEMIC LEARNING
            </span>
            <h3 className="text-xl font-extrabold text-slate-900 dark:text-white mt-1">
              Student Learning Hub
            </h3>
            <p className="text-xs sm:text-sm text-slate-500 mt-2 leading-relaxed">
              Designed for medical, nursing, and pharmacy students. Interactive pharmacology quizzes, flashcards, case-based clinical scenarios, and our <strong>“Explain Like I’m a Beginner”</strong> mode.
            </p>
            <div className="mt-4 text-xs font-bold text-teal-600 flex items-center gap-1 group-hover:translate-x-1 transition-transform">
              Explore Quizzes & Study Cards &rarr;
            </div>
          </div>

          {/* Doctor Hub */}
          <div
            onClick={() => onNavigate('doctor-hub')}
            className="p-6 sm:p-8 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-lg hover:border-teal-500 cursor-pointer transition-all group"
          >
            <div className="w-12 h-12 rounded-2xl bg-indigo-100 dark:bg-indigo-950 text-indigo-600 flex items-center justify-center mb-4 group-hover:scale-105 transition-transform">
              <Stethoscope className="w-6 h-6" />
            </div>
            <span className="text-[11px] font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400">
              VERIFIED PRACTITIONERS
            </span>
            <h3 className="text-xl font-extrabold text-slate-900 dark:text-white mt-1">
              Doctor & Clinician Hub
            </h3>
            <p className="text-xs sm:text-sm text-slate-500 mt-2 leading-relaxed">
              Clinical knowledge tools, high-density interaction cross-referencing, research trial indexes, and clinician verification badges.
            </p>
            <div className="mt-4 text-xs font-bold text-indigo-600 flex items-center gap-1 group-hover:translate-x-1 transition-transform">
              Open Doctor Portal &rarr;
            </div>
          </div>
        </div>
      </section>

      {/* 8. Latest Health Awareness Articles */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white">
              Health Awareness & Education
            </h2>
            <p className="text-xs sm:text-sm text-slate-500">
              Evidence-based articles on disease prevention, medicine safety, and healthy living.
            </p>
          </div>
          <button
            onClick={() => onNavigate('articles')}
            className="text-teal-600 dark:text-teal-400 text-xs font-bold hover:underline flex items-center gap-1"
          >
            All Articles &rarr;
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {HEALTH_ARTICLES.slice(0, 2).map((a) => (
            <div
              key={a.id}
              onClick={() => onNavigate('article-detail', a.id)}
              className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm hover:shadow-md transition-all cursor-pointer group"
            >
              <div className="flex items-center gap-2 text-xs font-semibold text-teal-600 dark:text-teal-400 mb-2">
                <span>{a.category}</span>
                <span>•</span>
                <span>{a.readTime}</span>
              </div>
              <h3 className="text-lg font-bold text-slate-900 dark:text-white group-hover:text-teal-600 transition-colors">
                {a.title}
              </h3>
              <p className="text-xs text-slate-500 mt-2 line-clamp-2 leading-relaxed">
                {a.summary}
              </p>
              <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs text-slate-400">
                <span>By {a.organization}</span>
                <span className="font-semibold text-teal-600">Read Article &rarr;</span>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};
