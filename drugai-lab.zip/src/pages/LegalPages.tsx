import React from 'react';
import { ShieldAlert, ShieldCheck, Mail, Globe, MapPin, HeartPulse } from 'lucide-react';

export const MedicalDisclaimerPage: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10 animate-fade-in pb-16 space-y-6">
      <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-red-50 dark:bg-red-950 text-red-700 dark:text-red-300 text-xs font-bold">
        <ShieldAlert className="w-4 h-4" />
        <span>Clinical & Regulatory Compliance</span>
      </div>
      <h1 className="text-3xl font-extrabold text-slate-900 dark:text-white">
        Official Medical & Legal Disclaimer
      </h1>

      <div className="p-6 rounded-3xl bg-red-50/80 dark:bg-red-950/40 border-2 border-red-300 dark:border-red-800 text-red-950 dark:text-red-200 text-sm sm:text-base leading-relaxed font-semibold">
        “DRUGAI-LAB provides general health and medicine information for educational purposes only. The information provided by this website and its AI assistants is not a diagnosis, prescription, or substitute for professional medical advice. Always consult a qualified healthcare professional for personal medical decisions. In an emergency, contact local emergency services or seek immediate medical care.”
      </div>

      <div className="space-y-4 text-xs sm:text-sm text-slate-700 dark:text-slate-300 leading-relaxed">
        <h2 className="text-base font-bold text-slate-900 dark:text-white">1. Nature of the Service</h2>
        <p>
          DRUGAI-LAB is designed exclusively as an educational and information-retrieval platform. Our AI models, algorithms, drug interaction tools, and disease guides synthesize medical information published by reputable public health institutions. They are not licensed clinicians and possess no clinical authority.
        </p>

        <h2 className="text-base font-bold text-slate-900 dark:text-white">2. No Doctor-Patient Relationship</h2>
        <p>
          Interacting with DRUGAI-LAB, its AI conversational assistants, or using its interactive drug interaction checker does not establish a doctor-patient, pharmacist-patient, or fiduciary relationship of any kind.
        </p>

        <h2 className="text-base font-bold text-slate-900 dark:text-white">3. Individual Patient Variability</h2>
        <p>
          Pharmacological responses vary widely depending on genetic polymorphisms, renal creatinine clearance, hepatic enzymes, age, pregnancy status, and concomitant drug therapies. Never alter, discontinue, or initiate any drug dosage without direct oversight from your physician or pharmacist.
        </p>

        <h2 className="text-base font-bold text-slate-900 dark:text-white">4. Acute Medical Emergencies</h2>
        <p>
          Do not rely on this website for acute, traumatic, or life-threatening symptoms (including but not limited to severe chest pain, shortness of breath, sudden neurological numbness, or suicidal ideation). Immediately summon local emergency medical services (such as 911, 112, 108, or 999).
        </p>
      </div>
    </div>
  );
};

export const PrivacyPolicyPage: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10 animate-fade-in pb-16 space-y-6">
      <h1 className="text-3xl font-extrabold text-slate-900 dark:text-white">Privacy Policy</h1>
      <p className="text-xs text-slate-500">Effective Date: October 2026</p>

      <div className="space-y-4 text-xs sm:text-sm text-slate-700 dark:text-slate-300 leading-relaxed">
        <p>
          At <strong>DRUGAI-LAB</strong>, your privacy and health confidentiality are fundamental priorities. We adhere to the principle of data minimization:
        </p>
        <ul className="list-disc pl-5 space-y-2">
          <li><strong>No Collection of Sensitive Personal Health Records:</strong> We do not ask for or store unnecessary sensitive personal health information, government IDs, or private health records.</li>
          <li><strong>Ephemeral Geolocation:</strong> Browser location permissions requested in the "Emergency Near Me" tool are used transiently inside your local browser session to calculate hospital distances. We never permanently record or track your exact coordinates.</li>
          <li><strong>AI Query Privacy:</strong> Search queries and conversational interactions with our health assistants are utilized solely to generate educational responses and are never sold to third-party data brokers.</li>
          <li><strong>Account Control:</strong> Users may export or clear their recent search history and bookmarks at any time through their personal dashboard.</li>
        </ul>
      </div>
    </div>
  );
};

export const TermsOfUsePage: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10 animate-fade-in pb-16 space-y-6">
      <h1 className="text-3xl font-extrabold text-slate-900 dark:text-white">Terms of Use</h1>
      <p className="text-xs text-slate-500">Effective Date: October 2026</p>

      <div className="space-y-4 text-xs sm:text-sm text-slate-700 dark:text-slate-300 leading-relaxed">
        <p>
          By accessing or utilizing DRUGAI-LAB, you agree to comply with our Terms of Use.
        </p>
        <ul className="list-disc pl-5 space-y-2">
          <li>You acknowledge that content is for educational purposes only.</li>
          <li>You agree not to impersonate licensed healthcare professionals or bypass clinician verification credentials.</li>
          <li>You understand that information provided by AI tools must be verified by certified healthcare professionals before taking any clinical action.</li>
        </ul>
      </div>
    </div>
  );
};

export const AboutPage: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10 animate-fade-in pb-16 space-y-6">
      <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-teal-50 dark:bg-teal-950 text-teal-700 dark:text-teal-300 text-xs font-bold">
        <HeartPulse className="w-4 h-4" />
        <span>About the Platform</span>
      </div>
      <h1 className="text-3xl font-extrabold text-slate-900 dark:text-white">About DRUGAI-LAB</h1>
      <p className="text-sm sm:text-base text-slate-600 dark:text-slate-300 leading-relaxed">
        <strong>DRUGAI-LAB</strong> is an evidence-based healthcare technology platform designed to bridge the gap between complex pharmacological science and everyday public understanding. Built for students, patients, doctors, researchers, and the general public, the platform provides verified medical education, multi-drug interaction checking, and life-saving emergency hospital routing.
      </p>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-4">
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
          <h3 className="font-bold text-sm text-slate-900 dark:text-white">Evidence-Based</h3>
          <p className="text-xs text-slate-500 mt-1">Grounding knowledge in WHO, FDA, CDC, and peer-reviewed journals.</p>
        </div>
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
          <h3 className="font-bold text-sm text-slate-900 dark:text-white">11 Languages</h3>
          <p className="text-xs text-slate-500 mt-1">Universal accessibility across major global and regional languages.</p>
        </div>
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
          <h3 className="font-bold text-sm text-slate-900 dark:text-white">Safety-First AI</h3>
          <p className="text-xs text-slate-500 mt-1">Strict guardrails preventing non-clinical prescriptions or false diagnoses.</p>
        </div>
      </div>
    </div>
  );
};

export const ContactPage: React.FC = () => {
  return (
    <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-10 animate-fade-in pb-16 space-y-6">
      <h1 className="text-3xl font-extrabold text-slate-900 dark:text-white">Contact DRUGAI-LAB</h1>
      <p className="text-xs sm:text-sm text-slate-500">
        Have questions regarding our clinical educational databases, institutional partnerships, or verified clinician accounts? Get in touch with our team.
      </p>

      <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-4 text-xs sm:text-sm">
        <div className="flex items-center gap-3">
          <Mail className="w-5 h-5 text-teal-600" />
          <span>contact@drugai-lab.health</span>
        </div>
        <div className="flex items-center gap-3">
          <Globe className="w-5 h-5 text-teal-600" />
          <span>https://drugai-lab.health</span>
        </div>
        <div className="flex items-center gap-3">
          <MapPin className="w-5 h-5 text-teal-600" />
          <span>Global Clinical Intelligence Network</span>
        </div>
      </div>
    </div>
  );
};
