import React from 'react';
import { Pill, AlertTriangle, ShieldCheck, HeartPulse, Eye, Sparkles } from 'lucide-react';

interface MedicineCategoriesProps {
  onSelectCategory?: (category: string) => void;
}

const CATEGORIES_DATA = [
  {
    name: 'Pain Relief (Analgesics)',
    examples: ['Paracetamol / Acetaminophen', 'Ibuprofen', 'Naproxen', 'Celecoxib'],
    commonPurposes: 'Alleviating acute headache, dental pain, musculoskeletal strain, and postoperative discomfort.',
    safetyConsideration:
      'Never assume pain medicines are harmless. NSAIDs can precipitate gastrointestinal ulceration and renal strain, while acetaminophen in excessive doses causes liver necrosis.',
  },
  {
    name: 'Fever Reduction (Antipyretics)',
    examples: ['Paracetamol', 'Ibuprofen'],
    commonPurposes: 'Lowering elevated body temperature and alleviating associated malaise.',
    safetyConsideration:
      'Fever is a natural physiological defense mechanism against infection. In suspected viral illnesses like dengue, aspirin and NSAIDs must be strictly avoided due to severe hemorrhage hazards.',
  },
  {
    name: 'Allergy & Antihistamines',
    examples: ['Cetirizine', 'Loratadine', 'Fexofenadine', 'Diphenhydramine'],
    commonPurposes: 'Relieving allergic rhinitis (hay fever), hives (urticaria), itching, and watery eyes.',
    safetyConsideration:
      'First-generation antihistamines (like diphenhydramine) cause significant drowsiness and psychomotor impairment. Do not drive or operate machinery.',
  },
  {
    name: 'Infection-Related Medicines (Antimicrobials)',
    examples: ['Amoxicillin', 'Azithromycin', 'Ciprofloxacin', 'Cephalexin'],
    commonPurposes: 'Eradicating confirmed bacterial pathogens causing respiratory, urinary, or skin infections.',
    safetyConsideration:
      'Antibiotics are completely ineffective against viral colds and flu. Misuse fuels life-threatening multi-drug resistant superbugs. Always complete prescribed courses.',
  },
  {
    name: 'Blood Pressure Medicines (Antihypertensives)',
    examples: ['Lisinopril (ACEI)', 'Losartan (ARB)', 'Amlodipine (CCB)', 'Metoprolol (Beta-blocker)'],
    commonPurposes: 'Lowering systemic arterial resistance to prevent stroke, myocardial infarction, and kidney failure.',
    safetyConsideration:
      'Abrupt discontinuation can cause dangerous rebound hypertension. Regular kidney function and potassium monitoring are essential.',
  },
  {
    name: 'Diabetes Medicines (Antidiabetics & Insulins)',
    examples: ['Metformin', 'Empagliflozin (SGLT2i)', 'Semaglutide (GLP-1 RA)', 'Gargine Insulin'],
    commonPurposes: 'Managing hyperglycemia and reducing microvascular and macrovascular complications.',
    safetyConsideration:
      'Sulfonylureas and insulins can induce acute hypoglycemia (low blood sugar). Patients must recognize early shakiness, sweating, and confusion.',
  },
  {
    name: 'Asthma & Respiratory Inhalers',
    examples: ['Albuterol / Salbutamol', 'Budesonide', 'Fluticasone', 'Montelukast'],
    commonPurposes: 'Bronchodilation for acute airflow obstruction and daily steroid maintenance to reduce airway inflammation.',
    safetyConsideration:
      'Over-reliance on rescue inhalers without daily anti-inflammatory controllers signifies poorly controlled asthma requiring urgent clinical review.',
  },
  {
    name: 'Gastrointestinal Medicines',
    examples: ['Omeprazole (PPI)', 'Famotidine (H2 blocker)', 'Antacids', 'Ondansetron'],
    commonPurposes: 'Suppression of gastric acid secretion in GERD, peptic ulcers, and nausea management.',
    safetyConsideration:
      'Prolonged unmonitored PPI use may reduce magnesium and Vitamin B12 absorption. Severe chest pain must never be assumed to be simple acid reflux.',
  },
  {
    name: 'Vitamins & Mineral Supplements',
    examples: ['Vitamin D3', 'Vitamin B12', 'Ferrous Sulfate (Iron)', 'Calcium Carbonate'],
    commonPurposes: 'Correcting clinical nutritional deficiencies and supporting bone density or hematopoiesis.',
    safetyConsideration:
      'Fat-soluble vitamins (A, D, E, K) accumulate in adipose tissue and liver, posing hypervitaminosis toxicity risks with excessive intake. Iron supplements can bind and block antibiotic absorption.',
  },
  {
    name: 'Dermatological / Skin Medicines',
    examples: ['Hydrocortisone', 'Mupirocin', 'Clotrimazole', 'Benzoyl Peroxide'],
    commonPurposes: 'Topical treatment of eczema, fungal tinea, minor bacterial infections, and acne vulgaris.',
    safetyConsideration:
      'Long-term potent topical steroid use leads to skin atrophy and systemic absorption. Topical antibiotics should not be used on non-bacterial lesions.',
  },
  {
    name: 'Ophthalmic / Eye Medicines',
    examples: ['Artificial tears', 'Olopatadine eye drops', 'Ciprofloxacin eye drops', 'Latanoprost'],
    commonPurposes: 'Ocular lubrication, allergic conjunctivitis relief, and lowering intraocular pressure in glaucoma.',
    safetyConsideration:
      'Maintain strict sterility of dropper tips. Eye pain, sudden vision changes, or halos require immediate ophthalmological evaluation.',
  },
  {
    name: 'Emergency Medicine Awareness',
    examples: ['Epinephrine auto-injector (EpiPen)', 'Naloxone (Narcan)', 'Sublingual Nitroglycerin'],
    commonPurposes: 'Life-saving immediate rescue interventions for anaphylaxis, opioid overdose, or acute angina.',
    safetyConsideration:
      'Emergency rescue medications are temporizing measures. Always activate emergency medical services (911 / 112 / 108) immediately upon administration.',
  },
];

export const MedicineCategories: React.FC<MedicineCategoriesProps> = () => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 animate-fade-in pb-16 space-y-8">
      {/* Header */}
      <div>
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-teal-50 dark:bg-teal-950 text-teal-700 dark:text-teal-300 text-xs font-bold mb-2">
          <Pill className="w-3.5 h-3.5" />
          <span>Therapeutic Classification Directory</span>
        </div>
        <h1 className="text-3xl font-extrabold text-slate-900 dark:text-white">
          Medicine Categories & Their Common Uses
        </h1>
        <p className="text-sm text-slate-500 mt-1">
          A structured medical education directory covering therapeutic classes, common indications, and clinical caveats.
        </p>

        {/* Crucial Individual Suitability Notice */}
        <div className="mt-4 p-4 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 text-amber-950 dark:text-amber-200 text-xs flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
          <div>
            <strong>Strict Pharmacological Rule:</strong> No medicine is universally "good" or "safe" for all individuals. Every medication possesses specific indications, contraindications, and potential adverse risks. Suitability depends entirely on an individual’s medical profile, organ function, existing medications, and professional clinical evaluation.
          </div>
        </div>
      </div>

      {/* Grid of 12 Categories */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {CATEGORIES_DATA.map((cat, idx) => (
          <div
            key={idx}
            className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center gap-2 mb-2">
                <span className="text-xs font-bold text-teal-600 dark:text-teal-400 bg-teal-50 dark:bg-teal-950 px-2 py-0.5 rounded">
                  Class #{idx + 1}
                </span>
              </div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white mb-2">
                {cat.name}
              </h3>
              <p className="text-xs text-slate-500 mb-3">
                <strong>Key Examples:</strong> {cat.examples.join(', ')}
              </p>
              <div className="space-y-2 text-xs">
                <div>
                  <p className="font-semibold text-slate-700 dark:text-slate-300">Common Clinical Purposes:</p>
                  <p className="text-slate-600 dark:text-slate-400 leading-relaxed">{cat.commonPurposes}</p>
                </div>
                <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
                  <p className="font-bold text-amber-700 dark:text-amber-300 text-[11px] flex items-center gap-1 mb-1">
                    <ShieldCheck className="w-3.5 h-3.5" /> Clinical Safety Caveat:
                  </p>
                  <p className="text-slate-600 dark:text-slate-300 text-[11px] leading-relaxed">
                    {cat.safetyConsideration}
                  </p>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
