import React from 'react';
import {
  ArrowLeft,
  Bookmark,
  Share2,
  AlertTriangle,
  ShieldAlert,
  ShieldCheck,
  Pill,
  Sparkles,
  Info,
  Clock,
  HeartPulse,
} from 'lucide-react';
import { MEDICINES_DATA } from '../data/mockData';
import { useAuth } from '../context/AuthContext';

interface MedicineDetailProps {
  medicineId: string;
  onBack: () => void;
  onCheckInteractionsWith: (medName: string) => void;
}

export const MedicineDetail: React.FC<MedicineDetailProps> = ({
  medicineId,
  onBack,
  onCheckInteractionsWith,
}) => {
  const { toggleBookmark, isBookmarked } = useAuth();
  const medicine = MEDICINES_DATA.find((m) => m.id === medicineId) || MEDICINES_DATA[0];

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-10 animate-fade-in pb-16">
      {/* Top Bar */}
      <div className="flex items-center justify-between mb-6">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-xs font-semibold text-slate-500 hover:text-teal-600 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" /> Back to Medicine Explorer
        </button>
        <div className="flex items-center gap-2">
          <button
            onClick={() => onCheckInteractionsWith(medicine.genericName)}
            className="px-3 py-1.5 rounded-lg bg-teal-600 hover:bg-teal-700 text-white text-xs font-semibold flex items-center gap-1.5 shadow-sm transition-colors"
          >
            <Sparkles className="w-3.5 h-3.5" /> Check Interactions
          </button>
          <button
            onClick={() => toggleBookmark(medicine.id, 'medicine', medicine.genericName)}
            className={`px-3 py-1.5 rounded-lg border text-xs font-semibold flex items-center gap-1.5 transition-colors ${
              isBookmarked(medicine.id)
                ? 'bg-teal-50 dark:bg-teal-950 border-teal-300 text-teal-600'
                : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-100'
            }`}
          >
            <Bookmark className="w-3.5 h-3.5" />
            {isBookmarked(medicine.id) ? 'Saved' : 'Bookmark'}
          </button>
        </div>
      </div>

      {/* Main Medicine Card */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-8 shadow-sm mb-8">
        <div className="flex items-center gap-2 mb-3">
          <span className="text-xs font-bold uppercase tracking-wider text-teal-600 dark:text-teal-400 bg-teal-50 dark:bg-teal-950 px-2.5 py-1 rounded-md">
            {medicine.category}
          </span>
          <span className="text-xs font-bold px-2 py-1 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
            {medicine.scheduleType}
          </span>
        </div>
        <h1 className="text-2xl sm:text-4xl font-extrabold text-slate-900 dark:text-white">
          {medicine.genericName}
        </h1>
        <p className="text-xs sm:text-sm text-slate-500 mt-1">
          <strong>Common Brand Names:</strong> {medicine.brandNames.join(', ')}
        </p>

        {/* Mandatory Dosage Disclaimer */}
        <div className="mt-6 p-4 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 text-amber-900 dark:text-amber-200 text-xs flex items-center gap-3">
          <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0" />
          <div>
            <strong>Dosage & Prescription Notice:</strong> Dosage and suitability depend on the individual; consult a qualified healthcare professional and follow the official label/prescription. Do not self-prescribe or adjust doses without medical oversight.
          </div>
        </div>
      </div>

      {/* Mechanism & General Uses */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
        {/* How it works */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm">
          <h3 className="text-sm font-bold uppercase tracking-wider text-slate-900 dark:text-white mb-3 flex items-center gap-2">
            <Info className="w-4 h-4 text-teal-600" /> How It Works (Mechanism of Action)
          </h3>
          <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
            {medicine.howItWorks}
          </p>
        </div>

        {/* General uses */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm">
          <h3 className="text-sm font-bold uppercase tracking-wider text-slate-900 dark:text-white mb-3 flex items-center gap-2">
            <Pill className="w-4 h-4 text-teal-600" /> General Clinical Uses
          </h3>
          <ul className="space-y-2 text-xs text-slate-600 dark:text-slate-300">
            {medicine.generalUses.map((use, i) => (
              <li key={i} className="flex items-start gap-2">
                <span className="text-teal-600 font-bold">•</span>
                <span>{use}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* Warnings & Side Effects */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
        {/* Important Warnings */}
        <div className="bg-red-50/60 dark:bg-red-950/20 border border-red-200 dark:border-red-900/60 rounded-2xl p-6 shadow-sm">
          <h3 className="text-sm font-bold uppercase tracking-wider text-red-900 dark:text-red-200 mb-3 flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 text-red-600" /> Important Warnings & Safety Cautions
          </h3>
          <ul className="space-y-2 text-xs text-red-950 dark:text-red-200">
            {medicine.importantWarnings.map((warn, i) => (
              <li key={i} className="flex items-start gap-2">
                <span className="text-red-600 font-bold">•</span>
                <span>{warn}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Common Side Effects */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm">
          <h3 className="text-sm font-bold uppercase tracking-wider text-slate-900 dark:text-white mb-3 flex items-center gap-2">
            <HeartPulse className="w-4 h-4 text-amber-500" /> Common Side Effects
          </h3>
          <ul className="space-y-2 text-xs text-slate-600 dark:text-slate-300">
            {medicine.commonSideEffects.map((side, i) => (
              <li key={i} className="flex items-start gap-2">
                <span className="text-amber-500 font-bold">•</span>
                <span>{side}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* Interactions & Contraindications */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
        {/* Interactions */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm">
          <h3 className="text-sm font-bold uppercase tracking-wider text-slate-900 dark:text-white mb-3 flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-teal-600" /> Key Drug Interactions
          </h3>
          <ul className="space-y-2 text-xs text-slate-600 dark:text-slate-300">
            {medicine.commonInteractions.map((inter, i) => (
              <li key={i} className="flex items-start gap-2">
                <span className="text-teal-600 font-bold">•</span>
                <span>{inter}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Contraindications */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm">
          <h3 className="text-sm font-bold uppercase tracking-wider text-slate-900 dark:text-white mb-3 flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-red-500" /> Contraindications
          </h3>
          <ul className="space-y-2 text-xs text-slate-600 dark:text-slate-300">
            {medicine.contraindications.map((contra, i) => (
              <li key={i} className="flex items-start gap-2">
                <span className="text-red-500 font-bold">•</span>
                <span>{contra}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* Pregnancy, Age & Storage Safety */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm mb-8 space-y-4 text-xs">
        <h3 className="text-sm font-bold uppercase tracking-wider text-slate-900 dark:text-white">
          Special Population & Storage Guidelines
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
            <h4 className="font-bold text-slate-700 dark:text-slate-300 mb-1">Pregnancy & Lactation:</h4>
            <p className="text-slate-600 dark:text-slate-400">{medicine.pregnancyWarning}</p>
          </div>
          <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
            <h4 className="font-bold text-slate-700 dark:text-slate-300 mb-1">Age Safety Warnings:</h4>
            <p className="text-slate-600 dark:text-slate-400">{medicine.ageSafetyWarning}</p>
          </div>
          <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
            <h4 className="font-bold text-slate-700 dark:text-slate-300 mb-1">Proper Storage:</h4>
            <p className="text-slate-600 dark:text-slate-400">{medicine.storageInfo}</p>
          </div>
        </div>
      </div>

      {/* When Professional Advice is Necessary */}
      <div className="p-6 rounded-2xl bg-teal-50/60 dark:bg-teal-950/20 border border-teal-200 dark:border-teal-800/60 text-xs">
        <h4 className="font-bold uppercase tracking-wider text-teal-900 dark:text-teal-200 mb-2">
          When Professional Medical Advice is Strictly Necessary:
        </h4>
        <ul className="space-y-1.5 text-teal-950 dark:text-teal-200">
          {medicine.whenProfessionalAdviceNecessary.map((item, idx) => (
            <li key={idx} className="flex items-start gap-2">
              <span className="text-teal-600 font-bold">•</span>
              <span>{item}</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};
