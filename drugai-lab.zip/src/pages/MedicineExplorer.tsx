import React, { useState, useMemo } from 'react';
import { Pill, Search, Bookmark, Filter, ShieldCheck, AlertTriangle } from 'lucide-react';
import { MEDICINES_DATA } from '../data/mockData';
import { useAuth } from '../context/AuthContext';

interface MedicineExplorerProps {
  onSelectMedicine: (id: string) => void;
  onCheckInteraction: (medicineName: string) => void;
}

export const MedicineExplorer: React.FC<MedicineExplorerProps> = ({
  onSelectMedicine,
  onCheckInteraction,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [scheduleFilter, setScheduleFilter] = useState<string>('All');
  const { toggleBookmark, isBookmarked } = useAuth();

  const filteredMedicines = useMemo(() => {
    return MEDICINES_DATA.filter((m) => {
      const matchesSearch =
        m.genericName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        m.brandNames.some((b) => b.toLowerCase().includes(searchTerm.toLowerCase())) ||
        m.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
        m.generalUses.some((u) => u.toLowerCase().includes(searchTerm.toLowerCase()));

      const matchesSchedule = scheduleFilter === 'All' || m.scheduleType === scheduleFilter;

      return matchesSearch && matchesSchedule;
    });
  }, [searchTerm, scheduleFilter]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 animate-fade-in">
      {/* Header */}
      <div className="mb-8">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-teal-50 dark:bg-teal-950 text-teal-700 dark:text-teal-300 text-xs font-bold mb-2">
          <Pill className="w-3.5 h-3.5" />
          <span>Pharmacopeia & Drug Intelligence</span>
        </div>
        <h1 className="text-3xl font-extrabold text-slate-900 dark:text-white">
          Medicine Information Database
        </h1>
        <p className="text-sm text-slate-500 mt-1">
          Explore evidence-based drug profiles, active ingredients, mechanisms of action, and critical contraindications.
        </p>

        {/* Mandatory Prescribing Disclaimer */}
        <div className="mt-4 p-3.5 rounded-xl bg-slate-100 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-xs text-slate-600 dark:text-slate-300 flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-teal-600 shrink-0" />
          <span>
            <strong>Prescription & Dosage Guidance:</strong> Dosage and suitability depend on the individual; consult a qualified healthcare professional and follow the official label/prescription. DRUGAI-LAB never generates personalized prescriptions.
          </span>
        </div>
      </div>

      {/* Controls */}
      <div className="flex flex-col md:flex-row gap-3 mb-8">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search generic name, brand (e.g. Tylenol, Lipitor, Glucophage)..."
            className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-teal-500"
          />
        </div>
        <div className="flex items-center gap-1.5">
          {['All', 'OTC', 'Prescription'].map((sch) => (
            <button
              key={sch}
              onClick={() => setScheduleFilter(sch)}
              className={`px-3 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors ${
                scheduleFilter === sch
                  ? 'bg-teal-600 text-white'
                  : 'bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700'
              }`}
            >
              {sch} Medicines
            </button>
          ))}
        </div>
      </div>

      {/* Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredMedicines.map((m) => (
          <div
            key={m.id}
            className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm hover:shadow-md transition-all flex flex-col justify-between group"
          >
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-semibold text-teal-600 dark:text-teal-400">
                  {m.category}
                </span>
                <div className="flex items-center gap-1.5">
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                    {m.scheduleType}
                  </span>
                  <button
                    onClick={() => toggleBookmark(m.id, 'medicine', m.genericName)}
                    className={`p-1.5 rounded-lg border text-xs transition-colors ${
                      isBookmarked(m.id)
                        ? 'bg-teal-50 dark:bg-teal-950 border-teal-300 text-teal-600'
                        : 'border-slate-200 dark:border-slate-700 text-slate-400 hover:text-slate-600'
                    }`}
                    title="Bookmark medicine"
                  >
                    <Bookmark className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              <h3
                onClick={() => onSelectMedicine(m.id)}
                className="text-lg font-bold text-slate-900 dark:text-white group-hover:text-teal-600 cursor-pointer transition-colors"
              >
                {m.genericName}
              </h3>
              <p className="text-[11px] text-slate-400 mb-2">
                Brands: {m.brandNames.slice(0, 3).join(', ')}
              </p>

              <p className="text-xs text-slate-600 dark:text-slate-300 line-clamp-3 leading-relaxed mb-4">
                {m.howItWorks}
              </p>

              <div className="space-y-1.5 mb-4 text-xs text-slate-500">
                <p className="line-clamp-1">
                  <strong>Indications:</strong> {m.generalUses.slice(0, 2).join(' • ')}
                </p>
                <p className="line-clamp-1 text-red-600/90 dark:text-red-400 font-medium">
                  <strong>Key Warning:</strong> {m.importantWarnings[0]}
                </p>
              </div>
            </div>

            <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
              <button
                onClick={() => onCheckInteraction(m.genericName)}
                className="text-[11px] text-slate-500 hover:text-teal-600 font-semibold flex items-center gap-1"
              >
                Check Interactions
              </button>
              <button
                onClick={() => onSelectMedicine(m.id)}
                className="text-xs font-bold text-teal-600 hover:text-teal-700 flex items-center gap-1 group-hover:translate-x-1 transition-transform"
              >
                Full Monograph &rarr;
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
