import React from 'react';
import { BookOpen, ExternalLink, ShieldCheck, CheckCircle2 } from 'lucide-react';

const SOURCES_LIST = [
  {
    organization: 'World Health Organization (WHO)',
    description: 'International public health agency of the United Nations setting clinical guidelines, essential medicines lists (EML), and antimicrobial stewardship frameworks.',
    url: 'https://www.who.int',
  },
  {
    organization: 'U.S. Food and Drug Administration (FDA)',
    description: 'Federal agency regulating pharmaceutical efficacy, safety label changes, black-box warnings, and post-market pharmacovigilance reports.',
    url: 'https://www.fda.gov',
  },
  {
    organization: 'Centers for Disease Control and Prevention (CDC)',
    description: 'National public health institute providing evidence-based epidemiology, infectious disease surveillance, and immunization standards.',
    url: 'https://www.cdc.gov',
  },
  {
    organization: 'National Health Service (NHS) Medicines Guidance',
    description: 'United Kingdom health authority providing patient information leaflets, drug interactions, and dosage safety protocols.',
    url: 'https://www.nhs.uk/medicines',
  },
  {
    organization: 'MedlinePlus (National Library of Medicine / NIH)',
    description: 'Comprehensive, trusted consumer health service produced by the U.S. National Library of Medicine.',
    url: 'https://medlineplus.gov',
  },
  {
    organization: 'Global Initiative for Asthma (GINA)',
    description: 'International collaborative program creating evidence-based global clinical guidelines for bronchial asthma diagnosis and management.',
    url: 'https://ginasthma.org',
  },
  {
    organization: 'American Diabetes Association (ADA)',
    description: 'Leading international professional organization defining annual Standards of Care in Type 1, Type 2, and Gestational Diabetes.',
    url: 'https://diabetes.org',
  },
  {
    organization: 'American Heart Association (AHA / ACC)',
    description: 'Cardiovascular clinical societies providing consensus guidelines for hypertension, dyslipidemia, coronary syndromes, and stroke protocols.',
    url: 'https://heart.org',
  },
];

export const SourcesAndReferences: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10 animate-fade-in pb-16 space-y-8">
      <div>
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-teal-50 dark:bg-teal-950 text-teal-700 dark:text-teal-300 text-xs font-bold mb-2">
          <BookOpen className="w-3.5 h-3.5" />
          <span>Clinical Citations & Source Governance</span>
        </div>
        <h1 className="text-3xl font-extrabold text-slate-900 dark:text-white">
          Medical Sources & Evidence References
        </h1>
        <p className="text-sm text-slate-500 mt-1">
          DRUGAI-LAB grounds all disease profiles, drug information, and AI assistant instructions in recognized international clinical institutions.
        </p>
      </div>

      <div className="p-4 rounded-2xl bg-teal-50/70 dark:bg-teal-950/40 border border-teal-200 dark:border-teal-800 text-teal-950 dark:text-teal-200 text-xs flex items-center gap-2">
        <ShieldCheck className="w-4 h-4 text-teal-600 shrink-0" />
        <span>
          <strong>Anti-Fabrication Principle:</strong> DRUGAI-LAB strictly forbids inventing clinical studies or imaginary medical citations. All references represent accredited bodies.
        </span>
      </div>

      <div className="space-y-4">
        {SOURCES_LIST.map((src, idx) => (
          <div
            key={idx}
            className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4"
          >
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                {src.organization}
              </h3>
              <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                {src.description}
              </p>
            </div>
            <a
              href={src.url}
              target="_blank"
              rel="noopener noreferrer"
              className="px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-teal-50 dark:hover:bg-teal-950 text-slate-700 dark:text-slate-200 hover:text-teal-600 text-xs font-bold whitespace-nowrap flex items-center gap-1.5 transition-colors self-start sm:self-auto"
            >
              Official Portal <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>
        ))}
      </div>
    </div>
  );
};
