import React, { useState } from 'react';
import {
  BookOpen,
  Sparkles,
  Award,
  CheckCircle2,
  XCircle,
  HelpCircle,
  ChevronRight,
  RotateCcw,
  Pill,
  Activity,
  Layers,
  Send,
  GraduationCap,
} from 'lucide-react';
import { STUDENT_QUIZZES, MEDICAL_TERMS, MEDICINES_DATA } from '../data/mockData';
import { useLanguage } from '../context/LanguageContext';

export const StudentHub: React.FC = () => {
  const { language } = useLanguage();
  const [activeTab, setActiveTab] = useState<'quiz' | 'flashcards' | 'terms' | 'beginner-ai'>('quiz');

  // Quiz state
  const [currentQuizIdx, setCurrentQuizIdx] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showExplanation, setShowExplanation] = useState(false);
  const [score, setScore] = useState(0);
  const [quizCompleted, setQuizCompleted] = useState(false);

  // Flashcards state
  const [flashcardIdx, setFlashcardIdx] = useState(0);
  const [flipped, setFlipped] = useState(false);

  // Beginner AI state
  const [beginnerQuery, setBeginnerQuery] = useState('');
  const [beginnerAnswer, setBeginnerAnswer] = useState('');
  const [beginnerLoading, setBeginnerLoading] = useState(false);

  // Terms search
  const [termQuery, setTermQuery] = useState('');

  const currentQ = STUDENT_QUIZZES[currentQuizIdx];
  const currentCard = MEDICINES_DATA[flashcardIdx];

  const handleSelectOption = (idx: number) => {
    if (selectedAnswer !== null) return;
    setSelectedAnswer(idx);
    setShowExplanation(true);
    if (idx === currentQ.correctIndex) {
      setScore((prev) => prev + 1);
    }
  };

  const handleNextQuestion = () => {
    setSelectedAnswer(null);
    setShowExplanation(false);
    if (currentQuizIdx + 1 < STUDENT_QUIZZES.length) {
      setCurrentQuizIdx((prev) => prev + 1);
    } else {
      setQuizCompleted(true);
    }
  };

  const restartQuiz = () => {
    setCurrentQuizIdx(0);
    setSelectedAnswer(null);
    setShowExplanation(false);
    setScore(0);
    setQuizCompleted(false);
  };

  const handleBeginnerSubmit = async () => {
    if (!beginnerQuery.trim() || beginnerLoading) return;
    setBeginnerLoading(true);
    setBeginnerAnswer('');

    try {
      const response = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: beginnerQuery,
          expertType: 'tutor',
          language,
          beginnerMode: true,
        }),
      });
      const data = await response.json();
      setBeginnerAnswer(data.reply);
    } catch {
      setBeginnerAnswer('Unable to generate beginner breakdown. Please try again.');
    } finally {
      setBeginnerLoading(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 animate-fade-in pb-16 space-y-8">
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-teal-50 dark:bg-teal-950 text-teal-700 dark:text-teal-300 text-xs font-bold mb-3">
          <GraduationCap className="w-4 h-4" />
          <span>Medical & Pharmacy Academic Academy</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-black text-slate-900 dark:text-white tracking-tight">
          Student Learning Hub
        </h1>
        <p className="text-sm text-slate-500 mt-2">
          High-yield pharmacology quizzes, study flashcards, clinical terminology, and AI-powered simple explanations.
        </p>
      </div>

      {/* Tabs */}
      <div className="flex items-center justify-center gap-2 border-b border-slate-200 dark:border-slate-800 pb-4">
        {[
          { id: 'quiz', label: 'Interactive MCQ Quiz', icon: Award },
          { id: 'flashcards', label: 'Pharmacology Flashcards', icon: Layers },
          { id: 'terms', label: 'Medical Terminology', icon: BookOpen },
          { id: 'beginner-ai', label: 'Explain Like I’m a Beginner', icon: Sparkles },
        ].map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-4 py-2.5 rounded-xl text-xs font-bold flex items-center gap-2 transition-all ${
                activeTab === tab.id
                  ? 'bg-teal-600 text-white shadow-md'
                  : 'bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span className="hidden sm:inline">{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* 1. QUIZ TAB */}
      {activeTab === 'quiz' && (
        <div className="max-w-2xl mx-auto bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-8 shadow-xl">
          {!quizCompleted ? (
            <div>
              <div className="flex items-center justify-between text-xs font-semibold text-slate-400 mb-4">
                <span>
                  Question {currentQuizIdx + 1} of {STUDENT_QUIZZES.length}
                </span>
                <span className="text-teal-600 dark:text-teal-400 font-bold">
                  Category: {currentQ.category}
                </span>
              </div>

              <h3 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white mb-6">
                {currentQ.question}
              </h3>

              {/* Options */}
              <div className="space-y-3 mb-6">
                {currentQ.options.map((opt, idx) => {
                  let btnStyle =
                    'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 hover:border-teal-500 text-slate-800 dark:text-slate-200';
                  if (selectedAnswer !== null) {
                    if (idx === currentQ.correctIndex) {
                      btnStyle = 'bg-emerald-100 dark:bg-emerald-950/60 border-emerald-500 text-emerald-900 dark:text-emerald-200 font-bold';
                    } else if (idx === selectedAnswer) {
                      btnStyle = 'bg-red-100 dark:bg-red-950/60 border-red-500 text-red-900 dark:text-red-200';
                    } else {
                      btnStyle = 'opacity-50 border-slate-200 dark:border-slate-800 text-slate-400';
                    }
                  }

                  return (
                    <button
                      key={idx}
                      onClick={() => handleSelectOption(idx)}
                      disabled={selectedAnswer !== null}
                      className={`w-full text-left p-4 rounded-xl border text-xs sm:text-sm font-medium transition-all flex items-center justify-between ${btnStyle}`}
                    >
                      <span>{opt}</span>
                      {selectedAnswer !== null && idx === currentQ.correctIndex && (
                        <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                      )}
                      {selectedAnswer !== null &&
                        idx === selectedAnswer &&
                        idx !== currentQ.correctIndex && (
                          <XCircle className="w-5 h-5 text-red-600 shrink-0" />
                        )}
                    </button>
                  );
                })}
              </div>

              {/* Explanation */}
              {showExplanation && (
                <div className="p-4 rounded-2xl bg-teal-50 dark:bg-teal-950/30 border border-teal-200 dark:border-teal-800 mb-6 text-xs text-teal-950 dark:text-teal-200 animate-fade-in">
                  <p className="font-bold mb-1">Clinical Rationale:</p>
                  <p className="leading-relaxed">{currentQ.explanation}</p>
                </div>
              )}

              {/* Next Button */}
              {selectedAnswer !== null && (
                <button
                  onClick={handleNextQuestion}
                  className="w-full py-3 rounded-xl bg-teal-600 hover:bg-teal-700 text-white font-bold text-sm transition-colors shadow-md"
                >
                  {currentQuizIdx + 1 < STUDENT_QUIZZES.length ? 'Next Question &rarr;' : 'Finish Quiz &rarr;'}
                </button>
              )}
            </div>
          ) : (
            <div className="text-center py-8 space-y-4">
              <Award className="w-16 h-16 text-teal-600 mx-auto" />
              <h3 className="text-2xl font-extrabold text-slate-900 dark:text-white">
                Quiz Complete!
              </h3>
              <p className="text-base text-slate-600 dark:text-slate-300">
                You scored <strong>{score}</strong> out of <strong>{STUDENT_QUIZZES.length}</strong> (
                {Math.round((score / STUDENT_QUIZZES.length) * 100)}%)
              </p>
              <button
                onClick={restartQuiz}
                className="px-6 py-2.5 rounded-xl bg-teal-600 hover:bg-teal-700 text-white font-bold text-sm flex items-center gap-2 mx-auto"
              >
                <RotateCcw className="w-4 h-4" /> Try Again
              </button>
            </div>
          )}
        </div>
      )}

      {/* 2. FLASHCARDS TAB */}
      {activeTab === 'flashcards' && (
        <div className="max-w-xl mx-auto space-y-6">
          <div
            onClick={() => setFlipped(!flipped)}
            className="w-full h-80 rounded-3xl bg-white dark:bg-slate-900 border-2 border-slate-200 dark:border-slate-800 p-8 shadow-2xl flex flex-col justify-between cursor-pointer transition-all hover:scale-[1.01]"
          >
            <div className="flex items-center justify-between text-xs text-slate-400 font-semibold">
              <span>Card {flashcardIdx + 1} of {MEDICINES_DATA.length}</span>
              <span className="text-teal-600">{flipped ? 'Back (Pharmacology)' : 'Front (Drug)'}</span>
            </div>

            {!flipped ? (
              <div className="text-center my-auto">
                <span className="text-[10px] font-bold uppercase tracking-wider text-teal-600 bg-teal-50 dark:bg-teal-950 px-2.5 py-1 rounded">
                  {currentCard.category}
                </span>
                <h3 className="text-3xl font-extrabold text-slate-900 dark:text-white mt-3">
                  {currentCard.genericName}
                </h3>
                <p className="text-xs text-slate-400 mt-2">
                  Common Brands: {currentCard.brandNames.join(', ')}
                </p>
                <p className="text-[11px] text-teal-600 font-semibold mt-4">
                  (Tap to flip and inspect mechanism & warnings)
                </p>
              </div>
            ) : (
              <div className="space-y-3 my-auto text-left text-xs text-slate-700 dark:text-slate-300">
                <div>
                  <strong className="text-teal-600">Mechanism:</strong> {currentCard.howItWorks}
                </div>
                <div>
                  <strong className="text-red-500">Key Warnings:</strong> {currentCard.importantWarnings[0]}
                </div>
                <div>
                  <strong className="text-slate-900 dark:text-white">Indications:</strong> {currentCard.generalUses.join(' • ')}
                </div>
              </div>
            )}

            <div className="text-center text-[10px] text-slate-400">
              Click anywhere to flip card
            </div>
          </div>

          <div className="flex items-center justify-between">
            <button
              onClick={() => {
                setFlipped(false);
                setFlashcardIdx((prev) => (prev > 0 ? prev - 1 : MEDICINES_DATA.length - 1));
              }}
              className="px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-semibold"
            >
              &larr; Previous Card
            </button>
            <button
              onClick={() => {
                setFlipped(false);
                setFlashcardIdx((prev) => (prev + 1 < MEDICINES_DATA.length ? prev + 1 : 0));
              }}
              className="px-4 py-2 rounded-xl bg-teal-600 text-white text-xs font-semibold"
            >
              Next Card &rarr;
            </button>
          </div>
        </div>
      )}

      {/* 3. TERMINOLOGY TAB */}
      {activeTab === 'terms' && (
        <div className="max-w-4xl mx-auto space-y-6">
          <input
            type="text"
            value={termQuery}
            onChange={(e) => setTermQuery(e.target.value)}
            placeholder="Search medical terms (e.g. Bioavailability, Half-life)..."
            className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-sm"
          />

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {MEDICAL_TERMS.filter(
              (t) =>
                t.term.toLowerCase().includes(termQuery.toLowerCase()) ||
                t.simpleDefinition.toLowerCase().includes(termQuery.toLowerCase())
            ).map((term, idx) => (
              <div
                key={idx}
                className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm space-y-2"
              >
                <div className="flex items-center justify-between">
                  <h4 className="text-base font-bold text-slate-900 dark:text-white">
                    {term.term}
                  </h4>
                  {term.pronunciation && (
                    <span className="text-[10px] text-slate-400 italic font-mono">
                      /{term.pronunciation}/
                    </span>
                  )}
                </div>
                <div className="p-2.5 rounded-xl bg-teal-50 dark:bg-teal-950/40 text-teal-900 dark:text-teal-200 text-xs">
                  <strong>Plain English:</strong> {term.simpleDefinition}
                </div>
                <p className="text-xs text-slate-500">
                  <strong>Clinical Definition:</strong> {term.clinicalDefinition}
                </p>
                <p className="text-[11px] text-slate-400 italic">
                  Context: "{term.exampleContext}"
                </p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 4. BEGINNER AI TAB */}
      {activeTab === 'beginner-ai' && (
        <div className="max-w-2xl mx-auto bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-8 shadow-xl space-y-6">
          <div>
            <h3 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-teal-500" /> Explain Like I’m a Beginner
            </h3>
            <p className="text-xs text-slate-500 mt-1">
              Enter any complicated medical term, drug mechanism, or pathology concept. DRUGAI will translate it into clear, easy-to-understand plain language.
            </p>
          </div>

          <div className="flex gap-2">
            <input
              type="text"
              value={beginnerQuery}
              onChange={(e) => setBeginnerQuery(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleBeginnerSubmit()}
              placeholder="e.g. Renin-Angiotensin system, First pass metabolism, Dengue shock..."
              className="flex-1 px-4 py-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-sm focus:outline-none focus:ring-2 focus:ring-teal-500"
            />
            <button
              onClick={handleBeginnerSubmit}
              disabled={beginnerLoading || !beginnerQuery.trim()}
              className="px-5 py-3 rounded-xl bg-teal-600 hover:bg-teal-700 disabled:opacity-50 text-white font-bold text-sm"
            >
              Simplify
            </button>
          </div>

          {beginnerAnswer && (
            <div className="p-5 rounded-2xl bg-teal-50/70 dark:bg-teal-950/40 border border-teal-200 dark:border-teal-800 text-xs sm:text-sm text-slate-800 dark:text-slate-200 whitespace-pre-wrap leading-relaxed animate-fade-in">
              {beginnerAnswer}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
