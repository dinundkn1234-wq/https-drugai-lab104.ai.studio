export type UserRole = 'patient' | 'student' | 'doctor' | 'researcher' | 'admin';

export interface UserProfile {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  isDoctorVerified?: boolean;
  medicalLicenseNumber?: string;
  institution?: string;
  savedMedicines: string[]; // medicine IDs
  savedDiseases: string[]; // disease IDs
  bookmarks: { id: string; type: 'disease' | 'medicine' | 'article'; title: string }[];
  recentSearches: string[];
  preferredLanguage: SupportedLanguage;
  createdAt: string;
}

export type SupportedLanguage =
  | 'Auto-Detect'
  | 'English'
  | 'Telugu'
  | 'Hindi'
  | 'Tamil'
  | 'Kannada'
  | 'Malayalam'
  | 'Marathi'
  | 'Bengali'
  | 'Gujarati'
  | 'Punjabi'
  | 'Urdu'
  | 'Spanish';

export interface Disease {
  id: string;
  name: string;
  scientificName?: string;
  category: string;
  isRareDisease?: boolean;
  overview: string;
  commonSymptoms: string[];
  causesAndRisks: string[];
  types: string[];
  prevention: string[];
  diagnosticTests: string[];
  treatmentApproaches: string[];
  medicineCategories: string[];
  whenToSeekHelp: string[];
  emergencyWarningSigns: string[];
  faqs: { question: string; answer: string }[];
  sources: { title: string; organization: string; url?: string }[];
}

export interface Medicine {
  id: string;
  genericName: string;
  brandNames: string[];
  category: string;
  generalUses: string[];
  howItWorks: string;
  commonSideEffects: string[];
  importantWarnings: string[];
  commonInteractions: string[];
  contraindications: string[];
  storageInfo: string;
  generalSafety: string;
  pregnancyWarning: string;
  ageSafetyWarning: string;
  whenProfessionalAdviceNecessary: string[];
  scheduleType: 'OTC' | 'Prescription' | 'Controlled';
}

export interface DrugInteractionPair {
  pair: [string, string];
  severity: 'Major' | 'Moderate' | 'Minor' | 'None';
  description: string;
  mechanism: string;
  clinicalEffects: string[];
  precautions: string[];
  questionsForClinician: string[];
}

export interface DrugInteractionResponse {
  overallRisk: 'Major' | 'Moderate' | 'Minor' | 'None';
  summary: string;
  interactions: DrugInteractionPair[];
  generalSafetyNotes?: string[];
  disclaimer: string;
  source?: string;
}

export interface HealthArticle {
  id: string;
  title: string;
  summary: string;
  category: string;
  readTime: string;
  publishedDate: string;
  author: string;
  organization: string;
  content: string[];
  keyTakeaways: string[];
  references: string[];
}

export interface EmergencyHospital {
  id: string;
  name: string;
  city: string;
  distanceKm: number;
  address: string;
  phone: string;
  emergencyDepartmentOpen24x7: boolean;
  traumaLevel?: string;
  ambulanceContact: string;
  coordinates: { lat: number; lng: number };
  facilityType?: 'hospital' | 'clinic' | 'emergency' | 'pharmacy';
  rating?: number;
  googleMapsUri?: string;
  ownership?: 'Government' | 'Private' | 'Charitable' | 'Academic';
}

export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
  category: 'Pharmacology' | 'Pathology' | 'Emergency Care' | 'General Health';
}

export interface MedicalTerm {
  term: string;
  pronunciation?: string;
  simpleDefinition: string;
  clinicalDefinition: string;
  exampleContext: string;
}
